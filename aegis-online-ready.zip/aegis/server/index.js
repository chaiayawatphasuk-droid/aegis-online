'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const DB = require('./database/db');
const auth = require('./auth/auth');
const { attachWS } = require('./network/ws');
const { Game } = require('./systems/game');
const GD = require('../shared/data');

const PORT = Number(process.env.PORT) || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'aegis.db');
const MAX_CHARS = 4;
const ROOT = path.join(__dirname, '..');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.json': 'application/json', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };
const STATIC = { '/shared/data.js': path.join(ROOT, 'shared', 'data.js') };

const db = new DB(DB_PATH);
const game = new Game(db);

function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function body(req) {
  return new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', c => { n += c.length; if (n > 16384) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString() || '{}')); } catch { reject(new Error('bad json')); } });
    req.on('error', reject);
  });
}
const ipOf = req => (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress;
function authUser(req) { const h = req.headers.authorization || ''; return auth.verifyToken(h.startsWith('Bearer ') ? h.slice(7) : ''); }

async function api(req, res, url) {
  const ip = ipOf(req);
  if (!auth.rateLimit('api:' + ip, 120, 60000)) return json(res, 429, { error: 'Too many requests' });
  if (req.method === 'POST' && (url === '/api/register' || url === '/api/login')) {
    if (!auth.rateLimit('auth:' + ip, 15, 60000)) return json(res, 429, { error: 'Too many attempts, wait a minute' });
    const b = await body(req);
    const u = String(b.username || '').trim(), pw = String(b.password || '');
    if (!/^[A-Za-z0-9_]{3,16}$/.test(u)) return json(res, 400, { error: 'Username: 3-16 letters, numbers or _' });
    if (pw.length < 6 || pw.length > 72) return json(res, 400, { error: 'Password: 6-72 characters' });
    if (url === '/api/register') {
      if (db.userByName(u)) return json(res, 409, { error: 'Username already taken' });
      const id = db.addUser(u, auth.hashPassword(pw));
      return json(res, 200, { token: auth.signToken(id), username: u });
    }
    const user = db.userByName(u);
    if (!user || !auth.verifyPassword(pw, user.pass)) return json(res, 401, { error: 'Invalid username or password' });
    return json(res, 200, { token: auth.signToken(user.id), username: user.username });
  }
  if (url === '/api/leaderboard' && req.method === 'GET') return json(res, 200, db.leaderboard());
  const tok = authUser(req); if (!tok) return json(res, 401, { error: 'Not logged in' });
  if (url === '/api/characters' && req.method === 'GET') return json(res, 200, { chars: db.listChars(tok.uid), max: MAX_CHARS });
  if (url === '/api/characters' && req.method === 'POST') {
    const b = await body(req);
    const name = String(b.name || '').trim(), cls = String(b.cls || ''), a = b.app || {};
    if (!/^[A-Za-z][A-Za-z0-9]{2,13}$/.test(name)) return json(res, 400, { error: 'Name: 3-14 letters/numbers, starting with a letter' });
    if (!GD.CLASSES[cls]) return json(res, 400, { error: 'Invalid class' });
    if (db.charCount(tok.uid) >= MAX_CHARS) return json(res, 400, { error: `Max ${MAX_CHARS} characters` });
    if (db.charByName(name)) return json(res, 409, { error: 'Name already taken' });
    const A = GD.APPEARANCE, pick = (v, n) => (Number.isInteger(v) && v >= 0 && v < n ? v : 0);
    const app = { g: a.g === 'f' ? 'f' : 'm', skin: pick(a.skin, A.skins.length), hair: pick(a.hair, A.styles.length), hc: pick(a.hc, A.hairs.length), oc: pick(a.oc, A.outfits.length), acc: pick(a.acc, A.accs.length) };
    const eq = { weapon: GD.makeItem(`novice_${cls}_wpn`, 1, null, -1), armor: GD.makeItem(cls === 'mage' ? 'novice_robe' : (cls === 'guardian' || cls === 'warrior') ? 'novice_heavy' : 'novice_light', 1, null, -1) };
    if (cls === 'guardian') eq.offhand = GD.makeItem('buckler', 1, null, -1);
    const inv = [GD.makeItem('hp_s', 10), GD.makeItem('mp_s', 5)];
    const data = { app, alloc: { vit: 0, str: 0, int: 0, dex: 0, end: 0 }, pts: 0, feats: [], cnt: {}, zones: [], tut: 0, pos: { x: 128.5 * GD.TILE, y: 130.5 * GD.TILE }, pvp: false };
    try { const id = db.createChar(tok.uid, name, cls, 100, data, inv, eq); return json(res, 200, { id }); }
    catch (e) { return json(res, 409, { error: 'Name already taken' }); }
  }
  const mDel = url.match(/^\/api\/characters\/(\d+)$/);
  if (mDel && req.method === 'DELETE') {
    const id = Number(mDel[1]);
    if (game.byCid.has(id)) return json(res, 400, { error: 'Character is online' });
    return json(res, db.deleteChar(tok.uid, id) ? 200 : 404, { ok: true });
  }
  json(res, 404, { error: 'Not found' });
}

function serveStatic(req, res, url) {
  let file = STATIC[url];
  if (!file) {
    const rel = url === '/' ? 'index.html' : decodeURIComponent(url).replace(/^\/+/, '');
    file = path.normalize(path.join(ROOT, 'client', rel));
    if (!file.startsWith(path.join(ROOT, 'client'))) { res.writeHead(403); return res.end(); }
  }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const ext = path.extname(file);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300', 'X-Content-Type-Options': 'nosniff' });
    fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  const url = (req.url || '/').split('?')[0];
  try {
    if (url === '/health') return json(res, 200, { ok: true, players: game.players.size, maps: game.maps.size });
    if (url.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    serveStatic(req, res, url);
  } catch (e) {
    if (!res.headersSent) json(res, 400, { error: e.message === 'too large' ? 'Request too large' : 'Bad request' });
  }
});

attachWS(server, '/ws', (sock) => {
  let player = null;
  const authT = setTimeout(() => { if (!player) sock.close(4000); }, 10000);
  sock.on('message', raw => {
    if (player) return game.handle(player, raw);
    let m; try { m = JSON.parse(raw); } catch { return sock.close(4000); }
    if (m.t !== 'auth') return;
    const tok = auth.verifyToken(m.token);
    if (!tok) { sock.send(JSON.stringify({ t: 'err', m: 'Session expired, please log in again' })); return sock.close(4003); }
    clearTimeout(authT);
    player = game.join(sock, tok.uid, Number(m.cid));
  });
  sock.on('close', () => { clearTimeout(authT); if (player) game.leave(player); player = null; });
});

server.listen(PORT, () => console.log(`Aegis Online server running on http://localhost:${PORT}`));

function shutdown() {
  console.log('Saving all players...');
  try { game.saveAll(); } catch (e) { console.error(e); }
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
process.on('uncaughtException', e => console.error('uncaught', e));
