'use strict';
const GD = require('../../shared/data');
let NEXT_ID = 1;
const nid = () => NEXT_ID++;

function createPlayer(sock, uid, loaded) {
  const { row, data, inv, eq, quests, member } = loaded;
  const p = {
    id: nid(), kind: 'p', sock, uid, cid: row.id, name: row.name, cls: row.cls, lvl: row.level, exp: row.exp, gold: row.gold,
    rating: row.rating, wins: row.wins, losses: row.losses,
    app: data.app || {}, alloc: Object.assign({ vit: 0, str: 0, int: 0, dex: 0, end: 0 }, data.alloc), pts: data.pts || 0,
    feats: data.feats || [], cnt: data.cnt || {}, zones: data.zones || [], tut: data.tut || 0,
    inv: normInv(inv), eq: eq || {}, quests: quests.active ? quests : { active: {}, done: [] },
    x: data.pos ? data.pos.x : 128 * GD.TILE, y: data.pos ? data.pos.y : 128 * GD.TILE, a: 0,
    hp: data.hp || 1, mp: data.mp || 1, sh: 0, shT: 0, buffs: {}, cds: {}, input: { dx: 0, dy: 0, run: 1 },
    dash: null, iframe: 0, blocking: false, pvp: !!data.pvp, party: null, gid: member ? member.guild_id : 0, grank: member ? member.rank : '', gname: '',
    dead: false, deadT: 0, combatT: 0, anim: 0, animT: 0, known: new Map(), zone: -1, map: null, ret: null, team: 0,
    dirty: { me: true, inv: true, q: true }, lastChat: 0, lastSave: Date.now(), msgBudget: 40, msgT: Date.now(), trade: null, escort: 0, lastWarn: 0
  };
  p.stats = GD.computeStats(p.cls, p.lvl, p.alloc, p.eq, p.feats);
  if (p.hp <= 1 || p.hp > p.stats.hp) p.hp = p.stats.hp;
  if (p.mp <= 1 || p.mp > p.stats.mp) p.mp = p.stats.mp;
  return p;
}
function normInv(inv) { const a = new Array(40).fill(null); (inv || []).forEach((it, i) => { if (i < 40 && it && GD.ITEMS[it.i]) a[i] = it; }); return a; }

function serializePlayer(p) {
  const pos = p.map && p.map.kind === 'world' ? { x: Math.round(p.x), y: Math.round(p.y) } : (p.ret || { x: 128 * GD.TILE, y: 128 * GD.TILE });
  return {
    id: p.cid, level: p.lvl, exp: p.exp, gold: p.gold, rating: p.rating, wins: p.wins, losses: p.losses,
    data: {
      app: p.app, alloc: p.alloc, pts: p.pts, feats: p.feats, cnt: p.cnt, zones: p.zones, tut: p.tut, pos, pvp: p.pvp,
      hp: Math.round(p.hp), mp: Math.round(p.mp), stats: p.stats, skills: GD.CLASSES[p.cls].skills.filter(s => GD.SKILLS[s].lvl <= p.lvl)
    },
    inv: p.inv, eq: p.eq, quests: p.quests
  };
}

function createMonster(mid, x, y, lvl, opts) {
  const d = GD.MONSTERS[mid], s = GD.monsterStats(mid, lvl);
  return Object.assign({
    id: nid(), kind: 'm', mid, d, lvl: s.lvl, st: { atk: s.atk, matk: s.atk, def: s.def, mdef: s.mdef, crit: 5, dodge: 0, block: 0, reflect: 0, spd: s.spd },
    exp: s.exp, goldV: s.gold, range: s.range, x, y, hx: x, hy: y, a: 0, hp: s.hp, mhp: s.hp, state: 'idle', target: 0, threat: new Map(),
    atkT: 0, wT: 0, px: x, py: y, buffs: {}, fled: false, fleeT: 0, dead: false, respawnT: 0, anim: 0, animT: 0, size: d.size,
    respawn: 15000, phase: 0, patT: 0, adds: 0, lastSeen: 0
  }, opts || {});
}

module.exports = { nid, createPlayer, serializePlayer, createMonster };
