'use strict';
const GD = require('../../shared/data');
const { nid, createMonster } = require('../entities/entities');
const TILE = GD.TILE;

module.exports = {
  // ---------------- dungeons (instanced per party / solo) ----------------
  enterDungeon(p, key) {
    const D = GD.DUNGEONS[key];
    if (p.lvl < D.lvl) return this.msg(p, `${D.name} requires level ${D.lvl}.`, '#ff8a65');
    if (p.map.kind !== 'world') return this.msg(p, 'Leave your current instance first.');
    if (p.dead) return;
    const gk = (p.party ? 'P' + p.party.id : 'S' + p.id) + ':' + key;
    let map = null; for (const m of this.maps.values()) if (m.kind === 'dungeon' && m.meta.gk === gk) { map = m; break; }
    if (!map) map = this.createDungeon(key, gk);
    p.ret = { x: (D.entrance[0] + 0.5) * TILE, y: (D.entrance[1] + 2.5) * TILE };
    this.changeMap(p, map, map.meta.spawn[0], map.meta.spawn[1]);
    this.msg(p, `Entered ${D.name}${p.party ? ' (party instance)' : ''}. Defeat ${GD.MONSTERS[D.boss].n}!`, '#c9a0ff');
  },
  createDungeon(key, gk) {
    const { GameMap } = require('./game');
    const D = GD.DUNGEONS[key], g = GD.buildDungeon(key);
    const map = new GameMap('dg' + (this.instSeq++), 'dungeon', g);
    map.meta = { gk, key, name: D.name, spawn: g.spawn, boss: D.boss, cleared: false };
    const L = D.mlvl, R = g.rooms;
    const sp = (mid, room, lvl, opt) => {
      const r = R[room];
      for (let i = 0; i < 50; i++) {
        const x = (r.x0 + 2 + Math.random() * (r.w - 4)) * TILE, y = (r.y0 + 2 + Math.random() * (r.h - 4)) * TILE;
        if (!GD.hitBox(map, x, y, 14)) { const m = createMonster(mid, x, y, lvl, Object.assign({ respawn: 0, leash: 2000 }, opt)); map.add(m); return m; }
      }
    };
    map.add({ id: nid(), kind: 'o', st: 'exit', x: g.spawn[0] - 10, y: g.spawn[1] - 70, ver: 0 });
    for (let i = 0; i < 5; i++) sp(D.mobs[i % 2], 1, L - 2 + (i % 3));
    for (let i = 0; i < 4; i++) sp(D.mobs[i % 2], 2, L - 1 + (i % 2));
    sp(D.mini, 2, L + 1);
    sp(D.mobs[0], 3, L); sp(D.mobs[1], 3, L);
    const b = createMonster(D.boss, R[3].cx + 120, R[3].cy, L + 2, { respawn: 0, leash: 2000 }); map.add(b);
    this.maps.set(map.id, map);
    return map;
  },
  dungeonCleared(map, boss) {
    map.meta.cleared = true;
    const D = GD.DUNGEONS[map.meta.key];
    map.add({ id: nid(), kind: 'o', st: 'chest', dungeon: true, opened: new Set(), lvl: D.mlvl + 2, x: boss.x, y: boss.y, ver: 0 });
    map.add({ id: nid(), kind: 'o', st: 'exit', x: boss.x + 80, y: boss.y, ver: 0 });
    for (const p of map.players) this.msg(p, `★ ${D.name} cleared! Open the reward chest. Use the exit portal to leave.`, '#ffd34d');
  },
  leaveInstance(p) {
    const ret = p.ret || { x: 128.5 * TILE, y: 130.5 * TILE };
    if (p.dead) { p.dead = false; p.hp = p.stats.hp; p.anim = 0; }
    p.team = 0; this.changeMap(p, this.world, ret.x, ret.y); p.ret = null;
  },

  // ---------------- arena (instanced PvP: 1v1, 2v2, 3v3 team battle) ----------------
  queueArena(p, mode) {
    if (!mode) return;
    if (p.lvl < 5) return this.msg(p, 'Arena requires level 5.');
    if (p.map.kind !== 'world') return this.msg(p, 'Leave your instance first.');
    for (const k in this.queues) this.queues[k] = this.queues[k].filter(x => x !== p);
    this.queues[mode].push(p);
    const need = mode * 2;
    this.msg(p, `Queued for ${mode}v${mode} arena (${this.queues[mode].length}/${need}).`, '#ff9d9d');
    this.send(p, { t: 'aq', mode });
    this.tryMatch(mode);
  },
  tryMatch(mode) {
    const need = mode * 2;
    this.queues[mode] = this.queues[mode].filter(p => this.players.has(p.id) && p.map.kind === 'world' && !p.dead);
    if (this.queues[mode].length < need) return;
    const ps = this.queues[mode].splice(0, need).sort(() => Math.random() - 0.5);
    const { GameMap } = require('./game');
    const map = new GameMap('ar' + (this.instSeq++), 'arena', GD.buildArena());
    const now = Date.now();
    map.meta = { name: `Arena ${mode}v${mode}`, mode, start: now + 5000, end: now + 185000, done: false, closeT: 0 };
    this.maps.set(map.id, map);
    ps.forEach((p, i) => {
      const team = i % 2 === 0 ? 1 : 2, slot = Math.floor(i / 2);
      p.ret = { x: p.x, y: p.y }; p.team = team; p.blocking = false;
      if (p.party) this.partyLeave(p);
      this.changeMap(p, map, (team === 1 ? 4 : 25) * TILE, (6 + slot * 4) * TILE);
      p.hp = p.stats.hp; p.mp = p.stats.mp; p.buffs = {}; p.sh = 0; p.cds = {};
      this.send(p, { t: 'aq', mode: 0 });
      this.msg(p, `Arena match ${mode}v${mode} — you are on ${team === 1 ? 'BLUE' : 'RED'} team. Fight starts in 5s!`, '#ff9d9d');
    });
  },
  updateArena(map, now) {
    const M = map.meta;
    if (M.done) {
      if (now > M.closeT) for (const p of [...map.players]) { p.dead = false; p.hp = p.stats.hp; p.mp = p.stats.mp; p.anim = 0; this.leaveInstance(p); }
      return;
    }
    if (now > M.end) {
      const score = t => [...map.players].filter(p => p.team === t && !p.dead).reduce((a, p) => a + p.hp / p.stats.hp, 0);
      const s1 = score(1), s2 = score(2);
      this.arenaFinish(map, s1 === s2 ? 0 : s1 > s2 ? 1 : 2);
    }
  },
  arenaCheck(map) {
    if (map.meta.done) return;
    const alive = t => [...map.players].some(p => p.team === t && !p.dead);
    const a1 = alive(1), a2 = alive(2);
    if (!a1 || !a2) this.arenaFinish(map, a1 ? 1 : a2 ? 2 : 0);
  },
  arenaFinish(map, winner) {
    map.meta.done = true; map.meta.closeT = Date.now() + 5000;
    for (const p of map.players) {
      if (!winner) this.msg(p, 'Arena: draw!', '#ffd34d');
      else if (p.team === winner) { p.rating += 20; p.wins++; this.msg(p, 'Arena: VICTORY! +20 rating', '#ffd34d'); }
      else { p.rating = Math.max(0, p.rating - 15); p.losses++; this.msg(p, 'Arena: defeat. -15 rating', '#ff6b6b'); }
      p.dirty.me = true; this.save(p);
    }
  }
};
