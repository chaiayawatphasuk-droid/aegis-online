'use strict';
const GD = require('../../shared/data');
const { nid } = require('../entities/entities');
const d2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;
const angDiff = (a, b) => { let d = a - b; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return Math.abs(d); };
const num = (v, d) => (typeof v === 'number' && isFinite(v) ? v : d);

module.exports = {
  eff(e, k) {
    const s = e.kind === 'p' ? e.stats : (e.st || {}); let v = s[k] || 0; const b = e.buffs || {};
    if ((k === 'atk' || k === 'matk') && b.atk_up) v *= b.atk_up.v;
    if (k === 'def' && b.def_up) v *= b.def_up.v;
    if (k === 'mdef' && b.mdef_up) v *= b.mdef_up.v;
    if (k === 'reflect' && b.reflect_up) v += b.reflect_up.v;
    return v;
  },
  canHarm(a, b) {
    if (!a || !b || b.dead || a === b || a.map !== b.map) return false;
    if (b.kind === 'm') return a.kind === 'p';
    if (b.kind === 'e') return a.kind === 'm';
    if (b.kind !== 'p') return false;
    if (a.kind === 'm') return true;
    if (a.kind !== 'p') return false;
    const map = a.map;
    if (map.kind === 'arena') return a.team !== b.team && Date.now() >= map.meta.start && !map.meta.done;
    if (map.kind !== 'world') return false;
    if (a.party && a.party === b.party) return false;
    const za = GD.ZONES[a.zone], zb = GD.ZONES[b.zone];
    return a.pvp && b.pvp && za && zb && za.pvp && zb.pvp;
  },
  combatAllowed(p, now) { const m = p.map; return !(m.kind === 'arena' && (now < m.meta.start || m.meta.done)); },
  enemiesIn(src, x, y, r) {
    const out = [];
    for (const e of src.map.ents.values()) {
      if (e.kind !== 'm' && e.kind !== 'p' && e.kind !== 'e') continue;
      if (!this.canHarm(src, e)) continue;
      const rr = r + (e.size || 10); if ((e.x - x) ** 2 + (e.y - y) ** 2 <= rr * rr) out.push(e);
    }
    return out;
  },
  nearestEnemy(p, range, a) {
    let best = null, bs = Infinity;
    for (const e of this.enemiesIn(p, p.x, p.y, range)) { const s = Math.sqrt(d2(e, p)) + (a === undefined ? 0 : angDiff(Math.atan2(e.y - p.y, e.x - p.x), a) * 120); if (s < bs) { bs = s; best = e; } }
    return best;
  },
  alliesIn(p, r) {
    const out = [p], R = r * r;
    if (p.party) for (const id of p.party.members) { const o = this.players.get(id); if (o && o !== p && !o.dead && o.map === p.map && d2(o, p) <= R) out.push(o); }
    if (p.map.kind === 'arena') for (const o of p.map.players) if (o !== p && o.team === p.team && !o.dead && d2(o, p) <= R && !out.includes(o)) out.push(o);
    return out;
  },

  dealDamage(src, t, mult, o = {}) {
    if (!t || t.dead || !src) return 0;
    const now = Date.now(), map = t.map;
    if (t.kind === 'p' && (t.iframe > now || t.buffs.vanish)) { map.fx.push([t.x, t.y - 20, 'd', 0, 4]); return 0; }
    const magic = !!o.magic;
    if (t.kind === 'p' && !o.aoe && Math.random() * 100 < t.stats.dodge) { map.fx.push([t.x, t.y - 20, 'd', 0, 4]); return 0; }
    const atk = this.eff(src, magic ? 'matk' : 'atk'), def = this.eff(t, magic ? 'mdef' : 'def');
    let dmg = atk * mult * 100 / (100 + Math.max(0, def)) * (0.9 + Math.random() * 0.2), crit = false;
    const cc = (src.kind === 'p' ? src.stats.crit : 5) + (o.critBonus || 0);
    if (Math.random() * 100 < cc) { crit = true; dmg *= src.cls === 'assassin' ? 2.2 : 1.8; }
    const tm = t.kind === 'p' ? t.stats.hp : t.mhp;
    if (o.execute && t.hp / tm < o.execute) dmg *= 2;
    if ((src.lvl || 1) < (t.lvl || 1)) dmg *= Math.max(0.5, 1 - ((t.lvl || 1) - (src.lvl || 1)) * 0.04);
    let blocked = false;
    if (t.kind === 'p') {
      if (t.blocking) { blocked = true; dmg *= t.cls === 'guardian' ? 0.25 : 0.6; }
      else if (Math.random() * 100 < t.stats.block) { blocked = true; dmg *= 0.35; }
      if (t.buffs.fortress) dmg *= t.buffs.fortress.v;
      if (src.kind === 'p') dmg *= 0.6;
      if (blocked) t.cnt.blocks = (t.cnt.blocks || 0) + 1;
      if (src.d && src.d.boss) t.cnt.bossHits = (t.cnt.bossHits || 0) + 1;
    }
    dmg = Math.max(1, Math.round(dmg));
    let absorbed = 0;
    if (t.sh > 0) { absorbed = Math.min(t.sh, dmg); t.sh -= absorbed; dmg -= absorbed; }
    t.hp -= dmg;
    const kind = t.kind === 'p' || t.kind === 'e' ? (blocked ? 3 : 5) : (crit ? 1 : 0);
    if (dmg > 0) map.fx.push([t.x, t.y - (t.size || 14) - 8, 'd', dmg, kind]);
    if (absorbed > 0) map.fx.push([t.x + 10, t.y - (t.size || 14) - 20, 'd', absorbed, 6]);
    if (t.kind === 'p') { t.combatT = now; t.cnt.taken = (t.cnt.taken || 0) + dmg + absorbed; }
    if (src.kind === 'p') src.combatT = now;
    if (t.kind === 'm' && src.kind === 'p') {
      t.threat.set(src.id, (t.threat.get(src.id) || 0) + GD.CLASSES[src.cls].threat * (dmg + absorbed));
      if (t.state === 'idle' || t.state === 'return') { t.state = 'chase'; t.target = src.id; }
    }
    if (t.hp > 0) {
      if (o.status) this.applyStatus(t, o.status[0], o.status[1], src);
      else if (src.kind === 'p' && src.buffs.venom) this.applyStatus(t, 'poison', 4000, src);
    }
    if (t.kind === 'p' && !o.noReflect && (src.kind === 'm' || src.kind === 'p') && src.map === map && !src.dead) {
      const refl = this.eff(t, 'reflect') + (blocked && t.cls === 'guardian' ? 15 : 0);
      if (refl > 0) {
        const rd = Math.max(1, Math.round((dmg + absorbed) * refl / 100));
        src.hp -= rd; map.fx.push([src.x, src.y - (src.size || 14) - 8, 'd', rd, 7]);
        t.cnt.reflected = (t.cnt.reflected || 0) + rd;
        if (src.kind === 'm') src.threat.set(t.id, (src.threat.get(t.id) || 0) + rd * 2);
        if (src.hp <= 0) this.kill(src, t);
      }
    }
    if (t.hp <= 0 && !t.dead) this.kill(t, src);
    if (t.kind === 'p') this.checkFeats(t);
    return dmg;
  },
  applyStatus(t, kind, dur, src) {
    const now = Date.now();
    if (kind === 'poison' || kind === 'burn') {
      const base = src.kind === 'p' ? this.eff(src, kind === 'burn' ? 'matk' : 'atk') : src.st.atk;
      t.buffs[kind] = { until: now + dur, v: Math.max(1, Math.round(base * 0.3)), src: src.id };
    } else if (kind === 'stun') { if (t.d && (t.d.boss || t.d.mini)) return; t.buffs.stun = { until: now + dur }; }
    else if (kind === 'slow') t.buffs.slow = { until: now + dur };
    t.map.fx.push([t.x, t.y, 'f', kind]);
  },
  applyDots(t, now) {
    for (const k of ['poison', 'burn']) {
      const b = t.buffs[k]; if (!b || b.until < now) continue;
      const dmg = b.v; t.hp -= dmg; t.map.fx.push([t.x, t.y - 24, 'd', dmg, 8]);
      if (t.kind === 'm') { const s = t.map.ents.get(b.src); if (s) t.threat.set(s.id, (t.threat.get(s.id) || 0) + dmg); }
      if (t.hp <= 0 && !t.dead) { this.kill(t, t.map.ents.get(b.src) || null); return; }
    }
  },
  heal(t, amt) {
    const max = t.kind === 'p' ? t.stats.hp : t.mhp;
    const h = Math.max(0, Math.min(max - t.hp, Math.round(amt))); t.hp += h;
    t.map.fx.push([t.x, t.y - 30, 'd', h, 2]);
  },
  kill(t, src) {
    const map = t.map, now = Date.now();
    if (t.kind === 'm') {
      t.dead = true; t.hp = 0; map.fx.push([t.x, t.y, 'f', 'death', 0, t.size]);
      let p = src && src.kind === 'p' ? src : null;
      if (!p) { let bv = -1; for (const [id, v] of t.threat) { const o = map.ents.get(id); if (o && o.kind === 'p' && v > bv) { bv = v; p = o; } } }
      if (t.bossId) { const b = map.ents.get(t.bossId); if (b) b.adds--; }
      if (t.temp || !t.respawn || map.kind !== 'world') map.remove(t); else t.respawnT = now + t.respawn;
      if (p) this.rewardKill(t, p);
      if (t.d.boss && map.kind === 'world') this.announce(`⚔ ${p ? p.name : 'Adventurers'}${p && p.party ? "'s party" : ''} defeated ${t.d.n}!`);
      if (map.kind === 'dungeon' && t.mid === map.meta.boss) this.dungeonCleared(map, t);
      t.threat.clear();
    } else if (t.kind === 'p') {
      t.dead = true; t.hp = 0; t.deadT = now; t.anim = 5; t.dash = null; t.blocking = false; t.sh = 0; t.buffs = {};
      this.dropAggro(t);
      if (src && src.kind === 'p') { src.cnt.pk = (src.cnt.pk || 0) + 1; this.msg(t, `You were defeated by ${src.name}.`, '#ff6b6b'); this.msg(src, `You defeated ${t.name}!`, '#ffd34d'); }
      else if (map.kind !== 'arena') {
        const loss = Math.floor(Math.min(t.exp, GD.expToNext(t.lvl) * 0.03)); t.exp -= loss;
        this.msg(t, `You have fallen${loss ? ` and lost ${loss} EXP` : ''}. Respawning...`, '#ff6b6b');
      }
      if (t.escort) { const e = this.world.ents.get(t.escort); if (e) { this.world.remove(e); t.escort = 0; this.msg(t, 'Pilgrim Mara fled. Talk to the Quest Master to retry.', '#ff8a65'); } }
      t.dirty.me = true;
      if (map.kind === 'arena') this.arenaCheck(map);
    } else if (t.kind === 'e') {
      map.remove(t); const o = this.players.get(t.owner);
      if (o) { o.escort = 0; this.msg(o, 'Pilgrim Mara has fallen! Talk to the Quest Master to retry.', '#ff6b6b'); }
    }
  },

  // ---------------- player attacks ----------------
  basicAttack(p, m) {
    const now = Date.now();
    if (p.dead || p.blocking || p.buffs.stun || !this.combatAllowed(p, now)) return;
    const B = GD.CLASSES[p.cls].basic;
    if ((p.cds._b || 0) > now) return;
    p.cds._b = now + B.cd * (p.buffs.haste ? 0.8 : 1) - 40;
    let a = num(m.a, p.a);
    const tgt = typeof m.id === 'number' ? p.map.ents.get(m.id) : null;
    if (tgt && this.canHarm(p, tgt) && d2(p, tgt) < (B.range + 120) ** 2) a = Math.atan2(tgt.y - p.y, tgt.x - p.x);
    p.a = a; p.anim = 2; p.animT = now + 260; delete p.buffs.vanish;
    if (B.kind === 'melee') this.arcHit(p, a, B.range, B.arc, B.mult, { fx: B.fx, magic: B.magic });
    else this.spawnProj(p.map, p, a, { speed: B.speed, range: B.range, mult: B.mult, magic: B.magic, style: B.fx });
  },
  arcHit(p, a, range, arc, mult, o) {
    p.map.fx.push([p.x, p.y, 'f', o.fx || 'slash', Math.round(a * 100) / 100, range]);
    const half = arc / 2 * Math.PI / 180 + 0.15;
    for (const e of this.enemiesIn(p, p.x, p.y, range)) {
      const ang = Math.atan2(e.y - p.y, e.x - p.x);
      if (angDiff(ang, a) <= half || d2(e, p) < 26 * 26) this.dealDamage(p, e, mult, o);
    }
  },
  stepMove(p, a, dist) {
    let x = p.x, y = p.y; const n = Math.ceil(dist / 8);
    for (let i = 0; i < n; i++) { const [nx, ny] = GD.tryMove(p.map, x, y, x + Math.cos(a) * 8, y + Math.sin(a) * 8, 10); if (nx === x && ny === y) break; if (!this.placeOk(p, nx, ny)) break; x = nx; y = ny; }
    return [x, y];
  },
  useSkill(p, m) {
    const id = String(m.k), S = GD.SKILLS[id]; if (!S) return;
    if (!GD.CLASSES[p.cls].skills.includes(id) || p.lvl < S.lvl) return;
    const now = Date.now();
    if (p.dead || p.buffs.stun || (p.cds[id] || 0) > now + 100) return;
    if (p.mp < S.mp) return this.msg(p, 'Not enough MP', '#7fb6ff');
    const offensive = !['buff', 'ally_shield', 'heal'].includes(S.type);
    if (offensive && !this.combatAllowed(p, now)) return;
    const map = p.map;
    let tx = num(m.x, p.x + Math.cos(p.a) * 100), ty = num(m.y, p.y + Math.sin(p.a) * 100);
    const tgt = typeof m.id === 'number' ? map.ents.get(m.id) : null;
    if (tgt && this.canHarm(p, tgt)) { tx = tgt.x; ty = tgt.y; }
    const a = (tx === p.x && ty === p.y) ? p.a : Math.atan2(ty - p.y, tx - p.x);
    const o = { magic: S.magic, status: S.status, critBonus: S.critBonus, execute: S.execute };
    const refund = msg => { this.msg(p, msg, '#aaa'); };
    // targeted skills need a target before spending resources
    let chainT = null, blinkT = null;
    if (S.type === 'chain') { chainT = tgt && this.canHarm(p, tgt) && d2(p, tgt) <= S.range * S.range ? tgt : this.nearestEnemy(p, S.range, a); if (!chainT) return refund('No target in range'); }
    if (S.type === 'blink' && S.toTarget) { blinkT = tgt && this.canHarm(p, tgt) && d2(p, tgt) <= (S.dist + 40) ** 2 ? tgt : this.nearestEnemy(p, S.dist, a); if (!blinkT) return refund('No target in range'); }
    p.mp -= S.mp;
    const cd = Math.round(S.cd * (1 - p.stats.cdr / 100)); p.cds[id] = now + cd;
    this.send(p, { t: 'cd', k: id, ms: cd });
    p.a = a; p.anim = 3; p.animT = now + 350;
    if (offensive) delete p.buffs.vanish;
    const applyBuffs = () => (S.buffs || []).forEach(([k, d, v]) => p.buffs[k] = { until: now + d, v });
    switch (S.type) {
      case 'buff': applyBuffs(); map.fx.push([p.x, p.y, 'f', S.fx]); break;
      case 'taunt': {
        for (const e of this.enemiesIn(p, p.x, p.y, S.radius)) {
          if (e.kind !== 'm') continue;
          e.buffs.taunt = { until: now + S.dur, v: p.id }; e.threat.set(p.id, (e.threat.get(p.id) || 0) + 5000); e.state = 'chase'; e.target = p.id;
          if (S.mult) this.dealDamage(p, e, S.mult, {});
        }
        applyBuffs(); map.fx.push([p.x, p.y, 'f', S.fx, 0, S.radius]); break;
      }
      case 'ally_shield': {
        const val = Math.round(this.eff(p, 'def') * 4 + p.stats.hp * 0.1);
        for (const al of this.alliesIn(p, S.radius)) { al.sh = Math.max(al.sh, val); al.shT = now + S.dur; map.fx.push([al.x, al.y, 'f', 'shield']); if (al !== p) this.msg(al, `${p.name} shields you (${val})`, '#7fd4ff'); }
        break;
      }
      case 'arc': this.arcHit(p, a, S.range, S.arc, S.mult, Object.assign({ fx: S.fx }, o)); break;
      case 'nova': map.fx.push([p.x, p.y, 'f', S.fx, 0, S.radius]); for (const e of this.enemiesIn(p, p.x, p.y, S.radius)) this.dealDamage(p, e, S.mult, o); break;
      case 'dash': {
        p.iframe = now + 300; const sx = p.x, sy = p.y; [p.x, p.y] = this.stepMove(p, a, S.dist);
        map.fx.push([sx, sy, 'f', 'dash', Math.round(a * 100) / 100, Math.round(Math.hypot(p.x - sx, p.y - sy))]);
        for (const e of this.enemiesIn(p, p.x, p.y, S.radius)) this.dealDamage(p, e, S.mult, o);
        break;
      }
      case 'proj': {
        const n = S.count || 1;
        for (let i = 0; i < n; i++) { const aa = a + (n > 1 ? (i / (n - 1) - 0.5) * S.spread * 2 : 0); this.spawnProj(map, p, aa, Object.assign({ speed: S.speed, range: S.range, mult: S.mult, explode: S.explode, pierce: S.pierce, style: S.fx }, o)); }
        break;
      }
      case 'chain': {
        const hit = new Set(), pts = [Math.round(p.x), Math.round(p.y)]; let cur = chainT, mult = S.mult;
        for (let j = 0; j <= S.jumps && cur; j++) {
          hit.add(cur.id); pts.push(Math.round(cur.x), Math.round(cur.y)); this.dealDamage(p, cur, mult, o); mult *= 0.85;
          let nx = null, nd = 220 * 220; for (const e of this.enemiesIn(p, cur.x, cur.y, 220)) { if (hit.has(e.id)) continue; const dd = d2(e, cur); if (dd < nd) { nd = dd; nx = e; } }
          cur = nx;
        }
        map.fx.push([p.x, p.y, 'c', pts]); break;
      }
      case 'ground': {
        const d = Math.min(S.range, Math.hypot(tx - p.x, ty - p.y)), gx = p.x + Math.cos(a) * d, gy = p.y + Math.sin(a) * d;
        map.pend.push(Object.assign({ t: now + S.delay, x: gx, y: gy, r: S.radius, src: p, mult: S.mult, fx: S.fx, hostile: false }, o));
        map.fx.push([gx, gy, 'w', S.radius, S.delay, 0]); break;
      }
      case 'heal': {
        const amt = this.eff(p, 'matk') * S.mult + p.stats.hp * 0.05;
        for (const al of this.alliesIn(p, S.radius)) { this.heal(al, amt); map.fx.push([al.x, al.y, 'f', 'heal']); }
        break;
      }
      case 'blink': {
        if (blinkT) {
          const ba = Math.atan2(blinkT.y - p.y, blinkT.x - p.x), bx = blinkT.x + Math.cos(ba) * 30, by = blinkT.y + Math.sin(ba) * 30;
          map.fx.push([p.x, p.y, 'f', 'shadow']);
          if (!GD.hitBox(map, bx, by, 10) && this.placeOk(p, bx, by)) { p.x = bx; p.y = by; p.a = ba + Math.PI; }
          map.fx.push([p.x, p.y, 'f', 'shadow']);
          this.dealDamage(p, blinkT, S.mult, Object.assign({}, o, { critBonus: 25 }));
        } else {
          p.iframe = now + 300; map.fx.push([p.x, p.y, 'f', S.fx]);
          [p.x, p.y] = this.stepMove(p, S.back ? a + Math.PI : a, S.dist);
        }
        applyBuffs(); break;
      }
    }
    p.dirty.me = true;
  },
  spawnProj(map, src, a, o) {
    const id = nid();
    map.projs.push({ id, src, x: src.x, y: src.y, vx: Math.cos(a) * o.speed, vy: Math.sin(a) * o.speed, speed: o.speed, range: o.range, trav: 0, mult: o.mult, magic: o.magic, status: o.status, explode: o.explode, pierce: o.pierce, critBonus: o.critBonus, hit: new Set() });
    map.fx.push([Math.round(src.x), Math.round(src.y), 'p', id, o.style || 'arrow', Math.round(a * 100) / 100, o.speed, o.range]);
  },
  explode(pr, map) {
    map.fx.push([pr.x, pr.y, 'f', 'explosion', 0, pr.explode]);
    for (const e of this.enemiesIn(pr.src, pr.x, pr.y, pr.explode)) this.dealDamage(pr.src, e, pr.mult, { magic: pr.magic, status: pr.status, aoe: true });
  },
  updateProjectiles(map, dt) {
    for (let i = map.projs.length - 1; i >= 0; i--) {
      const pr = map.projs[i]; let done = false;
      const sub = Math.max(1, Math.ceil(pr.speed * dt / 14));
      for (let s = 0; s < sub && !done; s++) {
        pr.x += pr.vx * dt / sub; pr.y += pr.vy * dt / sub; pr.trav += pr.speed * dt / sub;
        if (pr.src.map !== map) { done = true; break; }
        if (pr.trav > pr.range || GD.solidAt(map, pr.x, pr.y)) { done = true; if (pr.explode) this.explode(pr, map); break; }
        for (const e of map.ents.values()) {
          if ((e.kind !== 'm' && e.kind !== 'p' && e.kind !== 'e') || pr.hit.has(e.id) || !this.canHarm(pr.src, e)) continue;
          const r = (e.size || 10) + 6;
          if ((e.x - pr.x) ** 2 + (e.y - pr.y) ** 2 <= r * r) {
            pr.hit.add(e.id);
            if (pr.explode) { this.explode(pr, map); done = true; break; }
            this.dealDamage(pr.src, e, pr.mult, pr);
            if (!pr.pierce) { done = true; break; }
          }
        }
      }
      if (done) { map.projs.splice(i, 1); map.fx.push([Math.round(pr.x), Math.round(pr.y), 'px', pr.id]); }
    }
  },
  updatePending(map, now) {
    for (let i = map.pend.length - 1; i >= 0; i--) {
      const pd = map.pend[i]; if (pd.t > now) continue;
      map.pend.splice(i, 1);
      const src = pd.src; if (!src || src.dead || src.map !== map) continue;
      if (pd.hostile) {
        if (pd.charge && !GD.hitBox(map, pd.x, pd.y, 14)) { src.x = pd.x; src.y = pd.y; }
        map.fx.push([pd.x, pd.y, 'f', 'slam', 0, pd.r]);
        for (const e of map.ents.values()) if ((e.kind === 'p' || e.kind === 'e') && !e.dead && (e.x - pd.x) ** 2 + (e.y - pd.y) ** 2 <= (pd.r + 10) ** 2) this.dealDamage(src, e, pd.mult, { magic: pd.magic, aoe: true });
      } else {
        map.fx.push([pd.x, pd.y, 'f', pd.fx || 'explosion', 0, pd.r]);
        for (const e of this.enemiesIn(src, pd.x, pd.y, pd.r)) this.dealDamage(src, e, pd.mult, { magic: pd.magic, status: pd.status, aoe: true });
      }
    }
  }
};
