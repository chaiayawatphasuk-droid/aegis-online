'use strict';
const GD = require('../../shared/data');
const { nid } = require('../entities/entities');
const d2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;
const int = (v, lo, hi) => (Number.isInteger(v) && v >= lo && v <= hi ? v : null);
const TYPE_ORDER = { equip: 0, potion: 1, material: 2, quest: 3 };

const H = {
  i(p, m) { // movement input
    let dx = Number(m.x) || 0, dy = Number(m.y) || 0; const l = Math.hypot(dx, dy);
    if (l > 1) { dx /= l; dy /= l; }
    p.input.dx = dx; p.input.dy = dy; p.input.run = m.r ? 1 : 0;
    if (typeof m.a === 'number' && isFinite(m.a)) p.a = m.a; else if (l > 0.1) p.a = Math.atan2(dy, dx);
  },
  a(p, m) { this.basicAttack(p, m); },
  s(p, m) { this.useSkill(p, m); },
  d(p, m, now) {
    if (p.dead || p.buffs.stun || (p.cds._d || 0) > now) return;
    let dx = Number(m.x) || 0, dy = Number(m.y) || 0, l = Math.hypot(dx, dy);
    if (l < 0.1) { dx = Math.cos(p.a); dy = Math.sin(p.a); l = 1; }
    p.cds._d = now + (p.cls === 'assassin' ? 800 : p.cls === 'ranger' ? 1000 : 1300);
    p.dash = { vx: dx / l * 560, vy: dy / l * 560, end: now + 250 }; p.iframe = now + 350; p.anim = 6; p.animT = now + 300; p.blocking = false;
    this.send(p, { t: 'cd', k: '_d', ms: p.cds._d - now });
  },
  b(p, m) { if (!p.dead) p.blocking = !!m.on; },
  pot(p, m, now) {
    if (p.dead || (p.cds._pot || 0) > now) return;
    const key = m.k === 'mp' ? 'mana' : 'heal'; let best = -1, bv = 0;
    p.inv.forEach((it, i) => { const d = it && GD.ITEMS[it.i]; if (d && d.type === 'potion' && (d[key] || 0) > bv) { bv = d[key]; best = i; } });
    if (best < 0) return this.msg(p, `No ${m.k === 'mp' ? 'mana' : 'healing'} potions!`, '#ff8a65');
    this.usePotion(p, best, now);
  },
  use(p, m, now) { const s = int(m.s, 0, 39); if (s === null || !p.inv[s] || p.dead) return; if (GD.ITEMS[p.inv[s].i].type === 'potion' && (p.cds._pot || 0) <= now) this.usePotion(p, s, now); else if (GD.ITEMS[p.inv[s].i].type === 'equip') H.eq.call(this, p, m); },
  eq(p, m) {
    const s = int(m.s, 0, 39); if (s === null) return; const it = p.inv[s]; if (!it) return;
    const d = GD.ITEMS[it.i]; if (d.type !== 'equip') return;
    if (d.cls && !d.cls.includes(p.cls)) return this.msg(p, `${GD.CLASSES[p.cls].name} cannot equip ${d.n}.`, '#ff8a65');
    if (d.lvl > p.lvl) return this.msg(p, `Requires level ${d.lvl}.`, '#ff8a65');
    const old = p.eq[d.slot] || null; p.eq[d.slot] = it; p.inv[s] = old;
    this.recalc(p); p.dirty.inv = true;
  },
  ue(p, m) {
    const sl = String(m.sl); if (!GD.SLOTS.includes(sl) || !p.eq[sl]) return;
    const f = p.inv.indexOf(null); if (f < 0) return this.msg(p, 'Inventory full!', '#ff8a65');
    p.inv[f] = p.eq[sl]; delete p.eq[sl]; this.recalc(p); p.dirty.inv = true;
  },
  drop(p, m) {
    const s = int(m.s, 0, 39); if (s === null || !p.inv[s]) return; const it = p.inv[s];
    if (GD.ITEMS[it.i].type === 'quest') return this.msg(p, 'Quest items cannot be dropped.');
    p.inv[s] = null; p.dirty.inv = true; this.spawnLoot(p.map, p.x, p.y, [it], null);
  },
  sort(p) {
    const items = p.inv.filter(Boolean), merged = [];
    for (const it of items) {
      const d = GD.ITEMS[it.i];
      if (d.stack > 1) { let rest = it.q; for (const mm of merged) if (mm.i === it.i && mm.q < d.stack) { const t = Math.min(rest, d.stack - mm.q); mm.q += t; rest -= t; } if (rest > 0) merged.push({ i: it.i, q: rest }); }
      else merged.push(it);
    }
    merged.sort((a, b) => { const da = GD.ITEMS[a.i], db = GD.ITEMS[b.i]; return (TYPE_ORDER[da.type] - TYPE_ORDER[db.type]) || ((b.r || 0) - (a.r || 0)) || (db.lvl - da.lvl) || (a.i < b.i ? -1 : 1); });
    p.inv = new Array(40).fill(null); merged.forEach((it, i) => p.inv[i] = it); p.dirty.inv = true;
  },
  sell(p, m) {
    const npc = this.npcNear(p, m.n, 'merchant'); if (!npc) return;
    const s = int(m.s, 0, 39); if (s === null || !p.inv[s]) return; const it = p.inv[s], d = GD.ITEMS[it.i];
    if (d.type === 'quest' || !d.price) return;
    const q = Math.min(it.q, int(m.q, 1, 999) || it.q);
    const val = Math.floor(d.price / 4 * (d.type === 'equip' ? 1 + (it.r || 0) * 0.5 + (it.u || 0) * 0.2 : 1)) * q;
    it.q -= q; if (it.q <= 0) p.inv[s] = null;
    p.gold += val; p.dirty.inv = p.dirty.me = true;
    this.db.log('sell', p.cid, null, { item: it.i, q, gold: val });
    this.msg(p, `Sold ${d.n}${q > 1 ? ' x' + q : ''} for ${val}g`, '#ffd34d');
  },
  buy(p, m) {
    const npc = this.npcNear(p, m.n, 'merchant'); if (!npc) return;
    const id = String(m.id), q = int(m.q, 1, 99) || 1, d = GD.ITEMS[id];
    if (!d || !GD.SHOPS[npc.shop].includes(id)) return;
    const qq = d.stack > 1 ? q : 1, cost = d.price * qq;
    if (p.gold < cost) return this.msg(p, 'Not enough gold.', '#ff8a65');
    if (!this.canAdd(p, id, qq)) return this.msg(p, 'Inventory full!', '#ff8a65');
    p.gold -= cost; this.addItem(p, GD.makeItem(id, qq, Math.random, -1));
    p.dirty.me = true; this.db.log('buy', p.cid, null, { item: id, q: qq, gold: cost });
    this.msg(p, `Bought ${d.n}${qq > 1 ? ' x' + qq : ''} for ${cost}g`, '#ffd34d');
  },
  craft(p, m) {
    if (!this.npcNear(p, m.n, 'blacksmith')) return;
    const r = GD.RECIPES[int(m.r, 0, GD.RECIPES.length - 1)]; if (!r) return;
    if (p.gold < r.gold) return this.msg(p, 'Not enough gold.', '#ff8a65');
    for (const [id, n] of r.mats) if (this.countItem(p, id) < n) return this.msg(p, `Missing ${GD.ITEMS[id].n} (${this.countItem(p, id)}/${n})`, '#ff8a65');
    if (!this.canAdd(p, r.out, 1)) return this.msg(p, 'Inventory full!', '#ff8a65');
    for (const [id, n] of r.mats) this.removeItem(p, id, n);
    p.gold -= r.gold;
    const it = GD.makeItem(r.out, 1, Math.random, 0.4); this.addItem(p, it);
    p.dirty.me = true; this.db.log('craft', p.cid, null, { out: r.out, r: it.r || 0 });
    this.msg(p, `Crafted ${GD.itemName(it)} [${GD.RARITY[it.r || 0].n}]`, GD.RARITY[it.r || 0].c);
    p.map.fx.push([p.x, p.y, 'f', 'buff']);
  },
  up(p, m) {
    if (!this.npcNear(p, m.n, 'blacksmith')) return;
    let it = null, eqd = false;
    if (typeof m.sl === 'string' && GD.SLOTS.includes(m.sl)) { it = p.eq[m.sl]; eqd = true; } else { const s = int(m.s, 0, 39); if (s !== null) it = p.inv[s]; }
    if (!it || GD.ITEMS[it.i].type !== 'equip') return;
    if ((it.u || 0) >= 10) return this.msg(p, 'Already at +10.');
    const c = GD.upgradeCost(it);
    if (p.gold < c.gold) return this.msg(p, 'Not enough gold.', '#ff8a65');
    if (this.countItem(p, 'iron_ore') < c.ore) return this.msg(p, `Need ${c.ore} Iron Ore.`, '#ff8a65');
    p.gold -= c.gold; this.removeItem(p, 'iron_ore', c.ore);
    const ok = Math.random() < c.chance;
    if (ok) { it.u = (it.u || 0) + 1; this.msg(p, `Upgrade success! ${GD.itemName(it)}`, '#9fe870'); p.map.fx.push([p.x, p.y, 'f', 'levelup']); }
    else this.msg(p, 'Upgrade failed. Materials were consumed.', '#ff8a65');
    if (eqd) this.recalc(p);
    p.dirty.inv = p.dirty.me = true; this.db.log('upgrade', p.cid, null, { item: it.i, u: it.u, ok });
  },
  heal(p, m) {
    if (!this.npcNear(p, m.n, 'healer')) return;
    p.hp = p.stats.hp; p.mp = p.stats.mp; p.buffs = {}; p.map.fx.push([p.x, p.y, 'f', 'heal']); this.msg(p, 'You feel restored.', '#9fe870');
  },
  qa(p, m) {
    if (!this.npcNear(p, m.n, 'quest')) return;
    const qid = String(m.q), q = GD.QUESTS[qid]; if (!q) return;
    if (p.quests.active[qid]) { if (q.obj.some(o => o.k === 'escort')) this.spawnEscort(p); return; }
    if (p.quests.done.includes(qid)) return;
    if (q.pre && !p.quests.done.includes(q.pre)) return this.msg(p, 'You must complete an earlier quest first.');
    if (p.lvl < q.lvl) return this.msg(p, `Requires level ${q.lvl}.`);
    if (Object.keys(p.quests.active).length >= 10) return this.msg(p, 'Quest log full (10).');
    p.quests.active[qid] = { p: q.obj.map(o => (o.k === 'explore' && p.zones.includes(o.z)) ? 1 : 0) };
    p.dirty.q = true; this.msg(p, `Quest accepted: ${q.n}`, '#7fd4ff');
    if (q.obj.some(o => o.k === 'escort')) this.spawnEscort(p);
  },
  qt(p, m) {
    if (!this.npcNear(p, m.n, 'quest')) return;
    const qid = String(m.q), q = GD.QUESTS[qid], st = p.quests.active[qid]; if (!q || !st) return;
    for (let i = 0; i < q.obj.length; i++) {
      const o = q.obj[i];
      if (o.k === 'collect') { if (this.countItem(p, o.i) < o.n) return this.msg(p, 'Objectives not complete.'); }
      else if ((st.p[i] || 0) < (o.n || 1)) return this.msg(p, 'Objectives not complete.');
    }
    for (const o of q.obj) if (o.k === 'collect') this.removeItem(p, o.i, o.n);
    delete p.quests.active[qid]; p.quests.done.push(qid);
    p.gold += q.rew.gold || 0;
    const over = [];
    for (const [id, n] of (q.rew.items || [])) { const it = GD.makeItem(id, n, Math.random, 0.6); const left = this.addItem(p, it); if (left) { it.q = left; over.push(it); } }
    if (over.length) this.spawnLoot(p.map, p.x, p.y, over, this.lootKey(p));
    this.gainExp(p, q.rew.exp || 0);
    p.dirty.q = p.dirty.me = true; p.map.fx.push([p.x, p.y, 'f', 'buff']);
    this.msg(p, `Quest complete: ${q.n}! +${q.rew.exp} EXP, +${q.rew.gold}g`, '#ffd34d');
    this.save(p);
  },
  qx(p, m) {
    const qid = String(m.q); if (!p.quests.active[qid]) return;
    delete p.quests.active[qid]; p.dirty.q = true;
    if (GD.QUESTS[qid].obj.some(o => o.k === 'escort') && p.escort) { const e = this.world.ents.get(p.escort); if (e) this.world.remove(e); p.escort = 0; }
    this.msg(p, 'Quest abandoned.');
  },
  al(p, m) { const k = String(m.k); if (!GD.ALLOC[k] || p.pts <= 0) return; const n = Math.min(p.pts, int(m.n, 1, 100) || 1); p.alloc[k] += n; p.pts -= n; this.recalc(p); },
  pvp(p, m, now) {
    if (now - p.combatT < 5000) return this.msg(p, 'Cannot change PvP flag during combat.', '#ff8a65');
    p.pvp = !!m.on; p.dirty.me = true; this.msg(p, p.pvp ? 'PvP ENABLED — you can fight flagged players inside the Crimson Arena zone.' : 'PvP disabled.', p.pvp ? '#ff6b6b' : '#9fe870');
  },
  tut(p) { p.tut = 1; },
  e(p) { // interact
    let best = null, bd = 90 * 90;
    for (const e of p.map.ents.values()) {
      if (e.kind !== 'n' && e.kind !== 'o' && e.kind !== 'l') continue;
      const dd = d2(e, p); if (dd < bd) { bd = dd; best = e; }
    }
    if (best) this.interact(p, best);
  },
  ie(p, m) { const e = p.map.ents.get(m.id); if (e && (e.kind === 'o' || e.kind === 'l' || e.kind === 'n') && d2(e, p) < 110 * 110) this.interact(p, e); },
  de(p, m) {
    const k = String(m.k); if (!GD.DUNGEONS[k]) return;
    const npcOk = this.npcNear(p, m.n, 'dungeon', true);
    const portalOk = [...p.map.ents.values()].some(e => e.kind === 'o' && e.st === 'portal' && e.dk === k && d2(e, p) < 140 * 140);
    if (!npcOk && !portalOk) return;
    this.enterDungeon(p, k);
  },
  dl(p) { if (p.map.kind === 'dungeon') this.leaveInstance(p); },
  aq(p, m) { this.queueArena(p, int(m.mode, 1, 3)); },
  aqx(p) { for (const k in this.queues) this.queues[k] = this.queues[k].filter(x => x !== p); this.msg(p, 'Left arena queue.'); this.send(p, { t: 'aq', mode: 0 }); },
  lb(p) { this.send(p, Object.assign({ t: 'lb' }, this.db.leaderboard())); }
};

module.exports = {
  H,
  handle(p, raw) {
    const now = Date.now();
    p.msgBudget = Math.min(60, p.msgBudget + (now - p.msgT) * 0.05); p.msgT = now;
    if (p.msgBudget < 1) return; p.msgBudget--;
    if (raw.length > 4000) return;
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m.t !== 'string') return;
    const h = H[m.t] || (this.SH && this.SH[m.t]);
    if (!h) return;
    try { h.call(this, p, m, now); } catch (e) { console.error('handler error', m.t, e); }
  },
  npcNear(p, id, role, silent) {
    const n = p.map.ents.get(id);
    if (!n || n.kind !== 'n' || n.role !== role || d2(n, p) > 200 * 200) { if (!silent) this.msg(p, 'Move closer to the NPC.', '#aaa'); return null; }
    return n;
  },
  interact(p, e) {
    const now = Date.now();
    if (e.kind === 'n') return this.send(p, { t: 'npc', id: e.id });
    if (e.kind === 'l') return this.takeLoot(p, e);
    if (e.st === 'res') {
      if (!e.avail) return this.msg(p, 'Already harvested. It will regrow soon.', '#aaa');
      const q = 1 + (Math.random() < 0.4 ? 1 : 0);
      if (this.addItem(p, GD.makeItem(e.item, q)) > 0) return this.msg(p, 'Inventory full!', '#ff8a65');
      e.avail = false; e.rT = now + 30000; e.ver++; p.anim = 3; p.animT = now + 400;
      this.msg(p, `Gathered ${GD.ITEMS[e.item].n} x${q}`, '#9fe870'); p.map.fx.push([e.x, e.y, 'f', 'gather']);
    } else if (e.st === 'chest') {
      if (e.dungeon) {
        if (e.opened.has(p.cid)) return this.msg(p, 'You already opened this chest.', '#aaa');
        e.opened.add(p.cid);
        const items = []; for (let i = 0; i < 2; i++) { const id = this.randomEquip(e.lvl, i === 0 ? p.cls : null); if (id) items.push(GD.makeItem(id, 1, Math.random, 1.2)); }
        items.push(GD.makeItem('hp_m', 3)); const g = 50 + e.lvl * 25; p.gold += g; p.dirty.me = true;
        this.spawnLoot(p.map, p.x, p.y, items, this.lootKey(p)); this.msg(p, `The reward chest grants ${g} gold!`, '#ffd34d');
      } else {
        if (e.open) return this.msg(p, 'This chest is empty.', '#aaa');
        e.open = true; e.rT = now + 300000; e.ver++;
        const g = 10 + Math.floor(Math.random() * e.lvl * 12); p.gold += g; p.dirty.me = true;
        const items = [GD.makeItem(Math.random() < 0.5 ? 'hp_s' : 'mp_s', 1 + Math.floor(Math.random() * 3))];
        if (Math.random() < 0.45) { const id = this.randomEquip(e.lvl, p.cls); if (id) items.push(GD.makeItem(id, 1, Math.random, 0.5)); }
        this.spawnLoot(p.map, e.x, e.y + 20, items, this.lootKey(p)); this.msg(p, `Opened a chest: +${g} gold`, '#ffd34d');
      }
      p.map.fx.push([e.x, e.y, 'f', 'buff']);
    } else if (e.st === 'portal') this.send(p, { t: 'portal', dk: e.dk });
    else if (e.st === 'exit') this.leaveInstance(p);
  },
  usePotion(p, s, now) {
    const it = p.inv[s], d = GD.ITEMS[it.i];
    if (d.heal) this.heal(p, d.heal); if (d.mana) p.mp = Math.min(p.stats.mp, p.mp + d.mana);
    it.q--; if (it.q <= 0) p.inv[s] = null;
    p.cds._pot = now + 800; p.dirty.inv = true; this.send(p, { t: 'cd', k: '_pot', ms: 800 });
    p.map.fx.push([p.x, p.y, 'f', d.mana && !d.heal ? 'mana' : 'heal']);
  },
  // ---- inventory helpers ----
  countItem(p, id) { let n = 0; for (const it of p.inv) if (it && it.i === id) n += it.q; return n; },
  removeItem(p, id, n) { for (let i = 0; i < p.inv.length && n > 0; i++) { const it = p.inv[i]; if (it && it.i === id) { const t = Math.min(n, it.q); it.q -= t; n -= t; if (it.q <= 0) p.inv[i] = null; } } p.dirty.inv = true; },
  canAdd(p, id, q) {
    const d = GD.ITEMS[id]; let room = 0;
    for (const it of p.inv) { if (!it) room += d.stack; else if (d.stack > 1 && it.i === id) room += d.stack - it.q; if (room >= q) return true; }
    return room >= q;
  },
  addItem(p, inst) {
    if (!inst) return 0; const d = GD.ITEMS[inst.i]; let q = inst.q || 1;
    if (d.stack > 1) for (const it of p.inv) if (it && it.i === inst.i && it.q < d.stack) { const t = Math.min(q, d.stack - it.q); it.q += t; q -= t; if (!q) break; }
    while (q > 0) {
      const f = p.inv.indexOf(null); if (f < 0) break;
      const t = Math.min(q, d.stack); p.inv[f] = d.stack > 1 ? { i: inst.i, q: t } : inst; q -= t;
    }
    p.dirty.inv = true; return q;
  },
  progressQuest(p, kind, key) {
    for (const qid in p.quests.active) {
      const q = GD.QUESTS[qid], st = p.quests.active[qid];
      q.obj.forEach((o, i) => {
        const match = (o.k === 'kill' && kind === 'kill' && o.m === key) || (o.k === 'explore' && kind === 'explore' && o.z === key) || (o.k === 'escort' && kind === 'escort');
        if (!match) return; const need = o.n || 1;
        if ((st.p[i] || 0) < need) { st.p[i] = (st.p[i] || 0) + 1; p.dirty.q = true; if (st.p[i] >= need) this.msg(p, `Objective complete: ${q.n}`, '#7fd4ff'); }
      });
    }
  }
};
