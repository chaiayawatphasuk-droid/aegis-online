'use strict';
const GD = require('../../shared/data');
const { nid } = require('../entities/entities');
const d2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;
const clean = (s, n) => String(s || '').replace(/[\u0000-\u001f\u007f<>]/g, '').trim().slice(0, n);

const SH = {
  // ---------- chat ----------
  c(p, m, now) {
    const text = clean(m.m, 200); if (!text) return;
    if (now - p.lastChat < 600) return this.msg(p, 'You are chatting too fast.', '#aaa');
    p.lastChat = now;
    const ch = ['say', 'g', 'p', 'G', 'w'].includes(m.ch) ? m.ch : 'say';
    const out = JSON.stringify({ t: 'chat', ch, f: p.name, m: text, id: p.id });
    if (ch === 'g') { for (const o of this.players.values()) o.sock.send(out); }
    else if (ch === 'say') { for (const o of p.map.players) if (d2(o, p) < 900 * 900) o.sock.send(out); }
    else if (ch === 'p') { if (!p.party) return this.msg(p, 'You are not in a party.'); for (const id of p.party.members) { const o = this.players.get(id); if (o) o.sock.send(out); } }
    else if (ch === 'G') { if (!p.gid) return this.msg(p, 'You are not in a guild.'); for (const o of this.players.values()) if (o.gid === p.gid) o.sock.send(out); }
    else if (ch === 'w') {
      const o = this.byName.get(clean(m.to, 20).toLowerCase()); if (!o) return this.msg(p, 'Player not online.');
      this.send(o, { t: 'chat', ch: 'w', f: p.name, m: text }); this.send(p, { t: 'chat', ch: 'w', f: `→ ${o.name}`, m: text });
    }
  },
  // ---------- party ----------
  pi(p, m) {
    const o = this.byName.get(clean(m.name, 20).toLowerCase());
    if (!o || o === p) return this.msg(p, 'Player not online.');
    if (o.party) return this.msg(p, `${o.name} is already in a party.`);
    if (p.party && p.party.leader !== p.id) return this.msg(p, 'Only the party leader can invite.');
    if (p.party && p.party.members.length >= 5) return this.msg(p, 'Party is full (5).');
    o.pinv = { from: p.id, t: Date.now() }; this.send(o, { t: 'pinv', from: p.name }); this.msg(p, `Party invite sent to ${o.name}.`);
  },
  pa(p) {
    const iv = p.pinv; p.pinv = null; if (!iv || Date.now() - iv.t > 60000 || p.party) return;
    const l = this.players.get(iv.from); if (!l) return this.msg(p, 'Invite expired.');
    if (!l.party) l.party = { id: nid(), leader: l.id, members: [l.id] };
    if (l.party.members.length >= 5) return this.msg(p, 'Party is full.');
    l.party.members.push(p.id); p.party = l.party;
    this.partyMsg(l.party, `${p.name} joined the party.`); this.sendParty(l.party);
  },
  pl(p) { this.partyLeave(p); },
  pk(p, m) {
    if (!p.party || p.party.leader !== p.id) return;
    const o = this.players.get(m.id); if (!o || o.party !== p.party || o === p) return;
    this.partyLeave(o); this.msg(o, 'You were removed from the party.');
  },
  // ---------- guild ----------
  gc(p, m) {
    if (!this.npcNear(p, m.n, 'guild')) return;
    if (p.gid) return this.msg(p, 'Leave your current guild first.');
    const name = clean(m.name, 20);
    if (!/^[A-Za-z0-9 ]{3,20}$/.test(name)) return this.msg(p, 'Guild name: 3-20 letters/numbers.');
    if (p.gold < 1000) return this.msg(p, 'Creating a guild costs 1000 gold.');
    let gid; try { gid = this.db.createGuild(name, p.cid); } catch { return this.msg(p, 'That guild name is taken.'); }
    p.gold -= 1000; p.gid = gid; p.grank = 'leader'; p.gname = name; p.ver = (p.ver || 0) + 1; p.dirty.me = true;
    this.db.log('guild_create', p.cid, null, { gid, name }); this.save(p);
    this.announce(`${p.name} founded the guild «${name}»!`); SH.ginfo.call(this, p);
  },
  gi(p, m) {
    if (!p.gid || !['leader', 'officer'].includes(p.grank)) return this.msg(p, 'Only guild leader/officers can invite.');
    const o = this.byName.get(clean(m.name, 20).toLowerCase()); if (!o || o === p) return this.msg(p, 'Player not online.');
    if (o.gid) return this.msg(p, `${o.name} is already in a guild.`);
    o.ginv = { gid: p.gid, t: Date.now() }; this.send(o, { t: 'ginv', from: p.name, g: p.gname }); this.msg(p, `Guild invite sent to ${o.name}.`);
  },
  ga(p) {
    const iv = p.ginv; p.ginv = null; if (!iv || Date.now() - iv.t > 60000 || p.gid) return;
    const g = this.guild(iv.gid); if (!g) return;
    if (this.db.members(g.id).length >= 20 + g.level * 5) return this.msg(p, 'Guild is full.');
    this.db.setMember(p.cid, g.id, 'member'); p.gid = g.id; p.grank = 'member'; p.gname = g.name; p.ver = (p.ver || 0) + 1; p.dirty.me = true;
    this.guildMsg(g.id, `${p.name} joined the guild!`); SH.ginfo.call(this, p);
  },
  gl(p) {
    if (!p.gid) return; const gid = p.gid, g = this.guild(gid);
    this.db.removeMember(p.cid);
    const rest = this.db.members(gid);
    if (!rest.length) { this.db.deleteGuild(gid); this.guilds.delete(gid); }
    else if (g && g.leader_id === p.cid) { const nl = rest[0]; g.leader_id = nl.id; this.db.setMember(nl.id, gid, 'leader'); g.dirty = true; this.db.saveGuild(g); const o = this.byCid.get(nl.id); if (o) o.grank = 'leader'; this.guildMsg(gid, `${nl.name} is the new guild leader.`); }
    p.gid = 0; p.grank = ''; p.gname = ''; p.ver = (p.ver || 0) + 1; p.dirty.me = true;
    this.msg(p, 'You left the guild.'); this.send(p, { t: 'guild', g: null });
  },
  gk(p, m) {
    if (!p.gid || p.grank !== 'leader') return;
    const cid = Number(m.cid); if (cid === p.cid) return;
    const mem = this.db.members(p.gid).find(x => x.id === cid); if (!mem) return;
    this.db.removeMember(cid); const o = this.byCid.get(cid);
    if (o) { o.gid = 0; o.grank = ''; o.gname = ''; o.ver = (o.ver || 0) + 1; o.dirty.me = true; this.msg(o, 'You were removed from the guild.'); this.send(o, { t: 'guild', g: null }); }
    this.guildMsg(p.gid, `${mem.name} was removed from the guild.`); SH.ginfo.call(this, p);
  },
  gp(p, m) { // promote/demote officer
    if (!p.gid || p.grank !== 'leader') return;
    const cid = Number(m.cid), mem = this.db.members(p.gid).find(x => x.id === cid); if (!mem || mem.rank === 'leader') return;
    const r = mem.rank === 'officer' ? 'member' : 'officer'; this.db.setMember(cid, p.gid, r);
    const o = this.byCid.get(cid); if (o) { o.grank = r; o.dirty.me = true; }
    SH.ginfo.call(this, p);
  },
  gd(p, m) {
    if (!p.gid) return; const g = this.guild(p.gid); const s = Number.isInteger(m.s) ? m.s : -1; const it = p.inv[s]; if (!g || !it) return;
    if (GD.ITEMS[it.i].type === 'quest') return;
    if (g.storage.length >= 20 + g.level * 5) return this.msg(p, 'Guild storage is full.');
    p.inv[s] = null; g.storage.push(it); g.dirty = true; this.db.saveGuild(g); p.dirty.inv = true;
    this.db.log('guild_deposit', p.cid, null, { gid: g.id, item: it }); this.save(p); SH.ginfo.call(this, p);
  },
  gw(p, m) {
    if (!p.gid) return; const g = this.guild(p.gid); if (!g) return;
    const i = Number.isInteger(m.i) ? m.i : -1; const it = g.storage[i]; if (!it) return;
    if (!this.canAdd(p, it.i, it.q)) return this.msg(p, 'Inventory full!');
    g.storage.splice(i, 1); this.addItem(p, it); g.dirty = true; this.db.saveGuild(g);
    this.db.log('guild_withdraw', null, p.cid, { gid: g.id, item: it }); this.save(p); SH.ginfo.call(this, p);
  },
  ginfo(p) {
    if (!p.gid) return this.send(p, { t: 'guild', g: null });
    const g = this.guild(p.gid); if (!g) return;
    const members = this.db.members(g.id).map(x => Object.assign(x, { online: this.byCid.has(x.id) }));
    this.send(p, { t: 'guild', g: { id: g.id, name: g.name, level: g.level, exp: g.exp, next: g.level * g.level * 2000, cap: 20 + g.level * 5, storage: g.storage, members, rank: p.grank } });
  },
  // ---------- friends ----------
  fa(p, m) {
    const c = this.db.charByName(clean(m.name, 20)); if (!c || c.id === p.cid) return this.msg(p, 'Character not found.');
    this.db.addFriend(p.cid, c.id); this.msg(p, `${c.name} added to friends.`); SH.fl.call(this, p);
  },
  fr(p, m) { this.db.delFriend(p.cid, Number(m.cid)); SH.fl.call(this, p); },
  fl(p) { this.send(p, { t: 'friends', l: this.db.friends(p.cid).map(f => Object.assign(f, { online: this.byCid.has(f.id) })) }); },
  // ---------- trade ----------
  tr(p, m) {
    const o = this.byName.get(clean(m.name, 20).toLowerCase());
    if (!o || o === p) return this.msg(p, 'Player not online.');
    if (o.map !== p.map || d2(o, p) > 300 * 300) return this.msg(p, 'Too far away to trade.');
    if (p.trade || o.trade) return this.msg(p, 'Already trading.');
    o.tinv = { from: p.id, t: Date.now() }; this.send(o, { t: 'treq', from: p.name }); this.msg(p, `Trade request sent to ${o.name}.`);
  },
  ta(p) {
    const iv = p.tinv; p.tinv = null; if (!iv || Date.now() - iv.t > 60000) return;
    const o = this.players.get(iv.from); if (!o || o.trade || p.trade || o.map !== p.map || d2(o, p) > 300 * 300) return this.msg(p, 'Trade unavailable.');
    const tr = { a: o, b: p, off: new Map([[o, { s: [], g: 0 }], [p, { s: [], g: 0 }]]), ok: new Set() };
    o.trade = p.trade = tr; this.sendTrade(tr);
  },
  to(p, m) {
    const tr = p.trade; if (!tr) return; const s = Number.isInteger(m.s) ? m.s : -1; const it = p.inv[s]; if (!it) return;
    if (GD.ITEMS[it.i].type === 'quest') return this.msg(p, 'Quest items cannot be traded.');
    const off = tr.off.get(p), idx = off.s.findIndex(x => x.slot === s);
    if (idx >= 0) off.s.splice(idx, 1); else { if (off.s.length >= 8) return; off.s.push({ slot: s, ref: it }); }
    tr.ok.clear(); this.sendTrade(tr);
  },
  tg(p, m) { const tr = p.trade; if (!tr) return; const g = Math.max(0, Math.min(p.gold, Math.floor(Number(m.g) || 0))); tr.off.get(p).g = g; tr.ok.clear(); this.sendTrade(tr); },
  tc(p) { const tr = p.trade; if (!tr) return; tr.ok.add(p); if (tr.ok.size === 2) this.execTrade(tr); else this.sendTrade(tr); },
  tx(p) { this.cancelTrade(p, 'Trade cancelled.'); }
};

module.exports = {
  SH,
  partyMsg(party, text) { for (const id of party.members) { const o = this.players.get(id); if (o) this.msg(o, text, '#8fe0ff'); } },
  sendParty(party) {
    const m = party.members.map(id => this.players.get(id)).filter(Boolean).map(o => ({ id: o.id, n: o.name, c: o.cls, lv: o.lvl, hp: Math.ceil(o.hp), mhp: o.stats.hp, mp: Math.floor(o.mp), mmp: o.stats.mp, map: o.map ? o.map.id : '', x: Math.round(o.x), y: Math.round(o.y), dead: o.dead }));
    for (const id of party.members) { const o = this.players.get(id); if (o) this.send(o, { t: 'party', leader: party.leader, m }); }
  },
  partyLeave(p, quiet) {
    const party = p.party; if (!party) return;
    party.members = party.members.filter(id => id !== p.id); p.party = null;
    if (!quiet || true) this.send(p, { t: 'party', m: [] });
    if (party.members.length <= 1) {
      for (const id of party.members) { const o = this.players.get(id); if (o) { o.party = null; this.send(o, { t: 'party', m: [] }); this.msg(o, 'Party disbanded.'); } }
      return;
    }
    if (party.leader === p.id) party.leader = party.members[0];
    this.partyMsg(party, `${p.name} left the party.`); this.sendParty(party);
  },
  guild(id) {
    if (this.guilds.has(id)) return this.guilds.get(id);
    const g = this.db.guild(id); if (g) this.guilds.set(id, g); return g;
  },
  guildMsg(gid, text) { for (const o of this.players.values()) if (o.gid === gid) this.msg(o, text, '#7fe0a0'); },
  guildExp(gid, amt) {
    const g = this.guild(gid); if (!g) return;
    g.exp += amt; g.dirty = true;
    while (g.exp >= g.level * g.level * 2000) { g.exp -= g.level * g.level * 2000; g.level++; this.guildMsg(gid, `Guild «${g.name}» reached level ${g.level}! Storage expanded.`); }
  },
  notifyFriends(p, online) {
    try { for (const f of this.db.friends(p.cid)) { const o = this.byCid.get(f.id); if (o && this.db.friends(o.cid).some(x => x.id === p.cid)) this.msg(o, `${p.name} is now ${online ? 'online' : 'offline'}.`, '#aaa'); } } catch { }
  },
  sendTrade(tr) {
    for (const me of [tr.a, tr.b]) {
      const them = me === tr.a ? tr.b : tr.a, mo = tr.off.get(me), to = tr.off.get(them);
      this.send(me, { t: 'trade', name: them.name, me: { s: mo.s.map(x => x.slot), g: mo.g, ok: tr.ok.has(me) }, them: { items: to.s.map(x => x.ref), g: to.g, ok: tr.ok.has(them) } });
    }
  },
  cancelTrade(p, why) {
    const tr = p.trade; if (!tr) return;
    tr.a.trade = tr.b.trade = null;
    for (const o of [tr.a, tr.b]) { this.send(o, { t: 'trade', close: 1 }); if (why) this.msg(o, why, '#aaa'); }
  },
  execTrade(tr) {
    const { a, b } = tr, oa = tr.off.get(a), ob = tr.off.get(b);
    const valid = (p, off) => off.g <= p.gold && off.s.every(x => p.inv[x.slot] === x.ref);
    if (!valid(a, oa) || !valid(b, ob)) return this.cancelTrade(a, 'Trade failed: offer changed.');
    const free = (p, off) => p.inv.filter(x => !x).length + off.s.length;
    if (free(a, oa) < ob.s.length || free(b, ob) < oa.s.length) return this.cancelTrade(a, 'Trade failed: not enough inventory space.');
    const ia = oa.s.map(x => x.ref), ib = ob.s.map(x => x.ref);
    oa.s.forEach(x => a.inv[x.slot] = null); ob.s.forEach(x => b.inv[x.slot] = null);
    ib.forEach(it => this.addItem(a, it)); ia.forEach(it => this.addItem(b, it));
    a.gold += ob.g - oa.g; b.gold += oa.g - ob.g;
    a.dirty.me = b.dirty.me = a.dirty.inv = b.dirty.inv = true;
    this.db.log('trade', a.cid, b.cid, { aGave: ia, aGold: oa.g, bGave: ib, bGold: ob.g });
    this.save(a); this.save(b);
    a.trade = b.trade = null;
    for (const o of [a, b]) { this.send(o, { t: 'trade', close: 1 }); this.msg(o, 'Trade completed!', '#9fe870'); }
  }
};
