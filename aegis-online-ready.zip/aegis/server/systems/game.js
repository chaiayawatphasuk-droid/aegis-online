'use strict';
const GD = require('../../shared/data');
const { nid, createPlayer, serializePlayer, createMonster } = require('../entities/entities');
const TICK = 50, TILE = GD.TILE;
const d2 = (a, b) => (a.x - b.x) ** 2 + (a.y - b.y) ** 2;

class GameMap {
  constructor(id, kind, m) {
    this.id = id; this.kind = kind; this.w = m.w; this.h = m.h; this.tiles = m.tiles; this.zone = m.zone || null;
    this.ents = new Map(); this.players = new Set(); this.projs = []; this.pend = []; this.fx = []; this.emptyT = 0; this.meta = {};
  }
  add(e) { e.map = this; this.ents.set(e.id, e); if (e.kind === 'p') this.players.add(e); }
  remove(e) { this.ents.delete(e.id); if (e.kind === 'p') this.players.delete(e); }
}

class Game {
  constructor(db) {
    this.db = db; this.players = new Map(); this.byCid = new Map(); this.byName = new Map(); this.maps = new Map(); this.guilds = new Map();
    this.world = new GameMap('world', 'world', GD.buildWorld()); this.maps.set('world', this.world);
    this.queues = { 1: [], 2: [], 3: [] }; this.instSeq = 1; this.tickN = 0; this.eventT = Date.now() + 8 * 60000; this.eventEnd = 0;
    this.populateWorld();
    this.timer = setInterval(() => { try { this.tick(); } catch (e) { console.error('tick error', e); } }, TICK);
  }

  // ---------------- world setup ----------------
  randomSpot(map, zi, cx, cy, rad, tries = 300) {
    for (let i = 0; i < tries; i++) {
      const a = Math.random() * Math.PI * 2, r = Math.sqrt(Math.random()) * rad;
      const tx = Math.floor(cx + Math.cos(a) * r), ty = Math.floor(cy + Math.sin(a) * r);
      if (tx < 3 || ty < 3 || tx >= map.w - 3 || ty >= map.h - 3) continue;
      const idx = ty * map.w + tx;
      if (GD.SOLID[map.tiles[idx]]) continue;
      if (zi >= 0 && map.zone && map.zone[idx] !== zi) continue;
      const x = (tx + 0.5) * TILE, y = (ty + 0.5) * TILE;
      if (GD.hitBox(map, x, y, 14)) continue;
      return [x, y];
    }
    return null;
  }
  populateWorld() {
    const w = this.world;
    for (const n of GD.NPCS) w.add({ id: nid(), kind: 'n', nid: n.id, n: n.n, role: n.role, shop: n.shop, col: n.col, x: (n.x + 0.5) * TILE, y: (n.y + 0.5) * TILE, a: Math.PI / 2, ver: 0 });
    GD.ZONES.forEach((z, zi) => {
      const isPlains = z.id === 'plains', cx = isPlains ? 128 : z.x, cy = isPlains ? 128 : z.y, rad = isPlains ? 62 : z.r;
      for (const [mid, cnt] of (GD.ZONE_SPAWNS[z.id] || [])) for (let i = 0; i < cnt; i++) {
        const s = this.randomSpot(w, zi, cx, cy, rad); if (!s) continue;
        w.add(createMonster(mid, s[0], s[1], GD.MONSTERS[mid].lvl + Math.floor(Math.random() * 3)));
      }
      if (GD.ZONE_RES[z.id]) for (let i = 0; i < 12; i++) { const s = this.randomSpot(w, zi, cx, cy, rad); if (s) w.add({ id: nid(), kind: 'o', st: 'res', item: GD.ZONE_RES[z.id], avail: true, rT: 0, x: s[0], y: s[1], ver: 0 }); }
      if (!z.safe && !z.pvp) for (let i = 0; i < (isPlains ? 6 : 4); i++) { const s = this.randomSpot(w, zi, cx, cy, rad); if (s) w.add({ id: nid(), kind: 'o', st: 'chest', open: false, rT: 0, lvl: z.lvl[1], x: s[0], y: s[1], ver: 0 }); }
    });
    for (const k in GD.DUNGEONS) { const e = GD.DUNGEONS[k].entrance; w.add({ id: nid(), kind: 'o', st: 'portal', dk: k, x: (e[0] + 0.5) * TILE, y: (e[1] + 0.5) * TILE, ver: 0 }); }
    const g = GD.ZONES[GD.ZONE_IDX.grove];
    w.add(createMonster('elderbark', (g.x + 0.5) * TILE, (g.y + 0.5) * TILE, 0, { respawn: 180000, leash: 900 }));
  }

  // ---------------- connection ----------------
  send(p, o) { if (p.sock && p.sock.open) p.sock.send(JSON.stringify(o)); }
  msg(p, text, col) { this.send(p, { t: 'm', m: text, c: col || '' }); }
  broadcast(o) { const s = JSON.stringify(o); for (const p of this.players.values()) if (p.sock.open) p.sock.send(s); }
  announce(text) { this.broadcast({ t: 'm', m: text, c: '#ffd34d' }); }

  join(sock, uid, cid) {
    const loaded = this.db.loadChar(cid);
    if (!loaded || loaded.row.user_id !== uid) { sock.send(JSON.stringify({ t: 'err', m: 'Character not found' })); sock.close(4004); return null; }
    const old = this.byCid.get(cid);
    if (old) { this.send(old, { t: 'err', m: 'Logged in from another session' }); this.leave(old); old.sock.close(4001); }
    const p = createPlayer(sock, uid, loaded);
    if (p.gid) { const g = this.guild(p.gid); if (g) p.gname = g.name; else p.gid = 0; }
    this.players.set(p.id, p); this.byCid.set(p.cid, p); this.byName.set(p.name.toLowerCase(), p);
    let x = p.x, y = p.y;
    if (GD.hitBox(this.world, x, y, 10)) { x = 128.5 * TILE; y = 128.5 * TILE; }
    this.send(p, { t: 'init', id: p.id, cid: p.cid, name: p.name, cls: p.cls, app: p.app, tut: p.tut });
    this.changeMap(p, this.world, x, y);
    this.msg(p, `Welcome to Aegis Online, ${p.name}!`, '#9fe870');
    this.notifyFriends(p, true);
    return p;
  }
  leave(p) {
    if (!this.players.has(p.id)) return;
    try {
      this.cancelTrade(p, 'Trade cancelled (player left)');
      this.partyLeave(p, true);
      for (const k in this.queues) this.queues[k] = this.queues[k].filter(x => x !== p);
      if (p.escort) { const e = this.world.ents.get(p.escort); if (e) this.world.remove(e); }
      if (p.map && p.map.kind === 'arena' && !p.map.meta.done) { p.dead = true; this.arenaCheck(p.map); }
      this.save(p);
    } catch (e) { console.error('leave error', e); }
    if (p.map) { this.dropAggro(p); p.map.remove(p); }
    this.players.delete(p.id); this.byCid.delete(p.cid); this.byName.delete(p.name.toLowerCase());
    this.notifyFriends(p, false);
  }
  save(p) {
    try { this.db.saveChar(serializePlayer(p)); p.lastSave = Date.now(); } catch (e) { console.error('save failed', p.name, e); }
  }
  saveAll() { for (const p of this.players.values()) this.save(p); for (const g of this.guilds.values()) if (g.dirty) { this.db.saveGuild(g); g.dirty = false; } }

  changeMap(p, map, x, y) {
    if (p.map) { this.dropAggro(p); p.map.remove(p); }
    if (p.trade) this.cancelTrade(p, 'Trade cancelled');
    p.x = x; p.y = y; p.dash = null; map.add(p); p.known.clear(); p.zone = -1;
    const info = { t: 'map', id: map.id, kind: map.kind, w: map.w, h: map.h, name: map.meta.name || '' };
    if (map.kind !== 'world') info.tiles = Buffer.from(map.tiles).toString('base64');
    this.send(p, info);
    p.dirty.me = p.dirty.inv = p.dirty.q = true;
  }

  // ---------------- main loop ----------------
  tick() {
    const now = Date.now(), dt = TICK / 1000; this.tickN++;
    for (const m of this.maps.values()) {
      if (m.kind !== 'world') {
        if (m.players.size === 0) { if (!m.emptyT) m.emptyT = now; else if (now - m.emptyT > 60000) { this.maps.delete(m.id); continue; } }
        else m.emptyT = 0;
      }
      for (const p of m.players) this.updatePlayer(p, dt, now);
      for (const e of m.ents.values()) {
        if (e.kind === 'm') this.updateMonster(e, dt, now, m);
        else if (e.kind === 'e') this.updateEscort(e, dt, now);
        else if (e.kind === 'l' && now > e.exp) m.remove(e);
        else if (e.kind === 'o' && e.rT && now > e.rT) { e.rT = 0; e.avail = true; e.open = false; e.ver++; }
      }
      this.updateProjectiles(m, dt, now);
      this.updatePending(m, now);
      if (m.kind === 'arena') this.updateArena(m, now);
    }
    if (this.tickN % 2 === 0) for (const p of this.players.values()) this.sendSnapshot(p);
    for (const m of this.maps.values()) this.flushFx(m);
    if (this.tickN % 20 === 0) this.secondTick(now);
  }

  updatePlayer(p, dt, now) {
    if (p.dead) { if (now - p.deadT > 5000 && p.map.kind !== 'arena') this.respawn(p); return; }
    for (const k in p.buffs) if (p.buffs[k].until < now) { delete p.buffs[k]; p.dirty.me = true; }
    if (p.sh > 0 && now > p.shT) p.sh = 0;
    let vx = 0, vy = 0;
    if (p.dash) { if (now > p.dash.end) p.dash = null; else { vx = p.dash.vx; vy = p.dash.vy; } }
    if (!p.dash && !p.buffs.stun) {
      let sp = p.stats.spd * (p.input.run ? 1 : 0.55);
      if (p.blocking) sp *= 0.45; if (p.buffs.haste) sp *= p.buffs.haste.v; if (p.buffs.slow) sp *= 0.6;
      vx = p.input.dx * sp; vy = p.input.dy * sp;
    }
    if (vx || vy) {
      const [rx, ry] = GD.tryMove(p.map, p.x, p.y, p.x + vx * dt, p.y + vy * dt, 10);
      if (this.placeOk(p, rx, ry)) { p.x = rx; p.y = ry; }
      if (now > p.animT) p.anim = 1;
    } else if (now > p.animT) p.anim = p.blocking ? 4 : 0;
    if (p.blocking && now > p.animT) p.anim = 4;
    if (this.tickN % 4 === 0) this.autoLoot(p, now);
  }
  placeOk(p, x, y) {
    if (p.map.kind !== 'world') return true;
    const z = GD.ZONES[GD.zoneAt(p.map, x, y)];
    if (z.req > p.lvl) { const now = Date.now(); if (now - p.lastWarn > 3000) { p.lastWarn = now; this.msg(p, `${z.name} requires level ${z.req}.`, '#ff8a65'); } return false; }
    return true;
  }
  respawn(p) {
    p.dead = false; p.hp = p.stats.hp; p.mp = p.stats.mp; p.buffs = {}; p.anim = 0; p.sh = 0; p.dirty.me = true;
    if (p.map.kind === 'dungeon') { const s = p.map.meta.spawn; p.x = s[0]; p.y = s[1]; }
    else {
      const t = GD.ZONES[0], c = GD.ZONES[1];
      const dt2 = (p.x / TILE - t.x) ** 2 + (p.y / TILE - t.y) ** 2, dc2 = (p.x / TILE - c.x) ** 2 + (p.y / TILE - c.y) ** 2;
      const z = dc2 < dt2 ? c : t; p.x = (z.x + 0.5) * TILE; p.y = (z.y + 2.5) * TILE;
    }
    this.send(p, { t: 'respawn' });
  }

  secondTick(now) {
    for (const p of this.players.values()) {
      if (!p.dead) {
        const zi = p.map.kind === 'world' ? GD.zoneAt(p.map, p.x, p.y) : -1;
        if (zi !== p.zone) {
          p.zone = zi;
          if (zi >= 0) {
            const z = GD.ZONES[zi];
            this.send(p, { t: 'zone', z: zi });
            if (!p.zones.includes(z.id)) { p.zones.push(z.id); p.cnt.zones = p.zones.length; this.msg(p, `Discovered: ${z.name}`, '#7fd4ff'); this.checkFeats(p); }
            this.progressQuest(p, 'explore', z.id);
          } else this.send(p, { t: 'zone', z: -1 });
        }
        const safe = zi >= 0 && GD.ZONES[zi].safe, inCombat = now - p.combatT < 5000;
        const hr = safe ? 0.06 : inCombat ? 0.004 : 0.025, mr = safe ? 0.08 : inCombat ? 0.012 : 0.04;
        p.hp = Math.min(p.stats.hp, p.hp + p.stats.hp * hr); p.mp = Math.min(p.stats.mp, p.mp + p.stats.mp * mr);
        this.applyDots(p, now);
      }
      if (p.party && p.party.leader === p.id) this.sendParty(p.party);
      if (p.trade) { const o = p.trade.a === p ? p.trade.b : p.trade.a; if (o.map !== p.map || d2(o, p) > 450 * 450) this.cancelTrade(p, 'Trade cancelled (too far)'); }
      if (now - p.lastSave > 30000) this.save(p);
    }
    for (const m of this.maps.values()) for (const e of m.ents.values()) if (e.kind === 'm' && !e.dead) {
      if (m.kind === 'world') { let act = false; for (const p of m.players) if (d2(p, e) < 1500 * 1500) { act = true; break; } e.active = act; } else e.active = true;
      if (e.active) this.applyDots(e, now);
      if (e.expire && now > e.expire) m.remove(e);
    }
    if (now > this.eventT) this.worldEvent(now);
    if (this.tickN % 600 === 0) for (const g of this.guilds.values()) if (g.dirty) { this.db.saveGuild(g); g.dirty = false; }
  }
  worldEvent(now) {
    this.eventT = now + 15 * 60000;
    let n = 0;
    for (let i = 0; i < 14; i++) {
      const s = this.randomSpot(this.world, GD.ZONE_IDX.plains, 128, 128, 45); if (!s) continue;
      this.world.add(createMonster('slime_gold', s[0], s[1], 0, { respawn: 0, temp: true, expire: now + 4 * 60000, passive: true })); n++;
    }
    this.announce(`★ World Event: ${n} Gilded Slimes have appeared in Meadowlight Plains for 4 minutes! Bonus EXP & gold!`);
  }

  // ---------------- snapshots ----------------
  describe(e) {
    if (e.kind === 'p') return { id: e.id, k: 'p', n: e.name, lv: e.lvl, c: e.cls, ap: e.app, g: e.gname, v: e.ver || 0 };
    if (e.kind === 'm') return { id: e.id, k: 'm', m: e.mid, lv: e.lvl, v: 0 };
    if (e.kind === 'n') return { id: e.id, k: 'n', n: e.n, role: e.role, nid: e.nid, col: e.col, shop: e.shop, x: e.x, y: e.y, v: 0 };
    if (e.kind === 'o') return { id: e.id, k: 'o', st: e.st, item: e.item, avail: e.avail, open: e.open, dk: e.dk, x: e.x, y: e.y, v: e.ver };
    if (e.kind === 'l') return { id: e.id, k: 'l', x: e.x, y: e.y, v: 0 };
    if (e.kind === 'e') return { id: e.id, k: 'e', n: e.n, v: 0 };
  }
  flags(e) {
    const b = e.buffs || {}; let f = 0;
    if (e.blocking) f |= 1; if (e.sh > 0) f |= 2; if (e.pvp) f |= 4; if (e.dead) f |= 8; if (b.stun) f |= 16; if (b.poison || b.burn) f |= 32;
    if (b.def_up || b.atk_up || b.reflect_up || b.fortress || b.haste) f |= 64; if (b.slow) f |= 128; if (b.vanish) f |= 256; if (e.d && e.d.boss) f |= 512; if (b.taunt) f |= 1024;
    if (e.team) f |= e.team === 1 ? 2048 : 4096;
    return f;
  }
  sendSnapshot(p) {
    const m = p.map, V2 = GD.VIEW * GD.VIEW, out = [], adds = [], seen = new Set();
    for (const e of m.ents.values()) {
      if (e === p || (e.kind === 'm' && e.dead)) continue;
      const dx = e.x - p.x, dy = e.y - p.y; if (dx * dx + dy * dy > V2) continue;
      seen.add(e.id);
      const v = e.ver || 0;
      if (p.known.get(e.id) !== v) { p.known.set(e.id, v); adds.push(this.describe(e)); }
      if (e.kind === 'p' || e.kind === 'm' || e.kind === 'e') out.push([e.id, Math.round(e.x), Math.round(e.y), Math.round(e.a * 100) / 100, Math.ceil(e.hp), e.kind === 'p' ? e.stats.hp : e.mhp, e.anim, this.flags(e)]);
    }
    const rm = []; for (const id of p.known.keys()) if (!seen.has(id)) { p.known.delete(id); rm.push(id); }
    const s = { t: 's', me: [Math.round(p.x), Math.round(p.y), Math.ceil(p.hp), p.stats.hp, Math.floor(p.mp), p.stats.mp, Math.round(p.sh), p.anim, this.flags(p)], e: out };
    if (adds.length) s.a = adds; if (rm.length) s.r = rm;
    this.send(p, s);
    if (p.dirty.me) this.sendMe(p); if (p.dirty.inv) this.sendInv(p); if (p.dirty.q) this.sendQuests(p);
  }
  sendMe(p) {
    p.dirty.me = false; const now = Date.now();
    this.send(p, {
      t: 'me', lv: p.lvl, exp: p.exp, nx: GD.expToNext(p.lvl), gold: p.gold, st: p.stats, al: p.alloc, pts: p.pts, feats: p.feats, cnt: p.cnt,
      pvp: p.pvp, rating: p.rating, wins: p.wins, losses: p.losses, gname: p.gname, grank: p.grank, zones: p.zones,
      buffs: Object.keys(p.buffs).map(k => [k, p.buffs[k].until - now])
    });
  }
  sendInv(p) { p.dirty.inv = false; this.send(p, { t: 'inv', inv: p.inv, eq: p.eq }); }
  sendQuests(p) { p.dirty.q = false; this.send(p, { t: 'q', a: p.quests.active, d: p.quests.done }); }
  flushFx(m) {
    if (!m.fx.length) return;
    const V2 = GD.VIEW * GD.VIEW * 1.2;
    for (const p of m.players) {
      const l = m.kind === 'world' ? m.fx.filter(f => (f[0] - p.x) ** 2 + (f[1] - p.y) ** 2 < V2) : m.fx;
      if (l.length) this.send(p, { t: 'f', l });
    }
    m.fx = [];
  }

  // ---------------- monsters ----------------
  validTarget(m, e) {
    if (!e || e.dead || e.map !== m.map) return false;
    if (e.kind === 'p') { if (e.buffs.vanish) return false; if (m.map.kind === 'world' && e.zone >= 0 && GD.ZONES[e.zone].safe) return false; }
    return e.kind === 'p' || e.kind === 'e';
  }
  findTarget(m, map) {
    if (m.passive) return null;
    const R = m.d.boss ? 380 : 190; let best = null, bd = R * R;
    for (const e of map.ents.values()) {
      if (e.kind !== 'p' && e.kind !== 'e') continue;
      const dd = d2(e, m); if (dd < bd && this.validTarget(m, e)) { bd = dd; best = e; }
    }
    return best;
  }
  pickTarget(m, map) {
    const now = Date.now();
    if (m.buffs.taunt) { const t = map.ents.get(m.buffs.taunt.v); if (this.validTarget(m, t)) return t; }
    let best = null, bv = -1;
    for (const [id, v] of m.threat) { const t = map.ents.get(id); if (!this.validTarget(m, t)) { m.threat.delete(id); continue; } if (v > bv) { bv = v; best = t; } }
    if (!best) { best = this.findTarget(m, map); if (best) m.threat.set(best.id, 1); }
    if (best) m.target = best.id;
    return best;
  }
  moveToward(e, tx, ty, spd, dt, map) {
    const dx = tx - e.x, dy = ty - e.y, d = Math.hypot(dx, dy); if (d < 4) return false;
    const st = Math.min(d, spd * dt), nx = e.x + dx / d * st, ny = e.y + dy / d * st;
    const [rx, ry] = GD.tryMove(map, e.x, e.y, nx, ny, Math.min(14, e.size || 10));
    if (map.kind === 'world' && e.kind === 'm') { const z = GD.ZONES[GD.zoneAt(map, rx, ry)]; if (z.safe) return false; }
    e.x = rx; e.y = ry; e.a = Math.atan2(dy, dx);
    if (Date.now() > e.animT) e.anim = 1;
    return true;
  }
  updateMonster(m, dt, now, map) {
    if (m.dead) { if (m.respawnT && now >= m.respawnT) this.respawnMonster(m); return; }
    if (map.kind === 'world' && !m.active && m.state === 'idle') return;
    for (const k in m.buffs) if (m.buffs[k].until < now) delete m.buffs[k];
    if (m.buffs.stun) { m.anim = 0; return; }
    const spd = m.st.spd * (m.buffs.slow ? 0.55 : 1);
    if (m.d.boss) this.bossThink(m, now, map);
    if (now > m.animT && m.state !== 'chase') m.anim = 0;
    const leash = m.leash || (map.kind === 'world' ? 650 : 1600);
    switch (m.state) {
      case 'idle': {
        const t = this.findTarget(m, map);
        if (t) { m.state = 'chase'; m.target = t.id; m.threat.set(t.id, 1); break; }
        if (now > m.wT) { m.wT = now + 3000 + Math.random() * 4000; const a = Math.random() * 6.283, r = Math.random() * (m.d.boss ? 60 : 110); m.px = m.hx + Math.cos(a) * r; m.py = m.hy + Math.sin(a) * r; }
        if (!this.moveToward(m, m.px, m.py, spd * 0.45, dt, map) && now > m.animT) m.anim = 0;
        break;
      }
      case 'chase': {
        const t = this.pickTarget(m, map);
        if (!t || (m.x - m.hx) ** 2 + (m.y - m.hy) ** 2 > leash * leash) { m.state = 'return'; m.threat.clear(); m.target = 0; break; }
        if (m.d.flee && !m.fled && m.hp < m.mhp * 0.25) { m.state = 'flee'; m.fled = true; m.fleeT = now + 2500; break; }
        const dist = Math.sqrt(d2(m, t)); m.a = Math.atan2(t.y - m.y, t.x - m.x);
        if (dist <= m.range + (t.size || 10)) {
          if (now >= m.atkT) { const en = (m.d.boss && GD.BOSS_PHASES[m.d.boss][m.phase].enrage) || 1; m.atkT = now + (m.d.boss ? 1500 : 1300) / en; this.monsterAttack(m, t, now, map); }
          else if (now > m.animT) m.anim = 0;
        } else this.moveToward(m, t.x, t.y, spd, dt, map);
        break;
      }
      case 'flee': {
        if (now > m.fleeT) { m.state = 'chase'; break; }
        const t = map.ents.get(m.target);
        if (t) { const a = Math.atan2(m.y - t.y, m.x - t.x); this.moveToward(m, m.x + Math.cos(a) * 100, m.y + Math.sin(a) * 100, spd * 1.15, dt, map); }
        break;
      }
      case 'return': {
        this.moveToward(m, m.hx, m.hy, spd * 1.6, dt, map);
        m.hp = Math.min(m.mhp, m.hp + m.mhp * 0.2 * dt);
        const home = d2(m, { x: m.hx, y: m.hy }) < 400;
        if (home || now - (m.retT || (m.retT = now)) > 8000) { if (!home) { m.x = m.hx; m.y = m.hy; } m.state = 'idle'; m.retT = 0; m.hp = m.mhp; m.fled = false; m.buffs = {}; m.phase = 0; }
        break;
      }
    }
  }
  monsterAttack(m, t, now, map) {
    m.anim = 2; m.animT = now + 300;
    if (m.d.ranged) this.spawnProj(map, m, m.a, { speed: 360, range: m.range + 80, mult: 1, magic: m.d.magic, style: m.d.magic ? 'orb' : 'rock' });
    else { this.dealDamage(m, t, 1, { magic: m.d.magic }); map.fx.push([t.x, t.y, 'f', 'claw', m.a]); }
  }
  respawnMonster(m) {
    const s = GD.monsterStats(m.mid, m.lvl);
    Object.assign(m, { dead: false, hp: s.hp, mhp: s.hp, x: m.hx, y: m.hy, state: 'idle', target: 0, buffs: {}, fled: false, phase: 0, respawnT: 0, adds: 0 });
    m.threat.clear();
  }
  bossThink(m, now, map) {
    const ph = GD.BOSS_PHASES[m.d.boss]; const r = m.hp / m.mhp; let pi = 0;
    for (let i = 0; i < ph.length; i++) if (r <= ph[i].at) pi = i;
    if (pi > m.phase) { m.phase = pi; map.fx.push([m.x, m.y, 'f', 'roar', 0, 260]); for (const p of map.players) if (d2(p, m) < 1200 * 1200) this.msg(p, `${m.d.n} enters phase ${pi + 1}!`, '#ff6b6b'); }
    if (m.state !== 'chase' || now < m.patT) return;
    const P = ph[m.phase], en = P.enrage || 1; m.patT = now + 3600 / en;
    const pat = P.p[Math.floor(Math.random() * P.p.length)];
    const targets = [...map.players].filter(p => this.validTarget(m, p) && d2(p, m) < 700 * 700).slice(0, 5);
    const o = { src: m, magic: m.d.magic };
    if (pat === 'slam') this.warn(map, m.x, m.y, 150, 1200, Object.assign({ mult: 2 }, o));
    else if (pat === 'targets') targets.forEach(t => this.warn(map, t.x, t.y, 80, 1300, Object.assign({ mult: 1.6 }, o)));
    else if (pat === 'summon') {
      if (m.adds >= 6) return;
      const mid = m.d.summon || (map.meta.key ? GD.DUNGEONS[map.meta.key].mobs[0] : 'skeleton');
      for (let i = 0; i < 3; i++) {
        const a = Math.random() * 6.283, x = m.x + Math.cos(a) * 90, y = m.y + Math.sin(a) * 90;
        if (GD.hitBox(map, x, y, 12)) continue;
        const add = createMonster(mid, x, y, Math.max(1, m.lvl - 3), { respawn: 0, temp: true, bossId: m.id, leash: 1600 });
        add.state = 'chase'; map.add(add); m.adds++;
      }
      map.fx.push([m.x, m.y, 'f', 'summon', 0, 120]);
    } else if (pat === 'ring') { for (let i = 0; i < 14; i++) this.spawnProj(map, m, i / 14 * Math.PI * 2 + Math.random() * 0.2, { speed: 300, range: 560, mult: 1.1, magic: true, style: 'orb' }); }
    else if (pat === 'charge') {
      let far = null, fd = -1; for (const t of targets) { const dd = d2(t, m); if (dd > fd) { fd = dd; far = t; } }
      if (far) this.warn(map, far.x, far.y, 95, 1100, Object.assign({ mult: 2.2, charge: true }, o));
    }
  }
  warn(map, x, y, r, ms, o) {
    map.pend.push(Object.assign({ t: Date.now() + ms, x, y, r, hostile: true }, o));
    map.fx.push([x, y, 'w', r, ms, 1]);
  }
  dropAggro(p) {
    if (!p.map) return;
    for (const e of p.map.ents.values()) if (e.kind === 'm' && e.threat.has(p.id)) { e.threat.delete(p.id); if (e.target === p.id) e.target = 0; }
  }

  // ---------------- loot / rewards ----------------
  autoLoot(p, now) {
    for (const e of p.map.ents.values()) {
      if (e.kind !== 'l' || d2(e, p) > 48 * 48) continue;
      if (e.owner && now < e.ownT && e.owner !== this.lootKey(p)) continue;
      this.takeLoot(p, e);
    }
  }
  lootKey(p) { return p.party ? 'P' + p.party.id : 'S' + p.id; }
  takeLoot(p, e) {
    const rest = [];
    for (const it of e.items) { const left = this.addItem(p, it); if (left > 0) { it.q = left; rest.push(it); } else this.msg(p, `Looted ${GD.itemName(it)}${it.q > 1 ? ' x' + it.q : ''}`, GD.RARITY[it.r || 0].c); }
    e.items = rest;
    if (!rest.length) e.map.remove(e); else this.msg(p, 'Inventory full!', '#ff8a65');
  }
  spawnLoot(map, x, y, items, owner) {
    if (!items.length) return;
    map.add({ id: nid(), kind: 'l', x: x + (Math.random() - 0.5) * 16, y: y + (Math.random() - 0.5) * 16, items, owner, ownT: Date.now() + 30000, exp: Date.now() + 120000 });
  }
  randomEquip(lvl, cls) {
    const pool = Object.values(GD.ITEMS).filter(i => i.type === 'equip' && i.lvl <= lvl + 2 && i.lvl >= lvl - 14 && (!cls || !i.cls || i.cls.includes(cls)));
    return pool.length ? pool[Math.floor(Math.random() * pool.length)].id : null;
  }
  rewardKill(m, p) {
    const map = m.map;
    const members = p.party ? p.party.members.map(id => this.players.get(id)).filter(o => o && o.map === map && d2(o, m) < 1500 * 1500) : [p];
    if (!members.includes(p)) members.push(p);
    const n = members.length, exp = Math.round(m.exp * (1 + 0.2 * (n - 1)) / n), gold = Math.ceil(m.goldV / n);
    for (const o of members) {
      o.gold += gold; o.cnt.kills = (o.cnt.kills || 0) + 1;
      this.gainExp(o, exp); this.progressQuest(o, 'kill', m.mid); this.checkFeats(o);
      if (o.gid) this.guildExp(o.gid, Math.ceil(exp * 0.05));
      o.dirty.me = true;
    }
    const items = [];
    for (const [id, ch] of (m.d.drops || [])) if (Math.random() < ch) items.push(GD.makeItem(id, 1, Math.random, m.d.boss ? 1.5 : 0.5));
    const eqCh = m.d.boss ? 3 : m.d.mini ? 1 : 0.07;
    for (let i = 0; i < Math.ceil(eqCh); i++) if (Math.random() < Math.min(1, eqCh - i)) {
      const id = this.randomEquip(m.lvl, Math.random() < 0.6 ? p.cls : null);
      if (id) items.push(GD.makeItem(id, 1, Math.random, m.d.boss ? 1.5 : m.d.mini ? 0.6 : 0));
    }
    this.spawnLoot(map, m.x, m.y, items, this.lootKey(p));
  }
  gainExp(p, amt) {
    if (p.lvl >= GD.MAX_LEVEL) return;
    p.exp += amt; let up = false;
    while (p.lvl < GD.MAX_LEVEL && p.exp >= GD.expToNext(p.lvl)) { p.exp -= GD.expToNext(p.lvl); p.lvl++; p.pts += 3; up = true;
      for (const s of GD.CLASSES[p.cls].skills) if (GD.SKILLS[s].lvl === p.lvl) this.msg(p, `New skill unlocked: ${GD.SKILLS[s].n}!`, '#ffd34d');
      for (const z of GD.ZONES) if (z.req === p.lvl && z.req > 1) this.msg(p, `New area unlocked: ${z.name}`, '#7fd4ff');
    }
    if (up) {
      this.recalc(p); p.hp = p.stats.hp; p.mp = p.stats.mp; p.ver = (p.ver || 0) + 1;
      p.map.fx.push([p.x, p.y, 'f', 'levelup']); this.msg(p, `Level up! You are now level ${p.lvl}. (+3 stat points)`, '#ffd34d');
      if (p.party) this.sendParty(p.party);
    }
    p.dirty.me = true;
  }
  recalc(p) { p.stats = GD.computeStats(p.cls, p.lvl, p.alloc, p.eq, p.feats); p.hp = Math.min(p.hp, p.stats.hp); p.mp = Math.min(p.mp, p.stats.mp); p.dirty.me = true; }
  checkFeats(p) {
    for (const k in GD.FEATS) {
      if (p.feats.includes(k)) continue;
      const f = GD.FEATS[k];
      if ((p.cnt[f.counter] || 0) >= f.need) { p.feats.push(k); this.recalc(p); this.msg(p, `✦ Feat unlocked: ${f.n}! Permanent bonus gained.`, '#ff9de2'); p.map.fx.push([p.x, p.y, 'f', 'feat']); }
    }
  }

  // ---------------- escort ----------------
  spawnEscort(p) {
    if (p.escort && this.world.ents.get(p.escort)) return;
    if (p.map !== this.world) return this.msg(p, 'Return to the overworld first.');
    const e = { id: nid(), kind: 'e', n: 'Pilgrim Mara', owner: p.id, x: p.x + 20, y: p.y + 20, a: 0, lvl: Math.max(5, p.lvl), hp: 500 + p.lvl * 60, mhp: 500 + p.lvl * 60, st: { def: 10 + p.lvl * 3, mdef: 10 + p.lvl * 3 }, buffs: {}, anim: 0, animT: 0, size: 10, dest: [58, 122] };
    this.world.add(e); p.escort = e.id; this.msg(p, 'Pilgrim Mara joins you. Keep her alive!', '#9fe870');
  }
  updateEscort(e, dt, now) {
    const o = this.players.get(e.owner);
    if (!o || o.map !== e.map) { e.map.remove(e); if (o) { o.escort = 0; this.msg(o, 'Pilgrim Mara was left behind. Return to the Quest Master to retry.', '#ff8a65'); } return; }
    for (const k in e.buffs) if (e.buffs[k].until < now) delete e.buffs[k];
    if (d2(e, o) > 70 * 70) this.moveToward(e, o.x, o.y, 150, dt, e.map); else e.anim = 0;
    const dx = (e.dest[0] + 0.5) * TILE, dy = (e.dest[1] + 0.5) * TILE;
    if ((e.x - dx) ** 2 + (e.y - dy) ** 2 < 130 * 130) {
      e.map.remove(e); o.escort = 0; e.map.fx.push([e.x, e.y, 'f', 'heal']);
      this.progressQuest(o, 'escort', 'escort'); this.msg(o, 'Mara reached the forest shrine safely!', '#9fe870');
    }
  }
}

Object.assign(Game.prototype, require('./combat'), require('./player'), require('./social'), require('./instances'));
module.exports = { Game, GameMap };
