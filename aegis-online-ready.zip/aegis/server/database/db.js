'use strict';
const fs = require('fs');
const path = require('path');
process.removeAllListeners('warning'); // hide node:sqlite ExperimentalWarning
const { DatabaseSync } = require('node:sqlite');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE COLLATE NOCASE NOT NULL, pass TEXT NOT NULL, created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS characters (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT UNIQUE COLLATE NOCASE NOT NULL, cls TEXT NOT NULL, level INTEGER NOT NULL DEFAULT 1, exp INTEGER NOT NULL DEFAULT 0,
  gold INTEGER NOT NULL DEFAULT 0, rating INTEGER NOT NULL DEFAULT 1000, wins INTEGER NOT NULL DEFAULT 0, losses INTEGER NOT NULL DEFAULT 0,
  data TEXT NOT NULL, created INTEGER NOT NULL, updated INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS idx_char_user ON characters(user_id);
CREATE TABLE IF NOT EXISTS inventory (char_id INTEGER PRIMARY KEY REFERENCES characters(id) ON DELETE CASCADE, items TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS equipment (char_id INTEGER PRIMARY KEY REFERENCES characters(id) ON DELETE CASCADE, items TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS quests (char_id INTEGER PRIMARY KEY REFERENCES characters(id) ON DELETE CASCADE, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS guilds (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE COLLATE NOCASE NOT NULL, leader_id INTEGER NOT NULL,
  level INTEGER NOT NULL DEFAULT 1, exp INTEGER NOT NULL DEFAULT 0, storage TEXT NOT NULL DEFAULT '[]', created INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS guild_members (char_id INTEGER PRIMARY KEY REFERENCES characters(id) ON DELETE CASCADE, guild_id INTEGER NOT NULL REFERENCES guilds(id) ON DELETE CASCADE, rank TEXT NOT NULL DEFAULT 'member');
CREATE TABLE IF NOT EXISTS friends (char_id INTEGER NOT NULL REFERENCES characters(id) ON DELETE CASCADE, friend_id INTEGER NOT NULL REFERENCES characters(id) ON DELETE CASCADE, PRIMARY KEY(char_id, friend_id));
CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, from_id INTEGER, to_id INTEGER, detail TEXT, ts INTEGER NOT NULL);
`;

class DB {
  constructor(file) {
    fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
    this.db = new DatabaseSync(file);
    this.db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON;');
    this.db.exec(SCHEMA);
    const p = s => this.db.prepare(s);
    this.q = {
      userByName: p('SELECT * FROM users WHERE username=?'),
      addUser: p('INSERT INTO users(username,pass,created) VALUES(?,?,?)'),
      chars: p('SELECT id,name,cls,level,data FROM characters WHERE user_id=? ORDER BY id'),
      charCount: p('SELECT COUNT(*) n FROM characters WHERE user_id=?'),
      charByName: p('SELECT id,name,level,cls FROM characters WHERE name=?'),
      charById: p('SELECT * FROM characters WHERE id=?'),
      addChar: p('INSERT INTO characters(user_id,name,cls,level,exp,gold,data,created,updated) VALUES(?,?,?,1,0,?,?,?,?)'),
      delChar: p('DELETE FROM characters WHERE id=? AND user_id=?'),
      saveChar: p('UPDATE characters SET level=?,exp=?,gold=?,rating=?,wins=?,losses=?,data=?,updated=? WHERE id=?'),
      inv: p('SELECT items FROM inventory WHERE char_id=?'), setInv: p('INSERT OR REPLACE INTO inventory(char_id,items) VALUES(?,?)'),
      eq: p('SELECT items FROM equipment WHERE char_id=?'), setEq: p('INSERT OR REPLACE INTO equipment(char_id,items) VALUES(?,?)'),
      qs: p('SELECT data FROM quests WHERE char_id=?'), setQs: p('INSERT OR REPLACE INTO quests(char_id,data) VALUES(?,?)'),
      addGuild: p('INSERT INTO guilds(name,leader_id,created) VALUES(?,?,?)'),
      guild: p('SELECT * FROM guilds WHERE id=?'),
      saveGuild: p('UPDATE guilds SET leader_id=?,level=?,exp=?,storage=? WHERE id=?'),
      delGuild: p('DELETE FROM guilds WHERE id=?'),
      memberOf: p('SELECT guild_id,rank FROM guild_members WHERE char_id=?'),
      members: p('SELECT c.id,c.name,c.level,c.cls,m.rank FROM guild_members m JOIN characters c ON c.id=m.char_id WHERE m.guild_id=? ORDER BY c.level DESC'),
      setMember: p('INSERT OR REPLACE INTO guild_members(char_id,guild_id,rank) VALUES(?,?,?)'),
      delMember: p('DELETE FROM guild_members WHERE char_id=?'),
      friends: p('SELECT c.id,c.name,c.level,c.cls FROM friends f JOIN characters c ON c.id=f.friend_id WHERE f.char_id=?'),
      addFriend: p('INSERT OR IGNORE INTO friends(char_id,friend_id) VALUES(?,?)'),
      delFriend: p('DELETE FROM friends WHERE char_id=? AND friend_id=?'),
      tx: p('INSERT INTO transactions(kind,from_id,to_id,detail,ts) VALUES(?,?,?,?,?)'),
      topLevel: p('SELECT name,cls,level,exp FROM characters ORDER BY level DESC, exp DESC LIMIT 20'),
      topRating: p('SELECT name,cls,level,rating,wins,losses FROM characters WHERE wins+losses>0 ORDER BY rating DESC LIMIT 20')
    };
  }
  tx(fn) { this.db.exec('BEGIN'); try { const r = fn(); this.db.exec('COMMIT'); return r; } catch (e) { this.db.exec('ROLLBACK'); throw e; } }
  userByName(u) { return this.q.userByName.get(u); }
  addUser(u, hash) { return Number(this.q.addUser.run(u, hash, Date.now()).lastInsertRowid); }
  listChars(uid) { return this.q.chars.all(uid).map(r => { const d = JSON.parse(r.data); return { id: r.id, name: r.name, cls: r.cls, level: r.level, app: d.app }; }); }
  charCount(uid) { return this.q.charCount.get(uid).n; }
  charByName(n) { return this.q.charByName.get(n); }
  createChar(uid, name, cls, gold, data, inv, eq) {
    return this.tx(() => {
      const now = Date.now();
      const id = Number(this.q.addChar.run(uid, name, cls, gold, JSON.stringify(data), now, now).lastInsertRowid);
      this.q.setInv.run(id, JSON.stringify(inv)); this.q.setEq.run(id, JSON.stringify(eq)); this.q.setQs.run(id, JSON.stringify({ active: {}, done: [] }));
      return id;
    });
  }
  deleteChar(uid, id) { return this.q.delChar.run(id, uid).changes > 0; }
  loadChar(id) {
    const row = this.q.charById.get(id); if (!row) return null;
    const j = (r, d) => r ? JSON.parse(r.items || r.data) : d;
    return { row, data: JSON.parse(row.data), inv: j(this.q.inv.get(id), []), eq: j(this.q.eq.get(id), {}), quests: j(this.q.qs.get(id), { active: {}, done: [] }), member: this.q.memberOf.get(id) };
  }
  saveChar(c) {
    this.tx(() => {
      this.q.saveChar.run(c.level, c.exp, c.gold, c.rating, c.wins, c.losses, JSON.stringify(c.data), Date.now(), c.id);
      this.q.setInv.run(c.id, JSON.stringify(c.inv)); this.q.setEq.run(c.id, JSON.stringify(c.eq)); this.q.setQs.run(c.id, JSON.stringify(c.quests));
    });
  }
  createGuild(name, leaderId) { return this.tx(() => { const id = Number(this.q.addGuild.run(name, leaderId, Date.now()).lastInsertRowid); this.q.setMember.run(leaderId, id, 'leader'); return id; }); }
  guild(id) { const g = this.q.guild.get(id); if (g) g.storage = JSON.parse(g.storage); return g; }
  saveGuild(g) { this.q.saveGuild.run(g.leader_id, g.level, g.exp, JSON.stringify(g.storage), g.id); }
  deleteGuild(id) { this.q.delGuild.run(id); }
  members(gid) { return this.q.members.all(gid); }
  setMember(cid, gid, rank) { this.q.setMember.run(cid, gid, rank); }
  removeMember(cid) { this.q.delMember.run(cid); }
  friends(cid) { return this.q.friends.all(cid); }
  addFriend(a, b) { this.q.addFriend.run(a, b); }
  delFriend(a, b) { this.q.delFriend.run(a, b); }
  log(kind, from, to, detail) { this.q.tx.run(kind, from || null, to || null, JSON.stringify(detail), Date.now()); }
  leaderboard() { return { level: this.q.topLevel.all(), pvp: this.q.topRating.all() }; }
}
module.exports = DB;
