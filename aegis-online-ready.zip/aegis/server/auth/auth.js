'use strict';
const crypto = require('crypto');

let SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 16) {
  if (process.env.NODE_ENV === 'production') throw new Error('JWT_SECRET (min 16 chars) is required in production');
  SECRET = crypto.randomBytes(32).toString('hex');
  console.warn('[auth] JWT_SECRET not set — using a random dev secret (tokens reset on restart)');
}
const TOKEN_TTL = 7 * 24 * 3600 * 1000;

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$${salt.toString('hex')}$${h.toString('hex')}`;
}
function verifyPassword(pw, stored) {
  const [alg, s, h] = String(stored).split('$');
  if (alg !== 'scrypt' || !s || !h) return false;
  const calc = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64, { N: 16384, r: 8, p: 1 });
  const want = Buffer.from(h, 'hex');
  return want.length === calc.length && crypto.timingSafeEqual(calc, want);
}
const b64 = b => Buffer.from(b).toString('base64url');
function signToken(uid) {
  const body = b64(JSON.stringify({ uid, exp: Date.now() + TOKEN_TTL }));
  return body + '.' + crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
}
function verifyToken(tok) {
  if (typeof tok !== 'string' || tok.length > 512) return null;
  const [body, sig] = tok.split('.');
  if (!body || !sig) return null;
  const want = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
  if (want.length !== sig.length || !crypto.timingSafeEqual(Buffer.from(want), Buffer.from(sig))) return null;
  try { const p = JSON.parse(Buffer.from(body, 'base64url').toString()); return p.exp > Date.now() ? p : null; } catch { return null; }
}
// simple per-IP sliding window limiter
const hits = new Map();
function rateLimit(key, max, windowMs) {
  const now = Date.now(); let a = hits.get(key);
  if (!a) { a = []; hits.set(key, a); }
  while (a.length && a[0] < now - windowMs) a.shift();
  if (a.length >= max) return false;
  a.push(now); return true;
}
setInterval(() => { const now = Date.now(); for (const [k, a] of hits) if (!a.length || a[a.length - 1] < now - 600000) hits.delete(k); }, 60000).unref();

module.exports = { hashPassword, verifyPassword, signToken, verifyToken, rateLimit };
