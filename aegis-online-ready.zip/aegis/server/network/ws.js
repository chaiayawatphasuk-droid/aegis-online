// Minimal dependency-free RFC6455 WebSocket server (text frames, ping/pong, fragmentation, size limits)
'use strict';
const crypto = require('crypto');
const EventEmitter = require('events');
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

class WSConn extends EventEmitter {
  constructor(socket, ip, maxPayload) {
    super();
    this.s = socket; this.ip = ip; this.max = maxPayload; this.buf = Buffer.alloc(0); this.frags = []; this.open = true; this.lastPong = Date.now();
    socket.setNoDelay(true);
    socket.on('data', d => this._data(d));
    socket.on('close', () => this._closed());
    socket.on('end', () => this._closed());
    socket.on('error', () => this._closed());
  }
  _data(d) {
    this.buf = this.buf.length ? Buffer.concat([this.buf, d]) : d;
    while (this.open) {
      const b = this.buf; if (b.length < 2) return;
      const fin = b[0] & 0x80, op = b[0] & 0x0f, masked = b[1] & 0x80;
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; if (b.readUInt32BE(2) !== 0) return this.close(1009); len = b.readUInt32BE(6); off = 10; }
      if (len > this.max) return this.close(1009);
      if (!masked) return this.close(1002);
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4), payload = Buffer.from(b.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      this.buf = b.subarray(off + 4 + len);
      if (op === 0x8) return this.close(1000);
      if (op === 0x9) { this._frame(0xA, payload); continue; }
      if (op === 0xA) { this.lastPong = Date.now(); continue; }
      if (op === 0x1 || op === 0x2 || op === 0x0) {
        this.frags.push(payload);
        const total = this.frags.reduce((a, f) => a + f.length, 0);
        if (total > this.max) return this.close(1009);
        if (fin) { const m = Buffer.concat(this.frags); this.frags = []; this.lastPong = Date.now(); this.emit('message', m.toString('utf8')); }
      }
    }
  }
  _frame(op, data) {
    if (!this.open || this.s.destroyed) return;
    const len = data.length; let h;
    if (len < 126) { h = Buffer.alloc(2); h[1] = len; }
    else if (len < 65536) { h = Buffer.alloc(4); h[1] = 126; h.writeUInt16BE(len, 2); }
    else { h = Buffer.alloc(10); h[1] = 127; h.writeUInt32BE(0, 2); h.writeUInt32BE(len, 6); }
    h[0] = 0x80 | op;
    this.s.cork(); this.s.write(h); this.s.write(data); this.s.uncork();
  }
  send(str) {
    if (this.s.writableLength > 4 * 1024 * 1024) return this.close(1008); // slow client protection
    this._frame(0x1, Buffer.from(str, 'utf8'));
  }
  ping() { this._frame(0x9, Buffer.alloc(0)); }
  close(code = 1000) {
    if (!this.open) return;
    const b = Buffer.alloc(2); b.writeUInt16BE(code); this._frame(0x8, b);
    this.s.end(); setTimeout(() => this.s.destroy(), 1000).unref();
    this._closed();
  }
  _closed() { if (this.open) { this.open = false; this.emit('close'); } }
}

function attachWS(server, path, onConn) {
  const conns = new Set();
  server.on('upgrade', (req, socket) => {
    const url = (req.url || '').split('?')[0];
    const key = req.headers['sec-websocket-key'];
    if (url !== path || !key || String(req.headers.upgrade).toLowerCase() !== 'websocket') { socket.destroy(); return; }
    const acc = crypto.createHash('sha1').update(key + GUID).digest('base64');
    socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\n\r\n');
    const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || socket.remoteAddress;
    const c = new WSConn(socket, ip, 8192);
    conns.add(c); c.on('close', () => conns.delete(c));
    onConn(c, req);
  });
  setInterval(() => {
    const now = Date.now();
    for (const c of conns) { if (now - c.lastPong > 70000) c.close(1001); else c.ping(); }
  }, 25000).unref();
  return conns;
}
module.exports = { attachWS };
