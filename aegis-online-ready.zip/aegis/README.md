# ⛨ Aegis Online — 2D Top-down Web MMORPG

เกม MMORPG Open World 2D (Top-down) เล่นผ่านเว็บได้ทั้ง PC และมือถือ — รันได้จริง, Multiplayer real-time, Server-authoritative, ไม่มี dependency ภายนอก (Node.js 22+ อย่างเดียว)

## Stack & เหตุผล
| ส่วน | เลือก | เหตุผล |
|---|---|---|
| Server | Node.js 22 (vanilla `http`) | JS เดียวกับ client → แชร์ข้อมูลเกม/สูตรคำนวณ/collision ได้ (`/shared/data.js`) |
| Realtime | WebSocket (RFC6455 เขียนเอง `server/network/ws.js`) | latency ต่ำ, ไม่ต้องติดตั้ง package, รองรับทุกเบราว์เซอร์ |
| Database | SQLite (`node:sqlite` built-in, WAL) | ไม่ต้องติดตั้งอะไร, transaction ACID, ย้ายไป Postgres ได้ภายหลังผ่าน `server/database/db.js` |
| Auth | scrypt password hash + HMAC token | ไม่เก็บ plain text, secret อยู่ฝั่ง server เท่านั้น |
| Client | HTML5 Canvas 2D + DOM UI, ไม่มี build step | โหลดเร็วบนมือถือ, ภาพทั้งหมดวาด procedural (ไม่มี asset ลิขสิทธิ์) |
| Audio | WebAudio procedural | เพลงแต่ละโซน + เพลงบอส โดยไม่ต้องมีไฟล์เสียง |

## โครงสร้างไฟล์
```
aegis/
├─ package.json  Dockerfile  render.yaml  .env.example
├─ shared/data.js            # Zones, map gen, classes, skills, items, monsters, quests, stat/damage formulas (client+server)
├─ server/
│  ├─ index.js               # HTTP API + static + WS bootstrap + graceful save
│  ├─ auth/auth.js           # scrypt, HMAC token, rate limit
│  ├─ database/db.js         # SQLite schema: users, characters, inventory, equipment, quests, guilds, guild_members, friends, transactions
│  ├─ network/ws.js          # WebSocket server
│  ├─ entities/entities.js   # Player/Monster factories + serialization
│  └─ systems/
│     ├─ game.js             # Game loop 20Hz, maps, AOI snapshots, monster AI, bosses, loot, EXP, escort, world events
│     ├─ combat.js           # Damage formula, block/dodge/crit/reflect/shield, skills, projectiles, AoE telegraphs
│     ├─ player.js           # Message handlers: inventory, equip, shop, craft, upgrade, quests, NPC, interact
│     ├─ social.js           # Chat, party, guild, friends, trade (server validated)
│     └─ instances.js        # Instanced dungeons + arena (1v1/2v2/3v3) + rating
├─ client/
│  ├─ index.html  css/style.css
│  └─ js/ net.js audio.js render.js input.js ui.js main.js
└─ test/ smoke.js  systems.js  combat.js
```

## ติดตั้ง & รัน Local
```bash
# ต้องการ Node.js >= 22.13  (ไม่ต้อง npm install — ไม่มี dependency)
cd aegis
cp .env.example .env          # (optional) แก้ JWT_SECRET
JWT_SECRET=dev-secret-1234567890 npm start
# เปิด http://localhost:3000   (มือถือในวง LAN: http://<IP เครื่อง>:3000)
npm test                      # E2E + systems tests
```
Windows PowerShell: `$env:JWT_SECRET="dev-secret-1234567890"; npm start`

## Environment Variables
| Var | Default | หมายเหตุ |
|---|---|---|
| `JWT_SECRET` | random (dev) | **บังคับ** เมื่อ `NODE_ENV=production` (≥16 ตัวอักษร) |
| `PORT` | 3000 | HTTP + WebSocket (path `/ws`) |
| `DB_PATH` | `./data/aegis.db` | ต้องอยู่บน persistent disk ตอน deploy |
| `NODE_ENV` | - | `production` |

## Deploy เป็นเว็บไซต์
**Render.com** (ง่ายสุด): push repo → New → Blueprint → เลือก repo (ใช้ `render.yaml` ที่มี disk + JWT_SECRET อัตโนมัติ) → ได้ URL `https://xxx.onrender.com`

**Docker / VPS / Fly.io / Railway**
```bash
docker build -t aegis .
docker run -d -p 80:3000 -e JWT_SECRET=$(openssl rand -hex 32) -v aegis-data:/data --restart unless-stopped aegis
```
- Fly.io: `fly launch` → `fly volumes create data` → mount `/data` → `fly secrets set JWT_SECRET=...`
- Railway: New project from repo, เพิ่ม Volume mount `/data`, ตั้ง `DB_PATH=/data/aegis.db`, `JWT_SECRET`
- หลัง Nginx/Cloudflare: ต้องเปิด WebSocket upgrade (`proxy_set_header Upgrade $http_upgrade; proxy_set_header Connection "upgrade";`) — HTTPS จะใช้ `wss://` อัตโนมัติ
- รันได้ 1 instance (state อยู่ใน memory + SQLite) — ห้าม scale หลาย instance โดยไม่แยก shard

## ปัญหาที่อาจเจอ
| อาการ | สาเหตุ / แก้ |
|---|---|
| `Cannot find module 'node:sqlite'` / `No such built-in module` | Node เก่า → อัปเป็น 22.13+ |
| `JWT_SECRET ... is required in production` | ตั้ง env `JWT_SECRET` |
| "Connection lost" ค้าง | Proxy ไม่รองรับ WebSocket upgrade / timeout < 60s (server ping ทุก 25s) |
| ข้อมูลหายหลัง redeploy | `DB_PATH` ไม่ได้อยู่บน persistent volume |
| `SQLITE_BUSY` | อย่าเปิด DB ไฟล์เดียวกันจากหลาย process |
| `EADDRINUSE` | เปลี่ยน `PORT` |
| มือถือกระตุก | Settings → Graphics: LOW (ลด particle, DPR, chunk cache) |
| ไม่มีเสียง | เบราว์เซอร์ต้องได้รับการแตะ/คลิกก่อน (autoplay policy) |

## ระบบที่ทำงานแล้ว
- **Login/Register**, สร้างตัวละคร (เพศ/ผิว/ทรงผม/สีผม/ชุด/เครื่องประดับ), 5 Class: Guardian, Warrior, Mage, Ranger, Assassin (เพิ่มคลาสใหม่ = เพิ่ม entry ใน `CLASSES` + `SKILLS`)
- **Open World 256×256 tiles** 11 โซน (Village, Capital, Plains, Forest, Lake, Peaks, Caverns, Dunes, Ashen Wastes, Elder Grove (boss), Crimson Arena), ล็อกโซนตามเลเวล, ถนน, World Map, Minimap, เพลงต่อโซน
- **Multiplayer** real-time (20Hz sim, 10Hz snapshot, AOI culling 1000px), client prediction + reconciliation, ทุกค่าสำคัญคำนวณ server
- **Combat**: โจมตี/สกิล 25 สกิล/cooldown/MP, Dodge (i-frame), Block, Crit, Dodge%, Block%, Reflect, Shield absorb, Poison/Burn/Slow/Stun, Projectile, AoE telegraph
- **Tank System**: Guardian block รับ 25% + สะท้อน 15%, Taunt, Aegis Link (โล่ทั้งปาร์ตี้), Thorn Mirror, Unbroken Citadel, threat ×2.5 + **Feats** (ปลดโบนัสถาวรจากการกระทำ เช่น Block 100 ครั้ง → DEF +15%)
- **Monster AI**: patrol → detect → chase → attack (melee/ranged) → flee (HP ต่ำ) → leash/return; 16 ชนิด + 9 mini/boss
- **Boss** 3 phase (summon / ring / charge / slam / targeted AoE พร้อม warning area), HP bar ใหญ่, boss music, rare drop
- **Quest** 15 เควส: Kill/Collect/Explore/Escort/Boss/Story + Quest Log
- **Inventory 40 ช่อง** stack/equip/unequip/drop/sell/use/sort, **Equipment 6 slot**, 6 rarity + random bonus stats, **Craft** & **Upgrade +10**
- **Level** 1–120, stat points (VIT/STR/INT/DEX/END), ปลดสกิล/โซน
- **Party** (5 คน, shared EXP/quest/instance, HP bars), **Guild** (level/EXP/storage/rank), **Friends**, **Chat** (say/world/party/guild/whisper)
- **Dungeon** instance 4 แห่ง (mini boss + final boss + reward chest), **PvP** opt-in flag + Arena queue 1v1/2v2/3v3 + rating leaderboard
- **Trading** ตรวจสอบฝั่ง server (atomic + log ใน `transactions`), **World Event** (Gilded Slime ทุก 15 นาที)
- **Save** server-side อัตโนมัติทุก 30s + ตอนออก/ปิด server
- **Performance**: chunk cache (16×16 tiles), entity culling, LOD, particle pool + cap, monster sleep เมื่อไม่มีผู้เล่นใกล้, quality LOW/HIGH

## Controls
PC: WASD เดิน · Shift เดินช้า · คลิกซ้าย โจมตี/คุย NPC · คลิกขวา/Q Block · Space Dodge · 1-5 Skill · F/R Potion · E Interact · Tab เปลี่ยนเป้า · Enter แชท · I C K J M P G O เปิดหน้าต่าง · ล้อเมาส์ซูม
Mobile: จอยซ้าย · ปุ่มขวา · แตะเพื่อเลือกเป้า/คุย · Pinch ซูม · ☰ เมนู
