// Procedural renderer: tiles (chunk cached), characters, monsters, objects, FX (pooled), minimap
(function () {
  'use strict';
  const T = GD.T, TILE = GD.TILE, CH = GD.CHUNK, CPX = CH * TILE;
  const R = window.R = { chunks: new Map(), map: null, quality: 'high', mapImg: null, t: 0 };
  const TAU = Math.PI * 2;

  // ---------------- helpers ----------------
  function shade(hex, amt) {
    const n = parseInt(hex.slice(1), 16); let r = (n >> 16) + amt, g = ((n >> 8) & 255) + amt, b = (n & 255) + amt;
    r = Math.max(0, Math.min(255, r)); g = Math.max(0, Math.min(255, g)); b = Math.max(0, Math.min(255, b));
    return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  }
  R.shade = shade;
  const circ = (c, x, y, r) => { c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill(); };
  const ell = (c, x, y, rx, ry) => { c.beginPath(); c.ellipse(x, y, rx, ry, 0, 0, TAU); c.fill(); };
  function rrect(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  R.rrect = rrect;

  // ---------------- tiles ----------------
  function base(c, x, y, col, tx, ty, v) { c.fillStyle = shade(col, Math.round((GD.hash(tx, ty, 3) - 0.5) * (v || 14))); c.fillRect(x, y, TILE, TILE); }
  function specks(c, x, y, tx, ty, col, n, s) { c.fillStyle = col; for (let i = 0; i < n; i++) { const h1 = GD.hash(tx, ty, 50 + i), h2 = GD.hash(tx, ty, 80 + i); c.fillRect(x + h1 * (TILE - s), y + h2 * (TILE - s), s, s); } }
  function drawTile(c, t, x, y, tx, ty) {
    const h = GD.hash(tx, ty, 9);
    switch (t) {
      case T.GRASS: case T.GROVE: {
        base(c, x, y, t === T.GROVE ? '#3f7a45' : '#5aa648', tx, ty, 16);
        c.strokeStyle = t === T.GROVE ? '#2f6235' : '#4a9238'; c.lineWidth = 1.2;
        for (let i = 0; i < 3; i++) { const px = x + GD.hash(tx, ty, 20 + i) * 28 + 2, py = y + GD.hash(tx, ty, 30 + i) * 26 + 4; c.beginPath(); c.moveTo(px, py); c.lineTo(px - 2, py - 5); c.moveTo(px, py); c.lineTo(px + 2, py - 5); c.stroke(); }
        break;
      }
      case T.FLOWER: {
        base(c, x, y, '#62ad4f', tx, ty, 12);
        const cols = ['#ff8fb1', '#ffe066', '#ffffff', '#b28dff'];
        for (let i = 0; i < 4; i++) { c.fillStyle = cols[Math.floor(GD.hash(tx, ty, 40 + i) * 4)]; circ(c, x + 4 + GD.hash(tx, ty, 60 + i) * 24, y + 4 + GD.hash(tx, ty, 70 + i) * 24, 2.2); }
        break;
      }
      case T.WATER: case T.DEEP: {
        base(c, x, y, t === T.DEEP ? '#2a6aa8' : '#3a8fd6', tx, ty, 8);
        c.strokeStyle = '#ffffff40'; c.lineWidth = 1.5;
        if (h > 0.5) { c.beginPath(); c.arc(x + 10 + h * 10, y + 14, 5, Math.PI * 1.1, Math.PI * 1.9); c.stroke(); }
        break;
      }
      case T.TREE: {
        const z = R.map && R.map.zone ? GD.ZONES[R.map.zone[ty * R.map.w + tx]].id : '';
        base(c, x, y, z === 'grove' ? '#3f7a45' : z === 'peaks' ? '#e8eef2' : '#4f9a40', tx, ty, 10);
        c.fillStyle = '#0003'; ell(c, x + 17, y + 26, 12, 5);
        c.fillStyle = '#6b4a2b'; c.fillRect(x + 13, y + 16, 6, 12);
        const g = z === 'grove' ? '#1f5a2a' : z === 'peaks' ? '#2e5a4a' : '#2f7a34';
        if (z === 'peaks') { c.fillStyle = g; c.beginPath(); c.moveTo(x + 16, y - 2); c.lineTo(x + 30, y + 20); c.lineTo(x + 2, y + 20); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.moveTo(x + 16, y - 2); c.lineTo(x + 21, y + 6); c.lineTo(x + 11, y + 6); c.fill(); }
        else { c.fillStyle = g; circ(c, x + 16, y + 11, 13); c.fillStyle = shade(g, 25); circ(c, x + 12, y + 8, 7); c.fillStyle = shade(g, 45); circ(c, x + 10, y + 6, 3); }
        break;
      }
      case T.SAND: base(c, x, y, '#e2c98a', tx, ty, 14); specks(c, x, y, tx, ty, '#c9ad6a', 4, 2); if (h > 0.93) { c.fillStyle = '#4f8a3a'; c.fillRect(x + 14, y + 8, 5, 16); c.fillRect(x + 9, y + 12, 5, 3); c.fillRect(x + 9, y + 9, 3, 5); } break;
      case T.ROCK: base(c, x, y, '#9a958a', tx, ty, 16); specks(c, x, y, tx, ty, '#7d786e', 5, 3); break;
      case T.MOUNTAIN: {
        base(c, x, y, '#5d5a57', tx, ty, 10);
        c.fillStyle = '#7d7a76'; c.beginPath(); c.moveTo(x + 2, y + 30); c.lineTo(x + 16, y + 2 + h * 4); c.lineTo(x + 30, y + 30); c.fill();
        c.fillStyle = '#4a4744'; c.beginPath(); c.moveTo(x + 16, y + 2 + h * 4); c.lineTo(x + 30, y + 30); c.lineTo(x + 18, y + 30); c.fill();
        c.fillStyle = '#f2f4f6'; c.beginPath(); c.moveTo(x + 16, y + 2 + h * 4); c.lineTo(x + 21, y + 11); c.lineTo(x + 11, y + 11); c.fill();
        break;
      }
      case T.ROAD: base(c, x, y, '#c7a874', tx, ty, 10); specks(c, x, y, tx, ty, '#a88a58', 3, 3); break;
      case T.TOWN: {
        base(c, x, y, '#d5c8ab', tx, ty, 8); c.strokeStyle = '#b5a68a'; c.lineWidth = 1;
        c.strokeRect(x + 0.5, y + 0.5, 15, 15); c.strokeRect(x + 16.5, y + 0.5, 15, 15); c.strokeRect(x + 8.5, y + 16.5, 15, 15);
        break;
      }
      case T.WALL: case T.CWALL: {
        const col = t === T.CWALL ? '#2b2530' : (R.map && R.map.kind === 'dungeon' ? '#3a3448' : '#7a6650');
        base(c, x, y, col, tx, ty, 6); c.strokeStyle = shade(col, -25); c.lineWidth = 1;
        for (let r = 0; r < 4; r++) { c.beginPath(); c.moveTo(x, y + r * 8 + 0.5); c.lineTo(x + 32, y + r * 8 + 0.5); c.stroke(); const o = r % 2 ? 8 : 0; for (let k = o; k < 32; k += 16) { c.beginPath(); c.moveTo(x + k + 0.5, y + r * 8); c.lineTo(x + k + 0.5, y + r * 8 + 8); c.stroke(); } }
        c.fillStyle = shade(col, 25); c.fillRect(x, y, 32, 3);
        break;
      }
      case T.CAVE: base(c, x, y, '#4a4250', tx, ty, 10); specks(c, x, y, tx, ty, '#3a3340', 4, 3); break;
      case T.ASH: base(c, x, y, '#5a4f4b', tx, ty, 12); specks(c, x, y, tx, ty, h > 0.7 ? '#ff7a3a' : '#463c39', 3, 2); break;
      case T.LAVA: base(c, x, y, '#d9481a', tx, ty, 16); c.fillStyle = '#ffb02e'; circ(c, x + 8 + h * 14, y + 10 + h * 8, 4); c.fillStyle = '#ffe07a'; circ(c, x + 20 - h * 6, y + 22, 2.5); break;
      case T.SNOW: base(c, x, y, '#e8eef2', tx, ty, 8); specks(c, x, y, tx, ty, '#cfdbe6', 3, 3); break;
      case T.ARENA: base(c, x, y, '#a85a43', tx, ty, 10); specks(c, x, y, tx, ty, '#8e4634', 4, 2); break;
      case T.ICE: base(c, x, y, '#bfe2f2', tx, ty, 8); c.strokeStyle = '#ffffffaa'; c.beginPath(); c.moveTo(x + 4, y + 26); c.lineTo(x + 20, y + 6); c.stroke(); break;
      case T.RUIN: base(c, x, y, '#b8a98a', tx, ty, 10); c.strokeStyle = '#9a8c70'; c.strokeRect(x + 1.5, y + 1.5, 29, 29); break;
      case T.OBSID: base(c, x, y, '#3a2c3c', tx, ty, 8); c.strokeStyle = '#8a3aa055'; c.beginPath(); c.moveTo(x, y + h * 32); c.lineTo(x + 32, y + 32 - h * 20); c.stroke(); break;
      default: base(c, x, y, GD.TILE_COLORS[t] || '#000', tx, ty, 0);
    }
  }
  R.setMap = function (m) {
    R.map = m; R.chunks.clear();
    const img = document.createElement('canvas'); img.width = m.w; img.height = m.h;
    const c = img.getContext('2d'), id = c.createImageData(m.w, m.h);
    const rgb = GD.TILE_COLORS.map(h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]);
    for (let i = 0; i < m.w * m.h; i++) { const col = rgb[m.tiles[i]] || [0, 0, 0]; id.data[i * 4] = col[0]; id.data[i * 4 + 1] = col[1]; id.data[i * 4 + 2] = col[2]; id.data[i * 4 + 3] = 255; }
    c.putImageData(id, 0, 0); R.mapImg = img;
  };
  function buildChunk(cx, cy) {
    const cv = document.createElement('canvas'); cv.width = cv.height = CPX;
    const c = cv.getContext('2d'), m = R.map;
    c.fillStyle = '#000'; c.fillRect(0, 0, CPX, CPX);
    // draw non-tree tiles first then trees so canopies overlap neatly
    const trees = [];
    for (let ty = 0; ty < CH; ty++) for (let tx = 0; tx < CH; tx++) {
      const gx = cx * CH + tx, gy = cy * CH + ty; if (gx >= m.w || gy >= m.h) continue;
      const t = m.tiles[gy * m.w + gx];
      if (t === T.TREE) trees.push([t, tx, ty, gx, gy]); else drawTile(c, t, tx * TILE, ty * TILE, gx, gy);
    }
    for (const [t, tx, ty, gx, gy] of trees) drawTile(c, t, tx * TILE, ty * TILE, gx, gy);
    return cv;
  }
  R.drawWorld = function (ctx, x0, y0, x1, y1) {
    const m = R.map; if (!m) return;
    const cx0 = Math.max(0, Math.floor(x0 / CPX)), cy0 = Math.max(0, Math.floor(y0 / CPX));
    const cx1 = Math.min(Math.ceil(m.w / CH) - 1, Math.floor(x1 / CPX)), cy1 = Math.min(Math.ceil(m.h / CH) - 1, Math.floor(y1 / CPX));
    let built = 0;
    for (let cy = cy0; cy <= cy1; cy++) for (let cx = cx0; cx <= cx1; cx++) {
      const k = cx + ',' + cy; let ch = R.chunks.get(k);
      if (!ch && built < 2) { ch = buildChunk(cx, cy); built++; R.chunks.set(k, ch); }
      if (ch) { R.chunks.delete(k); R.chunks.set(k, ch); ctx.drawImage(ch, cx * CPX, cy * CPX); }
      else { ctx.fillStyle = '#3d6b35'; ctx.fillRect(cx * CPX, cy * CPX, CPX, CPX); }
    }
    const maxC = R.quality === 'low' ? 16 : 30;
    while (R.chunks.size > maxC) R.chunks.delete(R.chunks.keys().next().value);
    // animated water/lava shimmer for visible tiles (cheap: only on high quality)
    if (R.quality === 'high') {
      const t = R.t, tx0 = Math.max(0, Math.floor(x0 / TILE)), ty0 = Math.max(0, Math.floor(y0 / TILE)), tx1 = Math.min(m.w - 1, Math.floor(x1 / TILE)), ty1 = Math.min(m.h - 1, Math.floor(y1 / TILE));
      ctx.lineWidth = 1.5;
      for (let ty = ty0; ty <= ty1; ty++) for (let tx = tx0; tx <= tx1; tx++) {
        const tt = m.tiles[ty * m.w + tx];
        if (tt === T.WATER || tt === T.DEEP) { const ph = (t * 1.2 + GD.hash(tx, ty, 2) * 6) % 6; if (ph < 1.2) { ctx.strokeStyle = `rgba(255,255,255,${0.35 * (1 - ph / 1.2)})`; ctx.beginPath(); ctx.arc(tx * TILE + 16, ty * TILE + 18, 4 + ph * 6, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke(); } }
        else if (tt === T.LAVA) { const a = 0.15 + 0.15 * Math.sin(t * 3 + tx + ty); ctx.fillStyle = `rgba(255,220,90,${a})`; ctx.fillRect(tx * TILE, ty * TILE, TILE, TILE); }
      }
    }
  };

  // ---------------- characters ----------------
  const A = GD.APPEARANCE;
  R.drawChar = function (c, x, y, o) {
    const app = o.app || {}, t = o.t || 0, s = o.scale || 1, cls = o.cls;
    const skin = A.skins[app.skin || 0], hair = A.hairs[app.hc || 0], outfit = o.outfit || A.outfits[app.oc || 0];
    const a = o.a === undefined ? Math.PI / 2 : o.a, back = Math.sin(a) < -0.6, flip = Math.cos(a) < 0;
    const walk = o.anim === 1, bob = walk ? Math.sin(t * 12) * 1.5 : Math.sin(t * 2.5) * 0.6;
    const atkP = o.atkP !== undefined ? o.atkP : -1;
    c.save(); c.translate(x, y); c.scale(s * (flip ? -1 : 1), s);
    c.fillStyle = '#0004'; ell(c, 0, 0, 11, 4);
    if (o.dead) { c.rotate(Math.PI / 2); c.globalAlpha = 0.6; }
    if (o.dodge) c.globalAlpha = 0.55;
    c.translate(0, bob);
    // cape
    if (app.acc === 2) { c.fillStyle = shade(outfit, -40); c.beginPath(); c.moveTo(-7, -20); c.lineTo(7, -20); c.lineTo(9 + (walk ? Math.sin(t * 12) * 2 : 0), -2); c.lineTo(-9, -2); c.fill(); }
    // back hair
    c.fillStyle = hair;
    if (app.hair === 1) { rrect(c, -11, -36, 22, 26, 8); c.fill(); }
    if (app.hair === 2) { ell(c, -11, -24 + Math.sin(t * 6) * (walk ? 1.5 : 0.3), 4, 8); }
    if (app.hair === 3) { ell(c, -12, -22, 4, 9); ell(c, 12, -22, 4, 9); }
    // legs
    const lg = walk ? Math.sin(t * 12) * 3 : 0;
    c.fillStyle = '#2b2b3a'; c.fillRect(-5, -9 + lg * 0.3, 4, 8 + lg * 0.3); c.fillRect(1, -9 - lg * 0.3, 4, 8 - lg * 0.3);
    c.fillStyle = '#3a2a1a'; c.fillRect(-6, -2 + lg * 0.3, 5, 2); c.fillRect(1, -2 - lg * 0.3, 5, 2);
    // body
    const heavy = cls === 'guardian' || cls === 'warrior';
    c.fillStyle = outfit; rrect(c, -8, -21, 16, 13, 4); c.fill();
    if (heavy) { c.fillStyle = '#c9ccd6'; rrect(c, -9, -21, 6, 5, 2); c.fill(); rrect(c, 3, -21, 6, 5, 2); c.fill(); }
    if (cls === 'mage') { c.fillStyle = outfit; c.beginPath(); c.moveTo(-8, -12); c.lineTo(8, -12); c.lineTo(10, -4); c.lineTo(-10, -4); c.fill(); }
    c.fillStyle = '#5a3a1a'; c.fillRect(-8, -12, 16, 2); c.fillStyle = '#e8c66a'; c.fillRect(-1, -12, 2, 2);
    // weapon (behind arm)
    drawWeapon(c, cls, t, atkP, o.blocking, o.anim === 3);
    // arm
    c.fillStyle = skin; circ(c, 7, -13, 2.6);
    // head
    c.fillStyle = skin; circ(c, 0, -29, 11);
    if (app.acc === 3) { c.beginPath(); c.moveTo(-10, -30); c.lineTo(-17, -34); c.lineTo(-10, -26); c.fill(); c.beginPath(); c.moveTo(10, -30); c.lineTo(17, -34); c.lineTo(10, -26); c.fill(); }
    if (!back) {
      c.fillStyle = '#1d1d2a'; ell(c, 4, -28, 1.9, 2.6); ell(c, -3, -28, 1.9, 2.6);
      c.fillStyle = '#fff'; circ(c, 4.6, -29, 0.8); circ(c, -2.4, -29, 0.8);
      c.fillStyle = '#ff8a8a55'; ell(c, 7, -24.5, 2, 1.2); ell(c, -6, -24.5, 2, 1.2);
      if (app.g === 'f') { c.strokeStyle = '#1d1d2a'; c.lineWidth = 0.8; c.beginPath(); c.moveTo(5.8, -30.5); c.lineTo(7.2, -31.5); c.stroke(); }
    }
    // front hair
    c.fillStyle = hair;
    c.beginPath(); c.arc(0, -31, 11.5, Math.PI * 1.02, Math.PI * 1.98); c.lineTo(11, -30); c.quadraticCurveTo(4, -35, 1, -29); c.quadraticCurveTo(-4, -35, -11, -29); c.fill();
    if (back) { circ(c, 0, -30, 11); }
    if (app.hair === 4) { for (let i = -2; i <= 2; i++) { c.beginPath(); c.moveTo(i * 4 - 3, -38); c.lineTo(i * 4, -46 + Math.abs(i)); c.lineTo(i * 4 + 3, -38); c.fill(); } }
    if (app.hair === 1 || app.g === 'f') { rrect(c, -12, -32, 4, 14, 2); c.fill(); }
    if (app.acc === 1) { c.fillStyle = '#ffd34d'; c.fillRect(-10, -36, 20, 2.4); c.fillStyle = '#4ad0ff'; circ(c, 0, -35, 2); }
    if (app.acc === 4) { c.fillStyle = '#ff5a8a'; c.beginPath(); c.moveTo(6, -39); c.lineTo(13, -43); c.lineTo(13, -35); c.fill(); c.beginPath(); c.moveTo(6, -39); c.lineTo(-1, -43); c.lineTo(-1, -35); c.fill(); }
    if (cls === 'mage' && !o.noHat) { c.fillStyle = shade(outfit, -20); c.beginPath(); c.moveTo(-13, -36); c.lineTo(13, -36); c.lineTo(3, -54); c.lineTo(-2, -50); c.fill(); }
    // shield in front for guardian
    if (cls === 'guardian') {
      const bl = o.blocking; c.save(); c.translate(bl ? 9 : -9, bl ? -16 : -14);
      if (bl && R.quality === 'high') { c.shadowColor = '#7fd4ff'; c.shadowBlur = 12; }
      c.fillStyle = '#5a7bd8'; c.beginPath(); c.moveTo(-6, -8); c.lineTo(6, -8); c.lineTo(6, 2); c.lineTo(0, 9); c.lineTo(-6, 2); c.closePath(); c.fill();
      c.shadowBlur = 0; c.strokeStyle = '#ffd34d'; c.lineWidth = 1.6; c.stroke(); c.fillStyle = '#ffd34d'; circ(c, 0, -1, 2);
      c.restore();
    }
    c.restore();
  };
  function drawWeapon(c, cls, t, atkP, blocking, casting) {
    c.save(); c.translate(7, -13);
    let rot = -0.5;
    if (atkP >= 0 && atkP <= 1) rot = -1.8 + atkP * 2.8;
    if (casting) rot = -1.2;
    c.rotate(rot);
    if (cls === 'warrior') { c.fillStyle = '#d9dde8'; c.fillRect(-1.5, -26, 4, 22); c.fillStyle = '#ffd34d'; c.fillRect(-4, -5, 10, 2.5); c.fillStyle = '#6b4a2b'; c.fillRect(0, -3, 2, 6); }
    else if (cls === 'guardian') { c.fillStyle = '#6b4a2b'; c.fillRect(-1, -16, 2.5, 18); c.fillStyle = '#b9bccb'; circ(c, 0.2, -17, 4.5); c.fillStyle = '#8a8d99'; circ(c, 0.2, -17, 2); }
    else if (cls === 'mage') { c.fillStyle = '#7a5230'; c.fillRect(-1, -24, 2.5, 30); c.fillStyle = casting ? '#ffe7ff' : '#c48bff'; if (R.quality === 'high') { c.shadowColor = '#c48bff'; c.shadowBlur = 10; } circ(c, 0.2, -26, 4); c.shadowBlur = 0; }
    else if (cls === 'ranger') { c.strokeStyle = '#7a5230'; c.lineWidth = 2.2; c.beginPath(); c.arc(-4, -6, 12, -1.2, 1.2); c.stroke(); c.strokeStyle = '#eee'; c.lineWidth = 0.7; c.beginPath(); c.moveTo(0.4, -17); c.lineTo(0.4 - (atkP >= 0 && atkP < 0.5 ? 5 : 0), -6); c.lineTo(0.4, 5); c.stroke(); }
    else if (cls === 'assassin') { c.fillStyle = '#cfd6e8'; c.beginPath(); c.moveTo(0, -14); c.lineTo(2.5, -2); c.lineTo(-2.5, -2); c.fill(); c.fillStyle = '#3a2a4a'; c.fillRect(-1, -2, 2, 5); }
    c.restore();
    if (cls === 'assassin') { c.save(); c.translate(-7, -13); c.rotate(0.4 - (atkP >= 0 ? atkP * 1.5 : 0)); c.fillStyle = '#cfd6e8'; c.beginPath(); c.moveTo(0, -12); c.lineTo(2, -2); c.lineTo(-2, -2); c.fill(); c.restore(); }
  }

  // ---------------- monsters ----------------
  R.drawMonster = function (c, x, y, d, o) {
    const t = o.t, s = (d.size || 14) / 14, col = d.col, walk = o.anim === 1, atk = o.anim === 2;
    const lod = o.far;
    c.save(); c.translate(x, y);
    if (o.flipX) c.scale(-1, 1);
    c.fillStyle = '#0004'; ell(c, 0, 0, 12 * s, 4 * s);
    if (d.boss && R.quality === 'high') { c.fillStyle = '#ff3a3a22'; circ(c, 0, -12 * s, 26 * s + Math.sin(t * 4) * 3); }
    c.scale(s, s);
    const b = lod ? 0 : (walk ? Math.abs(Math.sin(t * 10)) * 2 : Math.sin(t * 3) * 0.8);
    const lunge = atk ? 4 : 0;
    const dk = shade(col, -40), lt = shade(col, 40);
    switch (d.shape) {
      case 'slime': {
        const sq = lod ? 0 : Math.sin(t * 6) * 1.5;
        c.fillStyle = col; c.globalAlpha = 0.92; c.beginPath(); c.ellipse(0, -9 + sq * 0.3, 13 + sq, 10 - sq, 0, Math.PI, 0); c.lineTo(13 + sq, -1); c.quadraticCurveTo(0, 2, -13 - sq, -1); c.fill(); c.globalAlpha = 1;
        c.fillStyle = lt; ell(c, -5, -13, 4, 2.5);
        c.fillStyle = '#1a1a2a'; circ(c, 4 + lunge * 0.3, -9, 1.8); circ(c, -1 + lunge * 0.3, -9, 1.8);
        if (d.event) { c.fillStyle = '#fff'; circ(c, 6, -16, 1.2); }
        break;
      }
      case 'wolf': case 'beast': {
        const big = d.shape === 'beast';
        c.fillStyle = dk; const lg = walk && !lod ? Math.sin(t * 14) * 3 : 0;
        c.fillRect(-9 + lg, -6, 3, 6); c.fillRect(6 - lg, -6, 3, 6); c.fillRect(-5 - lg, -6, 3, 6); c.fillRect(2 + lg, -6, 3, 6);
        c.fillStyle = col; ell(c, 0, -10 - b * 0.4, big ? 13 : 11, big ? 8 : 6);
        c.beginPath(); c.moveTo(-10, -11); c.lineTo(-17, -16 + Math.sin(t * 8) * 2); c.lineTo(-11, -8); c.fill();
        ell(c, 10 + lunge, -14 - b * 0.4, big ? 7 : 6, big ? 6 : 5);
        if (big) { c.fillStyle = '#f2ecd6'; c.beginPath(); c.moveTo(14 + lunge, -12); c.lineTo(19 + lunge, -16); c.lineTo(16 + lunge, -11); c.fill(); }
        else { c.beginPath(); c.moveTo(7 + lunge, -18); c.lineTo(9 + lunge, -24); c.lineTo(11 + lunge, -18); c.fill(); }
        c.fillStyle = d.mid === 'hound' ? '#ffe07a' : '#ff4a4a'; circ(c, 12 + lunge, -15, 1.3);
        break;
      }
      case 'goblin': case 'orc': case 'skeleton': case 'demon': {
        const isO = d.shape === 'orc', isS = d.shape === 'skeleton', isD = d.shape === 'demon';
        const w = isO ? 1.25 : 1, lg = walk && !lod ? Math.sin(t * 12) * 2.5 : 0;
        if (isD) { c.fillStyle = dk; c.beginPath(); c.moveTo(-4, -20); c.lineTo(-20, -30 - Math.sin(t * 5) * 3); c.lineTo(-14, -14); c.fill(); c.beginPath(); c.moveTo(4, -20); c.lineTo(20, -30 - Math.sin(t * 5) * 3); c.lineTo(14, -14); c.fill(); }
        c.fillStyle = isS ? '#d8d2bc' : dk; c.fillRect(-4 * w, -8 + lg * 0.3, 3, 8); c.fillRect(1 * w, -8 - lg * 0.3, 3, 8);
        if (isS) { c.strokeStyle = '#e6e0cc'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -20); c.lineTo(0, -8); for (let i = 0; i < 3; i++) { c.moveTo(-5, -18 + i * 3.5); c.lineTo(5, -18 + i * 3.5); } c.stroke(); }
        else { c.fillStyle = col; rrect(c, -7 * w, -20 - b * 0.3, 14 * w, 13, 4); c.fill(); }
        c.fillStyle = isS ? '#efe9d6' : col; circ(c, 0, -27 - b * 0.4, isO ? 9 : 8);
        if (d.shape === 'goblin') { c.beginPath(); c.moveTo(-7, -28); c.lineTo(-15, -32); c.lineTo(-7, -24); c.fill(); c.beginPath(); c.moveTo(7, -28); c.lineTo(15, -32); c.lineTo(7, -24); c.fill(); }
        if (isD) { c.fillStyle = '#2a1a1a'; c.beginPath(); c.moveTo(-5, -33); c.lineTo(-8, -42); c.lineTo(-2, -34); c.fill(); c.beginPath(); c.moveTo(5, -33); c.lineTo(8, -42); c.lineTo(2, -34); c.fill(); }
        c.fillStyle = isS ? '#1a1a1a' : (isD ? '#ffe07a' : '#ff3030'); circ(c, 3, -28, isS ? 2.2 : 1.5); circ(c, -3, -28, isS ? 2.2 : 1.5);
        if (isO) { c.fillStyle = '#fff'; c.fillRect(-4, -23, 2, 3); c.fillRect(2, -23, 2, 3); }
        if (d.mid === 'goblin_king') { c.fillStyle = '#ffd34d'; c.beginPath(); c.moveTo(-7, -34); c.lineTo(-7, -40); c.lineTo(-3, -36); c.lineTo(0, -41); c.lineTo(3, -36); c.lineTo(7, -40); c.lineTo(7, -34); c.fill(); }
        c.save(); c.translate(8 * w, -15); c.rotate(atk ? 0.9 : -0.5);
        if (d.ranged) { c.fillStyle = '#7a5230'; c.fillRect(-1, -10, 2, 12); }
        else { c.fillStyle = '#6b4a2b'; c.fillRect(-1, -12, 2.5, 14); c.fillStyle = isO || isS ? '#b9bccb' : '#9aa'; c.beginPath(); c.moveTo(0, -12); c.lineTo(isO ? 8 : 5, -14); c.lineTo(isO ? 8 : 5, -6); c.lineTo(0, -8); c.fill(); }
        c.restore();
        break;
      }
      case 'golem': {
        c.fillStyle = dk; c.fillRect(-9, -8, 7, 8); c.fillRect(2, -8, 7, 8);
        c.fillStyle = col; c.fillRect(-12, -24 - b * 0.2, 24, 17); c.fillRect(-17, -22 + (atk ? 6 : 0), 6, 13); c.fillRect(11, -22 + (atk ? 6 : 0), 6, 13);
        c.fillStyle = lt; c.fillRect(-8, -34 - b * 0.3, 16, 11);
        c.fillStyle = '#7fe0ff'; c.fillRect(-5, -30, 3, 2); c.fillRect(2, -30, 3, 2);
        c.fillStyle = dk; c.fillRect(-6, -18, 4, 3); c.fillRect(3, -14, 5, 2);
        break;
      }
      case 'dragon': {
        const fl = lod ? 0 : Math.sin(t * 9) * 6;
        c.fillStyle = dk; c.beginPath(); c.moveTo(-2, -18); c.lineTo(-22, -30 - fl); c.lineTo(-16, -12); c.fill(); c.beginPath(); c.moveTo(2, -18); c.lineTo(22, -30 - fl); c.lineTo(16, -12); c.fill();
        c.fillStyle = col; ell(c, 0, -14 - b, 10, 8);
        c.beginPath(); c.moveTo(-8, -12); c.quadraticCurveTo(-18, -4, -22, -12 + Math.sin(t * 4) * 3); c.lineTo(-8, -9); c.fill();
        ell(c, 9 + lunge, -22 - b, 6, 5); c.fillStyle = lt; c.beginPath(); c.moveTo(7 + lunge, -26); c.lineTo(5 + lunge, -32); c.lineTo(10 + lunge, -26); c.fill();
        c.fillStyle = '#ffe07a'; circ(c, 11 + lunge, -23, 1.4);
        break;
      }
      case 'undead': {
        c.globalAlpha = 0.85; const fl = lod ? 0 : Math.sin(t * 3) * 2;
        c.fillStyle = col; c.beginPath(); c.moveTo(-9, -6 + fl); c.lineTo(-11, -22 + fl); c.quadraticCurveTo(0, -40 + fl, 11, -22 + fl); c.lineTo(9, -6 + fl);
        for (let i = 3; i >= -3; i--) c.lineTo(i * 3, (i % 2 ? -2 : -7) + fl + Math.sin(t * 8 + i) * 1.5); c.fill();
        c.globalAlpha = 1; c.fillStyle = '#1a1a2a'; ell(c, -3, -24 + fl, 2, 3); ell(c, 3, -24 + fl, 2, 3);
        c.fillStyle = d.magic ? '#9ff' : '#ff9'; circ(c, -3, -24 + fl, 0.9); circ(c, 3, -24 + fl, 0.9);
        if (d.mid === 'sand_revenant') { c.fillStyle = '#ffd34d'; c.fillRect(-7, -36 + fl, 14, 3); }
        break;
      }
      case 'tree': {
        c.fillStyle = '#5a3a1f'; c.fillRect(-7, -28, 14, 28);
        c.strokeStyle = '#5a3a1f'; c.lineWidth = 4; const sw = Math.sin(t * 2) * 3 + (atk ? 8 : 0);
        c.beginPath(); c.moveTo(-6, -20); c.lineTo(-18, -30 + sw); c.moveTo(6, -20); c.lineTo(18, -30 - sw); c.stroke();
        c.fillStyle = col; circ(c, 0, -38, 16); circ(c, -12, -32, 10); circ(c, 12, -32, 10); c.fillStyle = lt; circ(c, -5, -44, 6);
        c.fillStyle = '#ffe07a'; circ(c, -3, -18, 1.8); circ(c, 3, -18, 1.8); c.fillStyle = '#2a1a0a'; c.fillRect(-3, -13, 6, 2);
        break;
      }
    }
    c.restore();
  };

  // ---------------- objects ----------------
  R.drawObject = function (c, e, t) {
    c.save(); c.translate(e.x, e.y);
    if (e.k === 'l') { c.fillStyle = '#0004'; ell(c, 0, 4, 8, 3); c.fillStyle = '#a77a3a'; circ(c, 0, -2, 7); c.fillStyle = '#c99a5a'; c.fillRect(-3, -11, 6, 4); c.fillStyle = '#ffe07a'; circ(c, 5, -10 + Math.sin(t * 5) * 2, 1.8); c.restore(); return; }
    if (e.st === 'chest') {
      c.fillStyle = '#0004'; ell(c, 0, 4, 14, 4);
      c.fillStyle = e.dungeon ? '#7a2a8a' : '#8a5a2a'; c.fillRect(-12, -10, 24, 14); c.fillStyle = '#ffd34d'; c.fillRect(-12, -10, 24, 2); c.fillRect(-2, -6, 4, 5);
      c.fillStyle = e.dungeon ? '#9a3aaa' : '#a06a32';
      if (e.open) { c.fillRect(-12, -20, 24, 6); } else { rrect(c, -12, -17, 24, 8, 4); c.fill(); if (!e.open) { c.fillStyle = '#fff8'; circ(c, 8, -16 + Math.sin(t * 4) * 2, 1.4); } }
    } else if (e.st === 'portal' || e.st === 'exit') {
      const col = e.st === 'exit' ? '#5ac8ff' : '#b05aff';
      for (let i = 0; i < 3; i++) { c.strokeStyle = col; c.globalAlpha = 0.4 + i * 0.2; c.lineWidth = 3; c.beginPath(); c.ellipse(0, -16, 16 - i * 4, 22 - i * 5, 0, t * (2 + i) , t * (2 + i) + 4.5); c.stroke(); }
      c.globalAlpha = 0.35; c.fillStyle = col; ell(c, 0, -16, 12, 18); c.globalAlpha = 1;
    } else if (e.st === 'res') {
      const av = e.avail; c.globalAlpha = av ? 1 : 0.35;
      c.fillStyle = '#0003'; ell(c, 0, 3, 10, 3);
      switch (e.item) {
        case 'herb': c.fillStyle = '#3f8a3a'; c.fillRect(-1, -12, 2, 12); c.fillRect(-6, -8, 5, 2); c.fillRect(1, -10, 5, 2); if (av) { c.fillStyle = '#9fffd0'; circ(c, 0, -14, 3.5 + Math.sin(t * 3) * 0.6); circ(c, -6, -9, 2.2); circ(c, 6, -11, 2.2); } break;
        case 'iron_ore': c.fillStyle = '#7d7a76'; ell(c, 0, -6, 11, 8); c.fillStyle = '#d98a3a'; circ(c, -3, -8, 2); circ(c, 4, -5, 1.6); circ(c, 1, -11, 1.4); break;
        case 'mana_crystal': c.fillStyle = '#5ab4ff'; for (const [dx, h] of [[-5, 12], [0, 18], [5, 10]]) { c.beginPath(); c.moveTo(dx - 3, 0); c.lineTo(dx, -h); c.lineTo(dx + 3, 0); c.fill(); } break;
        case 'sun_fiber': c.fillStyle = '#c9a23a'; for (let i = -2; i <= 2; i++) { c.fillRect(i * 3, -12 + Math.abs(i) * 2, 1.5, 12 - Math.abs(i) * 2); } break;
        case 'ember_core': c.fillStyle = '#3a2a2a'; ell(c, 0, -5, 9, 6); c.fillStyle = '#ff6a2a'; circ(c, 0, -6, 3 + Math.sin(t * 5)); break;
      }
      c.globalAlpha = 1;
    }
    c.restore();
  };
  const ROLE_ICON = { quest: '!', merchant: '$', blacksmith: '⚒', trainer: '✦', healer: '✚', guild: '⚑', dungeon: '⌂', arena: '⚔' };
  R.ROLE_ICON = ROLE_ICON;
  R.npcApp = n => { let h = 0; for (const ch of n.nid) h = (h * 31 + ch.charCodeAt(0)) | 0; h = Math.abs(h); return { g: h % 2 ? 'f' : 'm', skin: h % 4, hair: h % 5, hc: (h >> 3) % 8, oc: 0, acc: (h >> 5) % 5 === 2 ? 2 : (h >> 5) % 5 === 1 ? 1 : 0 }; };

  // ---------------- FX ----------------
  const FX = R.FX = { parts: [], dmg: [], fx: [], projs: new Map(), warns: [], chains: [] };
  const maxParts = () => R.quality === 'low' ? 90 : 320;
  function part(x, y, vx, vy, life, col, size, g) {
    if (FX.parts.length >= maxParts()) return;
    FX.parts.push({ x, y, vx, vy, life, max: life, col, size, g: g || 0 });
  }
  function burst(x, y, n, col, spd, life, size, g) {
    n = R.quality === 'low' ? Math.ceil(n / 3) : n;
    for (let i = 0; i < n; i++) { const a = Math.random() * TAU, s = spd * (0.3 + Math.random() * 0.7); part(x, y, Math.cos(a) * s, Math.sin(a) * s, life * (0.6 + Math.random() * 0.6), col, size * (0.6 + Math.random() * 0.6), g); }
  }
  function rise(x, y, n, col, r) { n = R.quality === 'low' ? Math.ceil(n / 3) : n; for (let i = 0; i < n; i++) part(x + (Math.random() - 0.5) * r, y + (Math.random() - 0.5) * r * 0.5, (Math.random() - 0.5) * 10, -30 - Math.random() * 40, 0.9, col, 2.5); }
  R.fxDamage = function (x, y, v, kind) {
    if (FX.dmg.length > 70) FX.dmg.shift();
    const col = ['#ffffff', '#ffd34d', '#7fe07f', '#9fc8ff', '#cccccc', '#ff6060', '#9fdcff', '#ff9de2', '#c48bff'][kind] || '#fff';
    const txt = kind === 4 ? 'MISS' : kind === 3 ? `${v} BLOCK` : kind === 6 ? `(${v})` : kind === 2 ? `+${v}` : kind === 7 ? `↺${v}` : String(v);
    FX.dmg.push({ x: x + (Math.random() - 0.5) * 14, y, txt, col, t: 0, big: kind === 1 });
  };
  R.fxSpawn = function (name, x, y, a, r) {
    const add = (o) => FX.fx.push(Object.assign({ name, x, y, a: a || 0, r: r || 60, t: 0 }, o));
    switch (name) {
      case 'slash': case 'slash2': case 'bigslash': add({ dur: 0.2 }); burst(x + Math.cos(a) * (r || 60) * 0.7, y + Math.sin(a) * (r || 60) * 0.7, 4, '#ffffff', 80, 0.25, 2); break;
      case 'claw': add({ dur: 0.25 }); break;
      case 'shield': add({ dur: 0.6 }); burst(x, y - 16, 10, '#9fdcff', 70, 0.5, 2.5); break;
      case 'roar': add({ dur: 0.5 }); break;
      case 'fortress': add({ dur: 0.9, r: 70 }); rise(x, y - 10, 20, '#ffd34d', 40); break;
      case 'thorns': add({ dur: 0.6, r: 40 }); burst(x, y - 16, 12, '#7fe07f', 90, 0.4, 2); break;
      case 'buff': rise(x, y - 10, 14, '#ffd34d', 30); break;
      case 'levelup': add({ dur: 1.2, r: 50 }); rise(x, y, 30, '#ffe07a', 40); A2s('level'); break;
      case 'feat': rise(x, y, 30, '#ff9de2', 40); add({ name: 'levelup', dur: 1.2, r: 50 }); break;
      case 'dash': add({ dur: 0.3 }); break;
      case 'whirl': case 'fan': add({ dur: 0.35 }); burst(x, y - 10, 12, name === 'fan' ? '#cfd6e8' : '#ffffff', 160, 0.3, 2); break;
      case 'fire': case 'burn': burst(x, y - 12, name === 'burn' ? 5 : 10, '#ff8a3a', 60, 0.4, 3); break;
      case 'explosion': add({ dur: 0.4 }); burst(x, y, 26, '#ff8a3a', (r || 60) * 2.2, 0.5, 4); burst(x, y, 10, '#ffe07a', (r || 60) * 1.5, 0.4, 3); A2s('boom'); break;
      case 'ice': case 'slow': burst(x, y - 12, 10, '#bfefff', 60, 0.5, 2.5); break;
      case 'heal': rise(x, y - 6, 16, '#7fe07f', 30); A2s('heal'); break;
      case 'mana': rise(x, y - 6, 12, '#7fb4ff', 30); break;
      case 'poison': burst(x, y - 14, 8, '#b45aff', 30, 0.7, 3, -20); break;
      case 'stun': add({ dur: 0.8 }); break;
      case 'shadow': burst(x, y - 14, 16, '#2a2a3a', 50, 0.6, 5, -10); break;
      case 'wind': burst(x, y - 10, 12, '#e8fff8', 90, 0.4, 2); break;
      case 'rain': add({ dur: 0.5 }); break;
      case 'death': burst(x, y - 10, 14, '#bbbbbb', 60, 0.6, 4, -10); break;
      case 'summon': add({ dur: 0.7 }); burst(x, y, 16, '#8a3aff', 90, 0.6, 3); break;
      case 'slam': add({ dur: 0.45 }); burst(x, y, 18, '#b59a7a', (r || 80) * 1.8, 0.5, 4); A2s('boom'); break;
      case 'gather': rise(x, y, 10, '#9fffd0', 20); A2s('pickup'); break;
      case 'lightning': break;
      default: rise(x, y, 6, '#fff', 20);
    }
  };
  const A2s = k => window.Audio2 && Audio2.sfx(k);
  R.fxProj = function (id, x, y, a, spd, range, style) {
    FX.projs.set(id, { x, y, vx: Math.cos(a) * spd, vy: Math.sin(a) * spd, a, range, trav: 0, style, spd });
    A2s(style === 'arrow' || style === 'poison' || style === 'snipe' ? 'arrow' : 'cast');
  };
  R.fxProjEnd = id => { const p = FX.projs.get(id); if (p && (p.style === 'fire' || p.style === 'orb')) burst(p.x, p.y, 8, p.style === 'fire' ? '#ff8a3a' : '#c48bff', 70, 0.3, 3); FX.projs.delete(id); };
  R.fxWarn = (x, y, r, ms, hostile) => { FX.warns.push({ x, y, r, end: performance.now() + ms, dur: ms, hostile }); if (hostile) A2s('warn'); };
  R.fxChain = pts => { FX.chains.push({ pts, t: 0 }); A2s('cast'); for (let i = 2; i < pts.length; i += 2) burst(pts[i], pts[i + 1] - 12, 5, '#bfe8ff', 80, 0.3, 2); };

  R.updateFx = function (dt) {
    for (let i = FX.parts.length - 1; i >= 0; i--) { const p = FX.parts[i]; p.life -= dt; if (p.life <= 0) { FX.parts[i] = FX.parts[FX.parts.length - 1]; FX.parts.pop(); continue; } p.x += p.vx * dt; p.y += p.vy * dt; p.vy += p.g * dt; p.vx *= 0.96; }
    for (let i = FX.dmg.length - 1; i >= 0; i--) { const d = FX.dmg[i]; d.t += dt; if (d.t > 1) FX.dmg.splice(i, 1); }
    for (let i = FX.fx.length - 1; i >= 0; i--) { const f = FX.fx[i]; f.t += dt; if (f.t > f.dur) FX.fx.splice(i, 1); }
    for (const [id, p] of FX.projs) {
      const st = p.spd * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.trav += st;
      if (p.trav > p.range + 20) FX.projs.delete(id);
      else if (p.style === 'fire' && Math.random() < 0.7) part(p.x, p.y, (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20, 0.3, '#ffb02e', 3);
    }
    const now = performance.now(); FX.warns = FX.warns.filter(w => w.end > now - 100);
    for (let i = FX.chains.length - 1; i >= 0; i--) { FX.chains[i].t += dt; if (FX.chains[i].t > 0.3) FX.chains.splice(i, 1); }
  };
  R.drawFxUnder = function (c) {
    const now = performance.now();
    for (const w of FX.warns) {
      const p = Math.min(1, 1 - (w.end - now) / w.dur);
      c.fillStyle = w.hostile ? 'rgba(255,40,40,0.18)' : 'rgba(80,180,255,0.15)'; circ(c, w.x, w.y, w.r);
      c.fillStyle = w.hostile ? 'rgba(255,60,40,0.35)' : 'rgba(120,200,255,0.3)'; circ(c, w.x, w.y, w.r * p);
      c.strokeStyle = w.hostile ? '#ff5a3a' : '#7fd4ff'; c.lineWidth = 2; c.beginPath(); c.arc(w.x, w.y, w.r, 0, TAU); c.stroke();
    }
  };
  R.drawFx = function (c) {
    for (const f of FX.fx) {
      const p = f.t / f.dur, r = f.r;
      c.save(); c.translate(f.x, f.y);
      switch (f.name) {
        case 'slash': case 'slash2': case 'bigslash': {
          c.strokeStyle = f.name === 'bigslash' ? `rgba(255,220,140,${1 - p})` : `rgba(255,255,255,${1 - p})`; c.lineWidth = f.name === 'bigslash' ? 7 : 4;
          const sweep = f.name === 'slash2' ? 0.8 : 1.3, st = f.a - sweep + p * sweep * 2 * 0.3;
          c.beginPath(); c.arc(0, -12, r * 0.85, st, st + sweep * 1.6 * Math.min(1, p * 3)); c.stroke(); break;
        }
        case 'claw': c.strokeStyle = `rgba(255,80,80,${1 - p})`; c.lineWidth = 2.5; for (let i = -1; i <= 1; i++) { c.beginPath(); c.moveTo(-8 + i * 5, -26); c.lineTo(4 + i * 5, -6); c.stroke(); } break;
        case 'shield': c.strokeStyle = `rgba(150,220,255,${1 - p})`; c.lineWidth = 3; c.beginPath(); c.arc(0, -16, 18 + p * 10, 0, TAU); c.stroke(); break;
        case 'roar': case 'summon': c.strokeStyle = f.name === 'roar' ? `rgba(255,170,60,${1 - p})` : `rgba(160,80,255,${1 - p})`; c.lineWidth = 5 * (1 - p) + 1; c.beginPath(); c.arc(0, -8, r * p, 0, TAU); c.stroke(); break;
        case 'fortress': case 'levelup': c.fillStyle = f.name === 'fortress' ? `rgba(255,211,77,${0.3 * (1 - p)})` : `rgba(255,230,120,${0.35 * (1 - p)})`; c.fillRect(-14, -90 * Math.min(1, p * 2), 28, 90 * Math.min(1, p * 2)); c.strokeStyle = `rgba(255,211,77,${1 - p})`; c.lineWidth = 3; c.beginPath(); c.ellipse(0, 0, r * (0.5 + p), r * 0.35 * (0.5 + p), 0, 0, TAU); c.stroke(); break;
        case 'thorns': c.strokeStyle = `rgba(120,230,120,${1 - p})`; c.lineWidth = 2; for (let i = 0; i < 10; i++) { const a = i / 10 * TAU; c.beginPath(); c.moveTo(Math.cos(a) * 14, -16 + Math.sin(a) * 14); c.lineTo(Math.cos(a) * (22 + p * 12), -16 + Math.sin(a) * (22 + p * 12)); c.stroke(); } break;
        case 'dash': c.strokeStyle = `rgba(255,255,255,${0.6 * (1 - p)})`; c.lineWidth = 10; c.lineCap = 'round'; c.beginPath(); c.moveTo(0, -12); c.lineTo(Math.cos(f.a) * r, Math.sin(f.a) * r - 12); c.stroke(); break;
        case 'whirl': case 'fan': c.strokeStyle = `rgba(255,255,255,${1 - p})`; c.lineWidth = 4; c.beginPath(); c.arc(0, -10, r * (0.4 + p * 0.6), p * 12, p * 12 + 4); c.stroke(); break;
        case 'explosion': c.fillStyle = `rgba(255,160,60,${0.5 * (1 - p)})`; circ(c, 0, 0, r * (0.3 + p * 0.8)); break;
        case 'slam': c.strokeStyle = `rgba(200,150,100,${1 - p})`; c.lineWidth = 6; c.beginPath(); c.arc(0, 0, r * (0.2 + p), 0, TAU); c.stroke(); break;
        case 'stun': c.fillStyle = '#ffe07a'; for (let i = 0; i < 3; i++) { const a = f.t * 6 + i * 2.1; circ(c, Math.cos(a) * 9, -40 + Math.sin(a) * 3, 2); } break;
        case 'rain': c.strokeStyle = `rgba(230,230,200,${1 - p})`; c.lineWidth = 1.5; for (let i = 0; i < 14; i++) { const rx = (GD.hash(i, 1, 5) - 0.5) * r * 1.6, ry = (GD.hash(i, 2, 5) - 0.5) * r; c.beginPath(); c.moveTo(rx, ry - 30 + p * 30); c.lineTo(rx + 2, ry - 18 + p * 30); c.stroke(); } break;
      }
      c.restore();
    }
    for (const [, p] of FX.projs) {
      c.save(); c.translate(p.x, p.y - 14); c.rotate(p.a);
      switch (p.style) {
        case 'arrow': case 'poison': case 'snipe':
          c.strokeStyle = p.style === 'poison' ? '#9f5aff' : p.style === 'snipe' ? '#fff3a0' : '#e8dcc0'; c.lineWidth = p.style === 'snipe' ? 3 : 2;
          c.beginPath(); c.moveTo(-14, 0); c.lineTo(6, 0); c.stroke(); c.fillStyle = c.strokeStyle; c.beginPath(); c.moveTo(9, 0); c.lineTo(3, -3); c.lineTo(3, 3); c.fill(); break;
        case 'ice': c.fillStyle = '#bfefff'; c.beginPath(); c.moveTo(12, 0); c.lineTo(-8, -4); c.lineTo(-8, 4); c.fill(); break;
        case 'rock': c.fillStyle = '#8a8070'; circ(c, 0, 0, 4); break;
        default: {
          const col = p.style === 'fire' ? '#ff8a3a' : p.style === 'orb' ? '#d05aff' : '#c48bff';
          if (R.quality === 'high') { c.shadowColor = col; c.shadowBlur = 12; }
          c.fillStyle = col; circ(c, 0, 0, p.style === 'fire' ? 7 : 5); c.fillStyle = '#fff'; circ(c, 0, 0, 2.5);
        }
      }
      c.restore();
    }
    for (const ch of FX.chains) {
      c.strokeStyle = `rgba(190,230,255,${1 - ch.t / 0.3})`; c.lineWidth = 2.5; c.beginPath();
      for (let i = 0; i < ch.pts.length - 2; i += 2) {
        const x1 = ch.pts[i], y1 = ch.pts[i + 1] - 14, x2 = ch.pts[i + 2], y2 = ch.pts[i + 3] - 14; c.moveTo(x1, y1);
        for (let k = 1; k < 6; k++) { const q = k / 6; c.lineTo(x1 + (x2 - x1) * q + (Math.random() - 0.5) * 14, y1 + (y2 - y1) * q + (Math.random() - 0.5) * 14); }
        c.lineTo(x2, y2);
      }
      c.stroke();
    }
    for (const p of FX.parts) { c.globalAlpha = Math.max(0, p.life / p.max); c.fillStyle = p.col; c.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size); }
    c.globalAlpha = 1;
  };
  R.drawDmg = function (c) {
    c.textAlign = 'center'; c.lineWidth = 3; c.strokeStyle = '#000';
    for (const d of FX.dmg) {
      const a = Math.min(1, 2 - d.t * 2), y = d.y - d.t * 40, sc = d.big ? 1.4 - Math.min(0.3, d.t) : 1;
      c.globalAlpha = Math.max(0, a); c.font = `800 ${Math.round(14 * sc)}px Nunito,sans-serif`;
      c.strokeText(d.txt, d.x, y); c.fillStyle = d.col; c.fillText(d.txt, d.x, y);
    }
    c.globalAlpha = 1;
  };

  // ---------------- item icons ----------------
  const iconCache = new Map();
  R.itemIcon = function (id) {
    if (iconCache.has(id)) return iconCache.get(id);
    const cv = document.createElement('canvas'); cv.width = cv.height = 40; const c = cv.getContext('2d'); const d = GD.ITEMS[id];
    c.translate(20, 20);
    if (!d) { iconCache.set(id, cv); return cv; }
    const tierCol = ['#a9a9b3', '#c9ccd6', '#7fb6ff', '#ffd34d', '#ff9de2'][d.tier || 0];
    if (d.type === 'potion') { const col = d.mana && !d.heal ? '#4a7be0' : d.mana ? '#ffd34d' : '#e04848'; c.fillStyle = '#d8eaff88'; rrect(c, -9, -6, 18, 20, 7); c.fill(); c.fillStyle = col; rrect(c, -8, 0, 16, 13, 6); c.fill(); c.fillStyle = '#8a5a2a'; c.fillRect(-4, -14, 8, 7); c.fillStyle = '#fff8'; c.fillRect(-5, 2, 2, 6); }
    else if (d.slot === 'weapon') {
      const cls = d.cls[0]; c.rotate(-0.78);
      if (cls === 'warrior') { c.fillStyle = tierCol; c.fillRect(-2.5, -18, 5, 26); c.fillStyle = '#ffd34d'; c.fillRect(-7, 6, 14, 3); c.fillStyle = '#6b4a2b'; c.fillRect(-1.5, 9, 3, 8); }
      else if (cls === 'guardian') { c.fillStyle = '#6b4a2b'; c.fillRect(-1.5, -6, 3, 22); c.fillStyle = tierCol; circ(c, 0, -10, 8); c.fillStyle = shade(tierCol, -50); circ(c, 0, -10, 3); }
      else if (cls === 'mage') { c.fillStyle = '#7a5230'; c.fillRect(-1.5, -10, 3, 28); c.fillStyle = tierCol === '#a9a9b3' ? '#c48bff' : tierCol; circ(c, 0, -13, 6); }
      else if (cls === 'ranger') { c.rotate(0.78); c.strokeStyle = '#7a5230'; c.lineWidth = 3; c.beginPath(); c.arc(-8, 0, 16, -1.1, 1.1); c.stroke(); c.strokeStyle = tierCol; c.lineWidth = 1; c.beginPath(); c.moveTo(-1, -14); c.lineTo(-1, 14); c.stroke(); }
      else { c.fillStyle = tierCol; c.beginPath(); c.moveTo(-6, -16); c.lineTo(-3, 4); c.lineTo(-9, 4); c.fill(); c.beginPath(); c.moveTo(6, -16); c.lineTo(9, 4); c.lineTo(3, 4); c.fill(); c.fillStyle = '#3a2a4a'; c.fillRect(-7, 4, 3, 8); c.fillRect(4, 4, 3, 8); }
    } else if (d.slot === 'offhand') { const col = id === 'dawn_bastion' ? '#ffd34d' : id === 'guardian_shield' ? '#5a7bd8' : id === 'knight_shield' ? '#9aa6c8' : id === 'iron_shield' ? '#8a8d99' : '#8a5a2a'; c.fillStyle = col; c.beginPath(); c.moveTo(-12, -14); c.lineTo(12, -14); c.lineTo(12, 2); c.lineTo(0, 16); c.lineTo(-12, 2); c.closePath(); c.fill(); c.strokeStyle = '#ffd34d'; c.lineWidth = 2; c.stroke(); c.fillStyle = '#fff6'; c.fillRect(-2, -10, 4, 18); }
    else if (d.slot === 'armor') { c.fillStyle = id.endsWith('robe') ? '#6a4abf' : id.endsWith('light') ? '#8a5a2a' : tierCol; rrect(c, -12, -14, 24, 28, 6); c.fill(); c.fillStyle = '#0003'; c.fillRect(-12, -2, 24, 3); c.fillStyle = '#0002'; c.fillRect(-2, -14, 4, 28); }
    else if (d.slot === 'helm') { c.fillStyle = id === 'regent_crown' ? '#b05aff' : tierCol; c.beginPath(); c.arc(0, 4, 14, Math.PI, 0); c.fill(); c.fillRect(-14, 4, 28, 5); c.fillStyle = '#0005'; c.fillRect(-8, 6, 16, 3); }
    else if (d.slot === 'boots') { c.fillStyle = '#6b4a2b'; c.fillRect(-12, -12, 9, 22); c.fillRect(-12, 6, 14, 6); c.fillRect(3, -12, 9, 22); c.fillRect(3, 6, 14, 6); c.fillStyle = tierCol; c.fillRect(-12, -12, 9, 4); c.fillRect(3, -12, 9, 4); }
    else if (d.slot === 'acc') { if (id.endsWith('ring')) { c.strokeStyle = '#ffd34d'; c.lineWidth = 4; c.beginPath(); c.arc(0, 3, 10, 0, TAU); c.stroke(); c.fillStyle = tierCol === '#a9a9b3' ? '#ff5a5a' : tierCol; circ(c, 0, -8, 5); } else { c.strokeStyle = '#ffd34d'; c.lineWidth = 2; c.beginPath(); c.arc(0, -6, 12, 0.3, Math.PI - 0.3); c.stroke(); c.fillStyle = id === 'heartwood_mantle' ? '#4a7a3a' : '#5ab4ff'; circ(c, 0, 8, 7); } }
    else {
      const M = { slime_gel: ['blob', '#6fd36f'], wolf_pelt: ['pelt', '#9a8f80'], goblin_ear: ['charm', '#7bb04c'], bone_shard: ['bone', '#e6e0cc'], golem_core: ['gem', '#8b8b9a'], orc_tusk: ['tusk', '#f2ecd6'], drake_scale: ['scale', '#e0903a'], demon_horn: ['tusk', '#8e1b1b'], herb: ['herb', '#9fffd0'], iron_ore: ['ore', '#7d7a76'], mana_crystal: ['gem', '#5ab4ff'], sun_fiber: ['fiber', '#c9a23a'], ember_core: ['gem', '#ff6a2a'], warden_heart: ['wood', '#4a7a3a'], abyss_shard: ['gem', '#8a3aff'] };
      const [k, col] = M[id] || ['blob', '#aaa']; c.fillStyle = col;
      if (k === 'blob') ell(c, 0, 4, 12, 9); else if (k === 'pelt') { rrect(c, -13, -9, 26, 18, 6); c.fill(); } else if (k === 'bone') { c.fillRect(-12, -2, 24, 5); circ(c, -12, -2, 4); circ(c, -12, 3, 4); circ(c, 12, -2, 4); circ(c, 12, 3, 4); }
      else if (k === 'tusk') { c.beginPath(); c.moveTo(-10, 12); c.quadraticCurveTo(-6, -14, 10, -14); c.quadraticCurveTo(0, -4, -2, 12); c.fill(); }
      else if (k === 'gem') { c.beginPath(); c.moveTo(0, -14); c.lineTo(11, -2); c.lineTo(0, 14); c.lineTo(-11, -2); c.fill(); c.fillStyle = '#fff6'; c.beginPath(); c.moveTo(0, -14); c.lineTo(4, -2); c.lineTo(0, 4); c.fill(); }
      else if (k === 'ore') { ell(c, 0, 2, 13, 10); c.fillStyle = '#d98a3a'; circ(c, -4, 0, 3); circ(c, 5, 4, 2.4); }
      else if (k === 'herb') { c.fillStyle = '#3f8a3a'; c.fillRect(-1, -4, 2, 16); c.fillStyle = col; circ(c, 0, -8, 6); circ(c, -7, 2, 4); circ(c, 7, 0, 4); }
      else if (k === 'fiber') { for (let i = -3; i <= 3; i++) c.fillRect(i * 3, -12, 1.6, 24); }
      else if (k === 'scale') { c.beginPath(); c.arc(0, -2, 12, Math.PI, 0); c.lineTo(0, 14); c.closePath(); c.fill(); }
      else if (k === 'charm') { circ(c, 0, 2, 9); c.fillStyle = '#ffd34d'; circ(c, 0, 2, 3); }
      else if (k === 'wood') { c.fillStyle = '#6b4a2b'; c.fillRect(-11, -8, 22, 16); c.fillStyle = col; circ(c, 0, 0, 5); }
    }
    iconCache.set(id, cv); return cv;
  };
  R.SKILL_ICON = { g_bulwark: '🛡', g_taunt: '📢', g_aegis: '💠', g_thorns: '🌵', g_fortress: '🏯', w_cleave: '🪓', w_charge: '💨', w_warcry: '📯', w_whirl: '🌀', w_execute: '⚔', m_fire: '🔥', m_ice: '❄', m_bolt: '⚡', m_heal: '✚', m_meteor: '☄', r_multi: '🏹', r_poison: '🐍', r_roll: '🍃', r_rain: '🌧', r_snipe: '🎯', a_backstab: '🗡', a_step: '👤', a_venom: '☠', a_fan: '✴', a_vanish: '🌑' };
  R.BUFF_ICON = { def_up: '🛡', mdef_up: '🔰', atk_up: '💪', reflect_up: '🌵', fortress: '🏯', haste: '💨', venom: '☠', vanish: '🌑', poison: '🤢', burn: '🔥', slow: '🐌', stun: '💫' };
})();
