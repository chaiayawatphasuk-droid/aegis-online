// REST API + WebSocket client
(function () {
  'use strict';
  const N = window.Net = { ws: null, token: localStorage.getItem('aegis_token') || '', cid: 0, handlers: {}, closedByUser: false, retry: 0 };
  N.api = async function (method, url, body) {
    const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json', ...(N.token ? { Authorization: 'Bearer ' + N.token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    let j = {}; try { j = await r.json(); } catch { }
    if (!r.ok) { const e = new Error(j.error || ('HTTP ' + r.status)); e.status = r.status; throw e; }
    return j;
  };
  N.setToken = t => { N.token = t; if (t) localStorage.setItem('aegis_token', t); else localStorage.removeItem('aegis_token'); };
  N.connect = function (cid) {
    N.cid = cid; N.closedByUser = false;
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = N.ws = new WebSocket(`${proto}//${location.host}/ws`);
    ws.onopen = () => { N.retry = 0; ws.send(JSON.stringify({ t: 'auth', token: N.token, cid })); N.emit('open'); };
    ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch { return; } N.emit(m.t, m); };
    ws.onclose = ev => {
      N.emit('close', ev);
      if (N.closedByUser || [4001, 4003, 4004].includes(ev.code)) return;
      N.retry++; setTimeout(() => { if (!N.closedByUser) N.connect(N.cid); }, Math.min(8000, 800 * N.retry));
    };
  };
  N.send = o => { if (N.ws && N.ws.readyState === 1) N.ws.send(JSON.stringify(o)); };
  N.close = () => { N.closedByUser = true; if (N.ws) N.ws.close(); };
  N.on = (t, fn) => { N.handlers[t] = fn; };
  N.emit = (t, m) => { const h = N.handlers[t]; if (h) try { h(m); } catch (e) { console.error('handler', t, e); } };
})();
