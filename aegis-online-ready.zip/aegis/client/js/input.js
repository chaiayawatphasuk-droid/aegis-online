// Keyboard + mouse + touch (virtual joystick, tap, pinch-zoom)
(function () {
  'use strict';
  const I = window.Input = { keys: new Set(), joy: { x: 0, y: 0, mag: 0, id: null }, mouse: { x: 0, y: 0, down: false }, walk: false, h: {}, touch: false };
  const typing = () => { const a = document.activeElement; return a && (a.tagName === 'INPUT' || a.tagName === 'SELECT' || a.tagName === 'TEXTAREA'); };
  const KEYMAP = { Digit1: 'skill0', Digit2: 'skill1', Digit3: 'skill2', Digit4: 'skill3', Digit5: 'skill4', Space: 'dodge', KeyQ: 'block', KeyE: 'interact', KeyF: 'potHp', KeyR: 'potMp', Tab: 'target', Escape: 'escape', Enter: 'chat', KeyI: 'p:inventory', KeyC: 'p:character', KeyK: 'p:skills', KeyJ: 'p:quests', KeyM: 'p:map', KeyP: 'p:party', KeyG: 'p:guild', KeyO: 'p:social', Equal: 'zoomIn', Minus: 'zoomOut', NumpadAdd: 'zoomIn', NumpadSubtract: 'zoomOut', KeyZ: 'toggleWalk' };
  I.move = function () {
    if (I.joy.id !== null) return { x: I.joy.x, y: I.joy.y, run: I.joy.mag > 0.7 };
    let x = 0, y = 0; const k = I.keys;
    if (k.has('KeyW') || k.has('ArrowUp')) y -= 1; if (k.has('KeyS') || k.has('ArrowDown')) y += 1;
    if (k.has('KeyA') || k.has('ArrowLeft')) x -= 1; if (k.has('KeyD') || k.has('ArrowRight')) x += 1;
    const l = Math.hypot(x, y); if (l) { x /= l; y /= l; }
    return { x, y, run: !(I.walk ^ (k.has('ShiftLeft') || k.has('ShiftRight'))) };
  };
  I.init = function (canvas, h) {
    I.h = h;
    I.touch = ('ontouchstart' in window) || navigator.maxTouchPoints > 0;
    if (I.touch && matchMedia('(pointer:coarse)').matches) document.body.classList.add('touch');
    window.addEventListener('keydown', e => {
      if (typing()) { if (e.code === 'Escape' || e.code === 'Enter') { h.action(KEYMAP[e.code], true, e); } return; }
      if (['Tab', 'Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
      if (e.repeat && KEYMAP[e.code] !== 'block') { I.keys.add(e.code); return; }
      I.keys.add(e.code); const a = KEYMAP[e.code]; if (a) h.action(a, true, e);
    });
    window.addEventListener('keyup', e => { I.keys.delete(e.code); const a = KEYMAP[e.code]; if (a === 'block') h.action('block', false, e); });
    window.addEventListener('blur', () => { I.keys.clear(); I.mouse.down = false; h.action('block', false); });
    canvas.addEventListener('contextmenu', e => e.preventDefault());
    canvas.addEventListener('mousemove', e => { I.mouse.x = e.clientX; I.mouse.y = e.clientY; h.hover && h.hover(e.clientX, e.clientY); });
    canvas.addEventListener('mousedown', e => {
      if (I.touch && e.sourceCapabilities && e.sourceCapabilities.firesTouchEvents) return;
      window.Audio2 && Audio2.init();
      I.mouse.x = e.clientX; I.mouse.y = e.clientY;
      if (e.button === 2) h.action('block', true); else if (e.button === 0) { I.mouse.down = true; h.click(e.clientX, e.clientY, false); }
    });
    window.addEventListener('mouseup', e => { if (e.button === 2) h.action('block', false); if (e.button === 0) I.mouse.down = false; });
    canvas.addEventListener('wheel', e => { e.preventDefault(); h.zoom(e.deltaY < 0 ? 1.1 : 1 / 1.1); }, { passive: false });
    // ---- touch ----
    const joy = document.getElementById('joystick'), knob = document.getElementById('joy-knob');
    let jc = null; const taps = new Map(); let pinch = null;
    const setKnob = (dx, dy) => { knob.style.transform = `translate(${dx}px,${dy}px)`; };
    canvas.addEventListener('touchstart', e => {
      e.preventDefault(); window.Audio2 && Audio2.init();
      for (const t of e.changedTouches) {
        if (t.clientX < innerWidth * 0.45 && I.joy.id === null) {
          I.joy.id = t.identifier; const r = joy.getBoundingClientRect();
          jc = { x: t.clientX, y: t.clientY };
          joy.style.left = (t.clientX - r.width / 2) + 'px'; joy.style.top = (t.clientY - r.height / 2) + 'px'; joy.style.bottom = 'auto';
        } else taps.set(t.identifier, { x: t.clientX, y: t.clientY, t: performance.now() });
      }
      if (taps.size === 2) { const [a, b] = [...taps.values()]; pinch = { d: Math.hypot(a.x - b.x, a.y - b.y) }; }
    }, { passive: false });
    canvas.addEventListener('touchmove', e => {
      e.preventDefault();
      for (const t of e.changedTouches) {
        if (t.identifier === I.joy.id) {
          let dx = t.clientX - jc.x, dy = t.clientY - jc.y; const l = Math.hypot(dx, dy), max = 50;
          if (l > max) { dx = dx / l * max; dy = dy / l * max; }
          I.joy.x = dx / max; I.joy.y = dy / max; I.joy.mag = Math.min(1, l / max);
          if (I.joy.mag < 0.15) { I.joy.x = I.joy.y = 0; }
          setKnob(dx, dy);
        } else if (taps.has(t.identifier)) { const tp = taps.get(t.identifier); tp.cx = t.clientX; tp.cy = t.clientY; }
      }
      if (pinch && taps.size === 2) {
        const [a, b] = [...taps.values()]; const d = Math.hypot((a.cx || a.x) - (b.cx || b.x), (a.cy || a.y) - (b.cy || b.y));
        if (Math.abs(d - pinch.d) > 6) { h.zoom(d / pinch.d); pinch.d = d; }
      }
    }, { passive: false });
    const end = e => {
      for (const t of e.changedTouches) {
        if (t.identifier === I.joy.id) { I.joy.id = null; I.joy.x = I.joy.y = I.joy.mag = 0; setKnob(0, 0); joy.style.left = ''; joy.style.top = ''; joy.style.bottom = ''; }
        const tp = taps.get(t.identifier);
        if (tp) { taps.delete(t.identifier); if (!pinch && performance.now() - tp.t < 300 && Math.hypot((tp.cx || tp.x) - tp.x, (tp.cy || tp.y) - tp.y) < 15) h.click(tp.x, tp.y, true); }
      }
      if (taps.size < 2) pinch = null;
    };
    canvas.addEventListener('touchend', end); canvas.addEventListener('touchcancel', end);
  };
})();
