// Game bootstrap: screens, network handlers, prediction, render loop, actions
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const TILE = GD.TILE;
  const WORLD = GD.buildWorld();
  const G = window.G = {
    inGame: false, me: null, self: null, stats: null, inv: [], eq: {}, quests: { a: {}, d: [] }, ents: new Map(), map: null, zone: -1,
    cds: {}, cdDur: {}, target: 0, party: null, guild: null, friends: [], lb: null, trade: null, zoom: 1, blocking: false, attackHeld: false,
    settings: Object.assign({ music: true, sfx: true, quality: matchMedia('(pointer:coarse)').matches ? 'low' : 'high', names: false }, JSON.parse(localStorage.getItem('aegis_settings') || '{}')),
    lastInput: { x: 0, y: 0, r: 1, t: 0 }, dash: null, nearInteract: null, arenaQ: 0
  };
  const Game = window.Game = {};
  const show = id => { document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden')); $('game').classList.add('hidden'); if (id === 'game') $('game').classList.remove('hidden'); else $(id).classList.remove('hidden'); };

  // ================= AUTH =================
  let authMode = 'login';
  document.querySelectorAll('.tabs button[data-tab]').forEach(b => b.onclick = () => { authMode = b.dataset.tab; document.querySelectorAll('.tabs button[data-tab]').forEach(x => x.classList.toggle('active', x === b)); $('auth-submit').textContent = authMode === 'login' ? 'Enter the World' : 'Create Account'; $('auth-err').textContent = ''; });
  $('auth-form').onsubmit = async e => {
    e.preventDefault(); $('auth-err').textContent = ''; $('auth-submit').disabled = true;
    try { const r = await Net.api('POST', '/api/' + authMode, { username: $('auth-user').value.trim(), password: $('auth-pass').value }); Net.setToken(r.token); await loadChars(); }
    catch (err) { $('auth-err').textContent = err.message; }
    $('auth-submit').disabled = false;
  };
  (function titleBg() {
    const cv = $('title-bg'), c = cv.getContext('2d'); const pts = Array.from({ length: 60 }, () => ({ x: Math.random(), y: Math.random(), s: Math.random() * 2 + 0.5, v: Math.random() * 0.02 + 0.005 }));
    (function loop() { if ($('screen-auth').classList.contains('hidden')) return setTimeout(loop, 500); cv.width = innerWidth; cv.height = innerHeight; c.fillStyle = '#ffe9a8'; for (const p of pts) { p.y -= p.v / 10; if (p.y < 0) p.y = 1; c.globalAlpha = 0.5 + Math.sin(Date.now() / 500 + p.x * 10) * 0.4; c.fillRect(p.x * cv.width, p.y * cv.height, p.s, p.s); } requestAnimationFrame(loop); })();
  })();

  // ================= CHARACTER SELECT =================
  async function loadChars() {
    let r; try { r = await Net.api('GET', '/api/characters'); } catch (e) { if (e.status === 401) { Net.setToken(''); show('screen-auth'); } else alert(e.message); return; }
    const list = $('char-list'); list.innerHTML = '';
    if (!r.chars.length) { openCreate(); return; }
    r.chars.forEach(ch => {
      const d = document.createElement('div'); d.className = 'char-card';
      d.innerHTML = `<button class="del" title="Delete">🗑</button><canvas width="110" height="110"></canvas><div><b>${ch.name}</b></div><div class="dim">Lv ${ch.level} ${GD.CLASSES[ch.cls].name}</div><button class="btn gold sm" style="margin-top:6px">Play</button>`;
      R.drawChar(d.querySelector('canvas').getContext('2d'), 55, 92, { app: ch.app, cls: ch.cls, scale: 1.8, t: 0 });
      d.querySelector('.btn').onclick = () => enterGame(ch.id);
      d.querySelector('.del').onclick = async ev => { ev.stopPropagation(); if (prompt(`Type ${ch.name} to delete permanently`) === ch.name) { try { await Net.api('DELETE', '/api/characters/' + ch.id); loadChars(); } catch (e) { alert(e.message); } } };
      list.appendChild(d);
    });
    $('btn-new-char').disabled = r.chars.length >= r.max;
    show('screen-chars');
  }
  $('btn-new-char').onclick = () => openCreate();
  $('btn-logout').onclick = () => Game.logout();

  // ================= CHARACTER CREATE =================
  const cc = { cls: 'guardian', app: { g: 'm', skin: 0, hair: 0, hc: 0, oc: 0, acc: 0 } };
  const CLS_ICON = { guardian: '🛡', warrior: '⚔', mage: '🔮', ranger: '🏹', assassin: '🗡' };
  function openCreate() {
    show('screen-create'); $('cc-err').textContent = '';
    const AP = GD.APPEARANCE;
    $('cc-classes').innerHTML = Object.keys(GD.CLASSES).map(k => `<button data-v="${k}" class="${cc.cls === k ? 'active' : ''}"><span>${CLS_ICON[k]}</span>${GD.CLASSES[k].name}</button>`).join('');
    const sw = (id, arr, key) => { $(id).innerHTML = arr.map((c, i) => `<button data-v="${i}" style="background:${c}" class="${cc.app[key] === i ? 'active' : ''}"></button>`).join(''); };
    sw('cc-skin', AP.skins, 'skin'); sw('cc-hc', AP.hairs, 'hc'); sw('cc-oc', AP.outfits, 'oc');
    $('cc-hair').innerHTML = AP.styles.map((s, i) => `<button data-v="${i}" class="${cc.app.hair === i ? 'active' : ''}">${s}</button>`).join('');
    $('cc-acc').innerHTML = AP.accs.map((s, i) => `<button data-v="${i}" class="${cc.app.acc === i ? 'active' : ''}">${s}</button>`).join('');
    const bind = (id, fn) => $(id).querySelectorAll('button').forEach(b => b.onclick = () => { $(id).querySelectorAll('button').forEach(x => x.classList.remove('active')); b.classList.add('active'); fn(b.dataset.v); descr(); });
    bind('cc-classes', v => cc.cls = v); bind('cc-g', v => cc.app.g = v); bind('cc-skin', v => cc.app.skin = +v); bind('cc-hair', v => cc.app.hair = +v);
    bind('cc-hc', v => cc.app.hc = +v); bind('cc-oc', v => cc.app.oc = +v); bind('cc-acc', v => cc.app.acc = +v);
    const descr = () => { const C = GD.CLASSES[cc.cls], b = C.base; $('cc-class-desc').innerHTML = `${C.desc}<br><span class="gold">HP ${b.hp} · MP ${b.mp} · ATK ${b.atk} · DEF ${b.def} · MATK ${b.matk} · CRIT ${b.crit}% · BLOCK ${b.block}%</span>`; };
    descr();
    const cv = $('create-preview'), c = cv.getContext('2d');
    (function loop(t) { if ($('screen-create').classList.contains('hidden')) return; c.clearRect(0, 0, 220, 220); const a = Math.PI / 2 + Math.sin(t / 1200) * 0.4; R.drawChar(c, 110, 180, { app: cc.app, cls: cc.cls, scale: 3, t: t / 1000, a, anim: 0 }); requestAnimationFrame(loop); })(0);
  }
  $('cc-back').onclick = () => loadChars();
  $('cc-create').onclick = async () => {
    $('cc-err').textContent = '';
    try { const r = await Net.api('POST', '/api/characters', { name: $('cc-name').value.trim(), cls: cc.cls, app: cc.app }); enterGame(r.id); }
    catch (e) { $('cc-err').textContent = e.message; }
  };

  // ================= ENTER GAME =================
  let started = false;
  function enterGame(cid) {
    show('game'); Audio2.init(); Game.applySettings();
    G.inGame = true; G.ents.clear(); G.self = null; G.stats = null; G.party = null; G.trade = null; G.target = 0;
    $('chat-log').innerHTML = '';
    if (!started) { started = true; initGame(); }
    Game.resize(); Net.connect(cid);
  }
  Game.exitToSelect = () => { Net.close(); G.inGame = false; UI.close(); loadChars(); };
  Game.logout = () => { Net.close(); G.inGame = false; UI.close(); Net.setToken(''); show('screen-auth'); };
  Game.applySettings = () => { localStorage.setItem('aegis_settings', JSON.stringify(G.settings)); R.quality = G.settings.quality; Audio2.setMusic(G.settings.music); Audio2.sfxOn = G.settings.sfx; Game.resize(); };
  Game.zoom = f => { G.zoom = Math.max(0.55, Math.min(2.2, G.zoom * f)); };
  Game.resize = () => {
    const cv = G.cv; if (!cv) return;
    G.dpr = Math.min(window.devicePixelRatio || 1, G.settings.quality === 'high' ? 2 : 1.25);
    cv.width = Math.round(innerWidth * G.dpr); cv.height = Math.round(innerHeight * G.dpr);
  };

  function initGame() {
    G.cv = $('cv'); G.ctx = G.cv.getContext('2d', { alpha: false });
    R.setMap(Object.assign({ kind: 'world' }, WORLD)); Game.worldImg = R.mapImg;
    G.zoom = innerWidth < 700 ? 0.8 : 1;
    window.addEventListener('resize', Game.resize);
    UI.init();
    Input.init(G.cv, { action: Game.action, click: onClick, zoom: Game.zoom, hover: onHover });
    requestAnimationFrame(frame);
    setInterval(slowTick, 250);
  }

  // ================= NETWORK =================
  const N = Net.on;
  N('open', () => $('conn-lost').classList.add('hidden'));
  N('close', ev => { if (G.inGame && !Net.closedByUser) $('conn-lost').classList.remove('hidden'); if (ev && [4001, 4003].includes(ev.code)) { G.inGame = false; setTimeout(() => { alert('Disconnected: session ended.'); if (ev.code === 4003) Game.logout(); else loadChars(); }, 50); } });
  N('err', m => UI.sys(m.m, '#ff7070'));
  N('init', m => {
    G.me = m; UI.buildActionBar(); UI.portrait();
    if (!m.tut) setTimeout(() => UI.tutorial(0), 800);
  });
  N('map', m => {
    G.ents.clear(); G.target = 0; R.FX.projs.clear(); R.FX.warns = []; G.self = null;
    if (m.kind === 'world') G.map = Object.assign({ id: m.id, kind: 'world', name: '' }, WORLD);
    else { const bin = atob(m.tiles), t = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) t[i] = bin.charCodeAt(i); G.map = { id: m.id, kind: m.kind, w: m.w, h: m.h, tiles: t, zone: null, name: m.name }; }
    R.setMap(G.map); if (m.kind === 'world') Game.worldImg = R.mapImg;
    if (m.kind !== 'world') { UI.zoneBanner({ name: m.name, lvl: [0, 0], pvp: m.kind === 'arena' }); $('zone-name').textContent = m.name; Audio2.play(m.kind === 'arena' ? 2 : 12); }
  });
  N('s', m => {
    const now = performance.now();
    if (m.a) for (const d of m.a) { const e = G.ents.get(d.id); if (e) Object.assign(e, d); else G.ents.set(d.id, Object.assign({ rx: d.x || 0, ry: d.y || 0, fresh: true }, d)); }
    if (m.r) for (const id of m.r) { G.ents.delete(id); if (G.target === id) G.target = 0; }
    for (const a of m.e) {
      const e = G.ents.get(a[0]); if (!e) continue;
      if (e.fresh) { e.rx = a[1]; e.ry = a[2]; e.fresh = false; }
      if ((a[6] === 2 || a[6] === 3) && e.anim !== a[6]) e.atkT = now;
      e.x = a[1]; e.y = a[2]; e.a = a[3]; e.hp = a[4]; e.mhp = a[5]; e.anim = a[6]; e.f = a[7];
    }
    const me = m.me;
    if (!G.self) G.self = { px: me[0], py: me[1], a: Math.PI / 2 };
    const s = G.self;
    if ((me[7] === 2 || me[7] === 3) && s.anim !== me[7]) s.atkT = now;
    Object.assign(s, { x: me[0], y: me[1], hp: me[2], mhp: me[3], mp: me[4], mmp: me[5], sh: me[6], anim: me[7], f: me[8] });
    const dx = me[0] - s.px, dy = me[1] - s.py, d = Math.hypot(dx, dy), moving = G.lastInput.x || G.lastInput.y || G.dash;
    if (d > 160) { s.px = me[0]; s.py = me[1]; } else { const k = moving ? 0.08 : 0.35; s.px += dx * k; s.py += dy * k; }
    $('death').classList.toggle('hidden', !(me[8] & 8));
  });
  N('me', m => {
    const prev = G.stats; m._t = performance.now(); G.stats = m;
    if (prev && m.lv > prev.lv) { UI.center(`LEVEL UP!  ${m.lv}`, 3000); Audio2.sfx('level'); }
    UI.refreshIf('character', 'skills', 'npc', 'inventory');
  });
  N('inv', m => { G.inv = m.inv; G.eq = m.eq; UI.refreshIf('inventory', 'npc', 'quests', 'trade'); });
  N('q', m => { G.quests = m; UI.refreshIf('quests', 'npc'); if (Object.keys(m.a).length && UI.tutStep === 1) UI.tutorial(2); });
  N('f', m => {
    const s = G.self;
    for (const f of m.l) {
      const [x, y, k] = f;
      if (k === 'd') { R.fxDamage(x, y, f[3], f[4]); if (s && Math.abs(x - s.px) < 500 && Math.abs(y - s.py) < 500) Audio2.sfx(f[4] === 1 ? 'crit' : f[4] === 3 ? 'block' : f[4] === 5 ? 'hurt' : f[4] === 0 ? 'hit' : 'ui'); }
      else if (k === 'f') { R.fxSpawn(f[3], x, y, f[4], f[5]); if (f[3].includes('slash')) Audio2.sfx('swing'); }
      else if (k === 'p') R.fxProj(f[3], x, y, f[5], f[6], f[7], f[4]);
      else if (k === 'px') R.fxProjEnd(f[3]);
      else if (k === 'w') R.fxWarn(x, y, f[3], f[4], f[5]);
      else if (k === 'c') R.fxChain(f[3]);
    }
  });
  N('m', m => { UI.sys(m.m, m.c); if (/Quest complete|Feat unlocked|World Event|defeated .*!|cleared/.test(m.m)) UI.center(m.m, 3500); if (/killed|Looted/.test(m.m)) Audio2.sfx('pickup'); });
  N('chat', m => UI.chatMsg(m));
  N('cd', m => { G.cds[m.k] = performance.now() + m.ms; G.cdDur[m.k] = m.ms; });
  N('zone', m => {
    G.zone = m.z; if (m.z < 0) return;
    const z = GD.ZONES[m.z]; UI.zoneBanner(z); Audio2.play(z.music);
    if (UI.tutStep === 2 && !z.safe) { /* left town */ }
  });
  N('npc', m => { const n = G.ents.get(m.id); if (n) { UI.openNpc(n); UI.tutEvent('npc'); } });
  N('portal', m => { const D = GD.DUNGEONS[m.dk]; if (confirm(`Enter ${D.name}? (Lv ${D.lvl}+)${G.party && G.party.m && G.party.m.length ? '\nYour party will share this instance.' : ''}`)) Net.send({ t: 'de', k: m.dk }); });
  N('respawn', () => $('death').classList.add('hidden'));
  N('party', m => { G.party = m.m && m.m.length ? m : null; UI.refreshIf('party'); });
  N('pinv', m => UI.invite(`${m.from} invites you to a party`, () => Net.send({ t: 'pa' })));
  N('ginv', m => UI.invite(`${m.from} invites you to guild «${m.g}»`, () => Net.send({ t: 'ga' })));
  N('treq', m => UI.invite(`${m.from} wants to trade`, () => Net.send({ t: 'ta' })));
  N('guild', m => { G.guild = m.g; UI.refreshIf('guild'); });
  N('friends', m => { G.friends = m.l; UI.refreshIf('social'); });
  N('lb', m => { G.lb = m; UI.refreshIf('social'); });
  N('trade', m => {
    if (m.close) { G.trade = null; if (UI.panel === 'trade') UI.close(); else UI.refreshIf('inventory'); return; }
    G.trade = m; if (UI.panel !== 'trade' && UI.panel !== 'inventory') UI.open('trade'); else UI.refresh();
  });
  N('aq', m => { G.arenaQ = m.mode; UI.refreshIf('npc'); });

  // ================= ACTIONS =================
  const enemy = e => e && e.hp > 0 && (e.k === 'm' || (e.k === 'p' && (((e.f & 2048) && (G.self.f & 4096)) || ((e.f & 4096) && (G.self.f & 2048)) || ((e.f & 4) && (G.self.f & 4) && G.zone >= 0 && GD.ZONES[G.zone].pvp))));
  const dist = (e) => Math.hypot(e.x - G.self.px, e.y - G.self.py);
  function nearestEnemy(range) { let best = null, bd = range; for (const e of G.ents.values()) if (enemy(e)) { const d = dist(e); if (d < bd) { bd = d; best = e; } } return best; }
  function screenToWorld(sx, sy) { const z = G.zoom; return [G.self.px + (sx - innerWidth / 2) / z, G.self.py - 10 + (sy - innerHeight / 2) / z]; }
  function aimPoint() {
    const t = G.ents.get(G.target);
    if (t && enemy(t)) return [t.x, t.y, t.id];
    if (!document.body.classList.contains('touch') && G.mouseOnCanvas) { const [x, y] = screenToWorld(Input.mouse.x, Input.mouse.y); return [x, y, undefined]; }
    const n = nearestEnemy(450); if (n) { G.target = n.id; return [n.x, n.y, n.id]; }
    return [G.self.px + Math.cos(G.self.a) * 150, G.self.py + Math.sin(G.self.a) * 150, undefined];
  }
  function attack(mouseAim) {
    const now = performance.now(), B = GD.CLASSES[G.me.cls].basic;
    if (!G.self || (G.cds._b || 0) > now || G.blocking || (G.self.f & 8)) return;
    G.cds._b = now + B.cd;
    let x, y, id;
    if (mouseAim) { [x, y] = screenToWorld(Input.mouse.x, Input.mouse.y); const t = G.ents.get(G.target); if (t && enemy(t) && Math.hypot(t.x - x, t.y - y) < 40) id = t.id; }
    else { const t = G.ents.get(G.target); if (!(t && enemy(t) && dist(t) < B.range + 300)) { const n = nearestEnemy(B.range + 250); if (n) G.target = n.id; } [x, y, id] = aimPoint(); }
    const a = Math.atan2(y - G.self.py, x - G.self.px); G.self.a = a;
    Net.send({ t: 'a', a, id });
  }
  Game.action = function (act, down, ev) {
    if (!G.inGame || !G.self) return;
    if (act === 'block') { if (G.blocking !== !!down) { G.blocking = !!down; Net.send({ t: 'b', on: G.blocking ? 1 : 0 }); } return; }
    if (!down) return;
    const now = performance.now();
    if (act === 'attack') attack(false);
    else if (act.startsWith('skill')) {
      const sid = GD.CLASSES[G.me.cls].skills[+act.slice(5)], S = GD.SKILLS[sid];
      if (G.stats.lv < S.lvl) return UI.sys(`${S.n} unlocks at level ${S.lvl}.`, '#aaa');
      if ((G.cds[sid] || 0) > now) return;
      if (G.self.mp < S.mp) return UI.center('Not enough MP', 900);
      const [x, y, id] = aimPoint();
      Net.send({ t: 's', k: sid, x: Math.round(x), y: Math.round(y), id });
    } else if (act === 'dodge') {
      if ((G.cds._d || 0) > now) return;
      const mv = Input.move(); let dx = mv.x, dy = mv.y;
      if (!dx && !dy) { dx = Math.cos(G.self.a); dy = Math.sin(G.self.a); }
      G.dash = { vx: dx * 560, vy: dy * 560, end: now + 250 }; Audio2.sfx('dodge');
      Net.send({ t: 'd', x: dx, y: dy });
    } else if (act === 'potHp') Net.send({ t: 'pot', k: 'hp' });
    else if (act === 'potMp') Net.send({ t: 'pot', k: 'mp' });
    else if (act === 'interact') { const n = G.nearInteract; if (n && n.k === 'n') { UI.openNpc(n); UI.tutEvent('npc'); } else Net.send({ t: 'e' }); }
    else if (act === 'target') {
      const list = [...G.ents.values()].filter(e => enemy(e) && dist(e) < 650).sort((a, b) => dist(a) - dist(b));
      if (!list.length) { G.target = 0; return; } const i = list.findIndex(e => e.id === G.target); G.target = list[(i + 1) % list.length].id;
    } else if (act === 'escape') { if (document.activeElement === $('chat-input')) { $('chat-input').blur(); $('chat-input-row').classList.add('hidden'); } else if (UI.panel) UI.close(); else UI.open('settings'); }
    else if (act === 'chat') { if (document.activeElement !== $('chat-input')) { UI.openChat(); ev && ev.preventDefault(); } }
    else if (act.startsWith('p:')) UI.toggle(act.slice(2));
    else if (act === 'zoomIn') Game.zoom(1.15); else if (act === 'zoomOut') Game.zoom(1 / 1.15);
    else if (act === 'toggleWalk') { Input.walk = !Input.walk; UI.sys(Input.walk ? 'Walk mode' : 'Run mode'); }
  };
  function entityAt(wx, wy) {
    let best = null, bd = Infinity;
    for (const e of G.ents.values()) {
      const r = e.k === 'm' ? (GD.MONSTERS[e.m].size + 10) : 22, cy = e.k === 'o' || e.k === 'l' ? e.ry - 8 : e.ry - 16;
      const d = Math.hypot(e.rx - wx, cy - wy); if (d < r && d < bd) { bd = d; best = e; }
    }
    return best;
  }
  function onHover(sx, sy) { G.mouseOnCanvas = true; if (!G.self) return; const [wx, wy] = screenToWorld(sx, sy); const e = entityAt(wx, wy); G.hover = e ? e.id : 0; G.cv.style.cursor = e ? (e.k === 'm' ? 'crosshair' : 'pointer') : 'default'; }
  function onClick(sx, sy, tap) {
    if (!G.self) return;
    if (document.activeElement === $('chat-input')) $('chat-input').blur();
    const [wx, wy] = screenToWorld(sx, sy), e = entityAt(wx, wy);
    if (e) {
      if (e.k === 'n') { Input.mouse.down = false; if (dist(e) < 170) { UI.openNpc(e); UI.tutEvent('npc'); } else UI.center('Move closer to talk', 1000); return; }
      if (e.k === 'o' || e.k === 'l') { Input.mouse.down = false; if (dist(e) < 110) Net.send({ t: 'ie', id: e.id }); else UI.center('Move closer', 900); return; }
      G.target = e.id;
      if (tap || !enemy(e)) { Input.mouse.down = false; return; }
    } else if (tap) { G.target = 0; return; }
    attack(true);
  }

  // ================= LOOP =================
  let last = performance.now();
  function frame(ts) {
    const dt = Math.min(0.05, (ts - last) / 1000); last = ts; R.t += dt;
    if (G.inGame && G.self && G.map) {
      sendInput(); predict(dt);
      if (Input.mouse.down && G.mouseOnCanvas && !document.body.classList.contains('touch')) attack(true);
      if (G.attackHeld) attack(false);
      interpolate(dt); R.updateFx(dt); draw(); UI.updateHud();
    }
    requestAnimationFrame(frame);
  }
  function sendInput() {
    const typing = document.activeElement && document.activeElement.tagName === 'INPUT';
    const mv = typing ? { x: 0, y: 0, run: true } : Input.move(), now = performance.now(), L = G.lastInput;
    const qx = Math.round(mv.x * 20) / 20, qy = Math.round(mv.y * 20) / 20, r = mv.run ? 1 : 0;
    if (qx !== L.x || qy !== L.y || r !== L.r || ((qx || qy) && now - L.t > 400)) {
      Net.send({ t: 'i', x: qx, y: qy, r }); G.lastInput = { x: qx, y: qy, r, t: now };
      if ((qx || qy) && UI.tutStep === 0) UI.tutorial(1);
    }
  }
  function predict(dt) {
    const s = G.self, st = G.stats; if (!st || (s.f & 8)) return;
    const now = performance.now(), L = G.lastInput, b = {}; (st.buffs || []).forEach(([k, ms]) => { if (ms - (now - st._t) > 0) b[k] = 1; });
    let vx = 0, vy = 0;
    if (G.dash && now < G.dash.end) { vx = G.dash.vx; vy = G.dash.vy; } else {
      G.dash = null; if (s.f & 16) return;
      let sp = st.st.spd * (L.r ? 1 : 0.55); if (G.blocking) sp *= 0.45; if (b.haste) sp *= 1.4; if (s.f & 128) sp *= 0.6;
      vx = L.x * sp; vy = L.y * sp;
    }
    if (!vx && !vy) return;
    const [nx, ny] = GD.tryMove(G.map, s.px, s.py, s.px + vx * dt, s.py + vy * dt, 10);
    if (G.map.kind === 'world') { const z = GD.ZONES[GD.zoneAt(G.map, nx, ny)]; if (z.req > st.lv) return; }
    s.px = nx; s.py = ny;
    if (L.x || L.y) s.a = Math.atan2(L.y, L.x);
  }
  function interpolate(dt) {
    const k = 1 - Math.exp(-dt * 14);
    for (const e of G.ents.values()) {
      if (e.x === undefined) continue;
      const dx = e.x - e.rx, dy = e.y - e.ry;
      if (Math.abs(dx) > 300 || Math.abs(dy) > 300) { e.rx = e.x; e.ry = e.y; } else { e.rx += dx * k; e.ry += dy * k; }
    }
  }
  function slowTick() {
    if (!G.inGame || !G.self) return;
    let best = null, bd = 90;
    for (const e of G.ents.values()) if ((e.k === 'n' || e.k === 'o' || e.k === 'l') && !(e.st === 'res' && !e.avail)) { const d = dist(e); if (d < bd) { bd = d; best = e; } }
    G.nearInteract = best;
    if (G.map.kind === 'world' && G.zone >= 0) Audio2.play(G.bossNear ? 11 : GD.ZONES[G.zone].music);
    drawMinimap();
    if (UI.tutStep === 2 && G.quests && G.quests.a.q1 && G.quests.a.q1.p[0] > 0) UI.tutorial(3);
  }

  // ================= DRAW =================
  function draw() {
    const c = G.ctx, cv = G.cv, s = G.self, W = cv.width, H = cv.height, z = G.zoom * G.dpr;
    const camx = s.px, camy = s.py - 10, now = performance.now();
    c.setTransform(1, 0, 0, 1, 0, 0); c.fillStyle = '#0b0d16'; c.fillRect(0, 0, W, H);
    c.setTransform(z, 0, 0, z, Math.round(W / 2 - camx * z), Math.round(H / 2 - camy * z));
    const vw = W / z, vh = H / z, x0 = camx - vw / 2, y0 = camy - vh / 2;
    R.drawWorld(c, x0, y0, x0 + vw, y0 + vh);
    const tgt = G.ents.get(G.target);
    if (tgt) { c.strokeStyle = enemy(tgt) ? '#ff5a5a' : '#7fd4ff'; c.lineWidth = 2; c.beginPath(); c.ellipse(tgt.rx, tgt.ry, (tgt.k === 'm' ? GD.MONSTERS[tgt.m].size : 12) + 6, 7, 0, 0, Math.PI * 2); c.stroke(); }
    R.drawFxUnder(c);
    const list = [], M = 90;
    for (const e of G.ents.values()) { const ex = e.rx, ey = e.ry; if (ex < x0 - M || ex > x0 + vw + M || ey < y0 - M || ey > y0 + vh + M * 1.5) continue; list.push(e); }
    list.push(SELF); SELF.ry = s.py;
    list.sort((a, b) => a.ry - b.ry);
    const lowDetail = R.quality === 'low';
    for (const e of list) {
      if (e === SELF) { drawPlayer(c, { rx: s.px, ry: s.py, a: s.a, anim: s.anim, f: s.f, hp: s.hp, mhp: s.mhp, ap: G.me.app, c: G.me.cls, n: G.me.name, lv: G.stats ? G.stats.lv : 1, g: G.stats && G.stats.gname, atkT: s.atkT, id: G.me.id, bubble: s.bubble, bubbleT: s.bubbleT }, now, true); continue; }
      const far = lowDetail || Math.abs(e.rx - s.px) > 600 || Math.abs(e.ry - s.py) > 450;
      if (e.k === 'p') drawPlayer(c, e, now, false);
      else if (e.k === 'm') {
        const d = GD.MONSTERS[e.m]; if (!d) continue;
        if (e.f & 256) continue;
        R.drawMonster(c, e.rx, e.ry, d, { t: R.t + e.id * 0.37, anim: e.anim, flipX: Math.cos(e.a) < 0, far });
        const showName = G.settings.names || e.id === G.target || e.id === G.hover || (e.f & 512);
        const top = e.ry - d.size * 2.4 - 18;
        if (e.hp < e.mhp || e.id === G.target) hpBar(c, e.rx, top + 4, 36, e.hp / e.mhp, '#e04a4a');
        if (showName) label(c, `${d.n} Lv${e.lv}`, e.rx, top - 2, d.boss ? '#ffb38a' : e.lv > G.stats.lv + 4 ? '#ff8a8a' : '#ffffff');
        statusIcons(c, e, e.rx, top - (showName ? 14 : 2));
      } else if (e.k === 'n') {
        const app = e._app || (e._app = R.npcApp(e));
        R.drawChar(c, e.rx, e.ry, { app, cls: e.role === 'blacksmith' ? 'warrior' : e.role === 'trainer' ? 'mage' : e.role === 'arena' ? 'warrior' : null, outfit: e.col, t: R.t + e.id, a: Math.PI / 2, anim: 0 });
        const qIcon = e.role === 'quest' && questAvailable();
        c.font = '800 16px Nunito,sans-serif'; c.textAlign = 'center';
        c.fillStyle = qIcon ? '#ffd34d' : '#e8e8ff'; c.strokeStyle = '#000'; c.lineWidth = 3;
        const ic = R.ROLE_ICON[e.role], iy = e.ry - 58 + Math.sin(R.t * 3) * 2; c.strokeText(ic, e.rx, iy); c.fillText(ic, e.rx, iy);
        label(c, e.n, e.rx, e.ry - 46, '#ffe9a8');
      } else if (e.k === 'e') {
        R.drawChar(c, e.rx, e.ry, { app: { g: 'f', skin: 1, hair: 1, hc: 3, oc: 6, acc: 2 }, cls: null, t: R.t, a: e.a, anim: e.anim });
        hpBar(c, e.rx, e.ry - 52, 36, e.hp / e.mhp, '#7fe07f'); label(c, 'Pilgrim Mara', e.rx, e.ry - 56, '#9fe870');
      } else R.drawObject(c, e, R.t);
      if (e.bubble && e.bubbleT > now) bubble(c, e.bubble, e.rx, e.ry - 70);
    }
    if (G.nearInteract && !document.body.classList.contains('touch')) { const n = G.nearInteract; label(c, '[E]', n.rx, n.ry + 18, '#ffd34d'); }
    R.drawFx(c); R.drawDmg(c);
    // darkness for caves / dungeons
    const dark = G.map.kind === 'dungeon' || (G.zone >= 0 && GD.ZONES[G.zone].id === 'cave');
    c.setTransform(1, 0, 0, 1, 0, 0);
    if (dark) { const gr = c.createRadialGradient(W / 2, H / 2, 80 * z, W / 2, H / 2, Math.max(W, H) * 0.6); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,10,0.72)'); c.fillStyle = gr; c.fillRect(0, 0, W, H); }
    if (s.hp / s.mhp < 0.25 && !(s.f & 8)) { c.fillStyle = `rgba(160,0,0,${0.12 + Math.sin(R.t * 6) * 0.06})`; c.fillRect(0, 0, W, H); }
  }
  const SELF = { k: 'self' };
  function questAvailable() { const q = G.quests; if (!q || !G.stats) return false; for (const id in GD.QUESTS) { const Q = GD.QUESTS[id]; if (q.d.includes(id)) continue; const a = q.a[id]; if (a) { if (Q.obj.every((o, i) => UI.objDone(o, a.p[i]))) return true; continue; } if ((!Q.pre || q.d.includes(Q.pre)) && Q.lvl <= G.stats.lv) return true; } return false; }
  function drawPlayer(c, e, now, isSelf) {
    if ((e.f & 256) && !isSelf) return;
    const atkP = e.atkT && now - e.atkT < 260 ? (now - e.atkT) / 260 : -1;
    if (e.f & 256) c.globalAlpha = 0.4;
    R.drawChar(c, e.rx, e.ry, { app: e.ap, cls: e.c, a: e.a, anim: e.anim, t: R.t + (e.id || 0) * 0.3, atkP, blocking: e.f & 1, dead: e.f & 8, dodge: e.anim === 6 });
    c.globalAlpha = 1;
    if (e.f & 2) { c.strokeStyle = 'rgba(140,210,255,0.8)'; c.fillStyle = 'rgba(140,210,255,0.12)'; c.lineWidth = 2; c.beginPath(); c.arc(e.rx, e.ry - 18, 24, 0, Math.PI * 2); c.fill(); c.stroke(); }
    if (e.f & 64) { c.strokeStyle = `rgba(255,211,77,${0.4 + Math.sin(R.t * 5) * 0.2})`; c.lineWidth = 2; c.beginPath(); c.ellipse(e.rx, e.ry, 16, 6, 0, 0, Math.PI * 2); c.stroke(); }
    const inParty = G.party && G.party.m && G.party.m.some(m => m.id === e.id);
    const col = isSelf ? '#ffffff' : (e.f & 2048) ? '#7fb6ff' : (e.f & 4096) ? '#ff8a8a' : inParty ? '#7fe07f' : (e.f & 4) ? '#ff9a6a' : '#dfe6ff';
    if (!isSelf && e.hp < e.mhp) hpBar(c, e.rx, e.ry - 52, 34, e.hp / e.mhp, inParty ? '#5fd16a' : '#e04a4a');
    label(c, `${e.n}${e.lv ? ' Lv' + e.lv : ''}`, e.rx, e.ry - 56, col);
    if (e.g) label(c, `«${e.g}»`, e.rx, e.ry - 68, '#7fe0a0', 10);
    statusIcons(c, e, e.rx, e.ry - (e.g ? 80 : 68));
    if (e.bubble && e.bubbleT > now && isSelf) bubble(c, e.bubble, e.rx, e.ry - 84);
  }
  function statusIcons(c, e, x, y) {
    const ic = []; if (e.f & 32) ic.push('☠'); if (e.f & 128) ic.push('🐌'); if (e.f & 16) ic.push('💫'); if (e.f & 1024) ic.push('❗');
    if (!ic.length) return; c.font = '11px sans-serif'; c.textAlign = 'center'; c.fillText(ic.join(''), x, y);
  }
  function label(c, t, x, y, col, size) { c.font = `800 ${size || 11}px Nunito,sans-serif`; c.textAlign = 'center'; c.lineWidth = 3; c.strokeStyle = '#000b'; c.strokeText(t, x, y); c.fillStyle = col; c.fillText(t, x, y); }
  function hpBar(c, x, y, w, p, col) { c.fillStyle = '#000a'; c.fillRect(x - w / 2 - 1, y - 1, w + 2, 6); c.fillStyle = col; c.fillRect(x - w / 2, y, w * Math.max(0, Math.min(1, p)), 4); }
  function bubble(c, t, x, y) { c.font = '700 11px Nunito,sans-serif'; const w = Math.min(180, c.measureText(t).width + 12); c.fillStyle = '#fffe'; R.rrect(c, x - w / 2, y - 16, w, 18, 6); c.fill(); c.fillStyle = '#222'; c.textAlign = 'center'; c.fillText(t.length > 30 ? t.slice(0, 30) + '…' : t, x, y - 3); }
  function drawMinimap() {
    const cv = $('minimap'), c = cv.getContext('2d'), s = G.self, img = R.mapImg; if (!img) return;
    const S = 140, span = G.map.kind === 'world' ? 90 : Math.max(G.map.w, G.map.h), sc = S / span, tx = s.px / TILE, ty = s.py / TILE;
    c.save(); c.clearRect(0, 0, S, S); c.beginPath(); c.arc(S / 2, S / 2, S / 2, 0, Math.PI * 2); c.clip();
    c.fillStyle = '#000'; c.fillRect(0, 0, S, S); c.imageSmoothingEnabled = false;
    c.drawImage(img, tx - span / 2, ty - span / 2, span, span, 0, 0, S, S);
    const dot = (e, col, r) => { const x = S / 2 + (e.x / TILE - tx) * sc, y = S / 2 + (e.y / TILE - ty) * sc; c.fillStyle = col; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill(); };
    for (const e of G.ents.values()) { if (e.x === undefined) continue; if (e.k === 'm') dot(e, (e.f & 512) ? '#ff00ff' : '#ff4a4a', (e.f & 512) ? 4 : 1.8); else if (e.k === 'p') dot(e, G.party && G.party.m && G.party.m.some(m => m.id === e.id) ? '#7fe07f' : '#7fb6ff', 2.5); else if (e.k === 'n') dot(e, '#ffd34d', 2.5); else if (e.st === 'portal' || e.st === 'exit') dot(e, '#d07aff', 3.5); }
    c.fillStyle = '#fff'; c.beginPath(); c.arc(S / 2, S / 2, 3.5, 0, Math.PI * 2); c.fill();
    c.restore();
  }

  // ================= BOOT =================
  document.addEventListener('visibilitychange', () => { if (document.hidden && G.blocking) Game.action('block', false); });
  if (Net.token) loadChars(); else show('screen-auth');
})();
