// HUD + panels + NPC dialogs
(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const UI = window.UI = { panel: null, opts: {}, sel: null, hudT: 0 };
  const send = o => Net.send(o);
  const G = () => window.G;

  // ---------------- HUD ----------------
  UI.init = function () {
    $('panel-close').onclick = () => UI.close();
    document.querySelectorAll('#side-menu button[data-p]').forEach(b => b.onclick = () => { UI.toggle(b.dataset.p); $('side-menu').classList.remove('open'); });
    $('btn-menu').onclick = () => $('side-menu').classList.toggle('open');
    $('btn-worldmap').onclick = () => UI.toggle('map');
    $('btn-zin').onclick = () => window.Game.zoom(1.15); $('btn-zout').onclick = () => window.Game.zoom(1 / 1.15);
    $('btn-chat-mobile').onclick = () => { $('chat').classList.toggle('open'); $('chat-input-row').classList.toggle('hidden'); if (!$('chat-input-row').classList.contains('hidden')) $('chat-input').focus(); };
    $('btn-interact').onclick = () => window.Game.action('interact', true);
    $('chat-input').addEventListener('keydown', e => { if (e.key === 'Enter') { UI.sendChat(); e.preventDefault(); e.stopPropagation(); } if (e.key === 'Escape') { $('chat-input').blur(); $('chat-input-row').classList.add('hidden'); } });
    UI.buildActionBar();
  };
  UI.buildActionBar = function () {
    const g = G(); if (!g || !g.me) return;
    const sk = GD.CLASSES[g.me.cls].skills;
    const bar = $('action-bar'); bar.innerHTML = '';
    const mk = (key, icon, act, id, label) => { const b = document.createElement('button'); b.className = 'slot'; b.dataset.cd = id; b.innerHTML = `<span class="key">${key}</span>${icon}<div class="cd"></div><div class="cdt"></div>${label ? `<span class="cnt">${label}</span>` : ''}`; b.onmousedown = e => { e.preventDefault(); window.Game.action(act, true); }; b.onmouseup = () => act === 'block' && window.Game.action(act, false); b.title = label || act; return b; };
    sk.forEach((s, i) => { const b = mk(i + 1, R.SKILL_ICON[s], 'skill' + i, s); b.title = GD.SKILLS[s].n; b.onmouseenter = e => UI.tip(e, UI.skillTip(s)); b.onmouseleave = () => UI.tip(); bar.appendChild(b); });
    bar.appendChild(mk('Spc', '💨', 'dodge', '_d')); bar.appendChild(mk('Q', '✋', 'block', '_blk'));
    bar.appendChild(mk('F', '🧪', 'potHp', '_pot', '')); bar.appendChild(mk('R', '🔷', 'potMp', '_pot2', ''));
    // mobile radial buttons
    const ma = $('mobile-actions'); ma.innerHTML = '';
    const arc = (R, deg) => { const a = deg * Math.PI / 180; return [Math.round(39 + R * Math.cos(a) - 23), Math.round(39 + R * Math.sin(a) - 23)]; };
    const pos = [0, 22.5, 45, 67.5, 90].map(d => arc(128, d));
    const mmk = (cls, icon, act, id, x, y, hold) => {
      const b = document.createElement('button'); b.className = 'slot ' + cls; b.dataset.cd = id || ''; b.innerHTML = `${icon}<div class="cd"></div><div class="cdt"></div>`;
      if (x !== undefined) { b.style.right = x + 'px'; b.style.bottom = y + 'px'; }
      b.addEventListener('touchstart', e => { e.preventDefault(); window.Audio2 && Audio2.init(); window.Game.action(act, true); if (act === 'attack') G().attackHeld = true; }, { passive: false });
      b.addEventListener('touchend', e => { e.preventDefault(); if (hold) window.Game.action(act, false); if (act === 'attack') G().attackHeld = false; });
      ma.appendChild(b); return b;
    };
    mmk('big', '⚔', 'attack', '');
    sk.forEach((s, i) => mmk('', R.SKILL_ICON[s], 'skill' + i, s, pos[i][0], pos[i][1]));
    mmk('', '💨', 'dodge', '_d', ...arc(192, 2)); mmk('', '✋', 'block', '_blk', ...arc(192, 30), true);
    mmk('', '🧪', 'potHp', '_pot', ...arc(192, 60)); mmk('', '🎯', 'target', '', ...arc(192, 88));
  };
  UI.updateHud = function () {
    const g = G(), s = g.self, st = g.stats; if (!s || !st) return;
    const now = performance.now(); if (now - UI.hudT < 90) return; UI.hudT = now;
    $('hp-fill').style.width = (s.hp / s.mhp * 100) + '%'; $('hp-txt').textContent = `${s.hp} / ${s.mhp}`;
    $('sh-fill').style.width = Math.min(100, s.sh / s.mhp * 100) + '%';
    $('mp-fill').style.width = (s.mp / s.mmp * 100) + '%'; $('mp-txt').textContent = `${s.mp} / ${s.mmp}`;
    $('xp-fill').style.width = (st.exp / st.nx * 100) + '%'; $('xp-txt').textContent = `EXP ${st.exp} / ${st.nx}`;
    $('hud-lv').textContent = st.lv; $('hud-name').textContent = g.me.name + (st.gname ? ` «${st.gname}»` : '') + (st.pvp ? ' ⚔' : '');
    // buffs
    const bh = (st.buffs || []).map(([k, ms]) => { const left = Math.max(0, ms - (now - st._t)); return left > 0 ? `<div class="buff" title="${k}">${R.BUFF_ICON[k] || '•'}<b>${Math.ceil(left / 1000)}</b></div>` : ''; }).join('');
    if ($('buffs')._h !== bh) { $('buffs').innerHTML = bh; $('buffs')._h = bh; }
    // cooldowns
    document.querySelectorAll('[data-cd]').forEach(b => {
      const k = b.dataset.cd; if (!k) return;
      const key = k === '_pot2' ? '_pot' : k, end = g.cds[key] || 0, dur = g.cdDur[key] || 1, left = end - now;
      const cd = b.querySelector('.cd'), cdt = b.querySelector('.cdt');
      if (left > 0) { cd.style.transform = `scaleY(${left / dur})`; cdt.textContent = left > 1000 ? Math.ceil(left / 1000) : ''; } else { cd.style.transform = 'scaleY(0)'; cdt.textContent = ''; }
      const sk = GD.SKILLS[k]; if (sk) b.classList.toggle('locked', st.lv < sk.lvl);
      if (k === '_blk') b.classList.toggle('active', g.blocking);
      if (k === '_pot' || k === '_pot2') { const c = b.querySelector('.cnt'); if (c) c.textContent = UI.potCount(k === '_pot' ? 'heal' : 'mana'); }
    });
    // target
    const t = g.target && g.ents.get(g.target);
    if (t && t.hp > 0) {
      $('target-frame').classList.remove('hidden');
      const nm = t.k === 'm' ? GD.MONSTERS[t.m].n : t.n;
      $('tf-name').innerHTML = `${esc(nm)} <span class="${t.lv > st.lv + 4 ? 'bad' : t.lv < st.lv - 5 ? 'dim' : 'gold'}">Lv ${t.lv || ''}</span>`;
      $('tf-fill').style.width = (t.hp / t.mhp * 100) + '%'; $('tf-txt').textContent = `${t.hp} / ${t.mhp}`;
    } else $('target-frame').classList.add('hidden');
    // boss
    let boss = null; for (const e of g.ents.values()) if (e.k === 'm' && (e.f & 512) && e.hp > 0) { boss = e; break; }
    if (boss) { $('boss-bar').classList.remove('hidden'); $('bb-name').textContent = GD.MONSTERS[boss.m].n; $('bb-fill').style.width = (boss.hp / boss.mhp * 100) + '%'; $('bb-txt').textContent = `${boss.hp} / ${boss.mhp}`; }
    else $('boss-bar').classList.add('hidden');
    g.bossNear = !!boss;
    // party frames
    const pf = (g.party && g.party.m || []).filter(m => m.id !== g.me.id).map(m => `<div class="pf ${m.id === g.party.leader ? 'lead' : ''} ${m.dead ? 'dead' : ''}"><span class="n">${esc(m.n)}</span> <span class="dim">Lv${m.lv} ${GD.CLASSES[m.c].name}</span><div class="bar hp"><i style="width:${m.hp / m.mhp * 100}%"></i></div><div class="bar mp" style="height:4px"><i style="width:${m.mp / m.mmp * 100}%"></i></div></div>`).join('');
    if ($('party-frames')._h !== pf) { $('party-frames').innerHTML = pf; $('party-frames')._h = pf; }
    $('coords').textContent = g.map.kind === 'world' ? `${Math.floor(s.x / 32)}, ${Math.floor(s.y / 32)}` : g.map.name;
    $('btn-interact').classList.toggle('hidden', !g.nearInteract || !document.body.classList.contains('touch'));
  };
  UI.potCount = k => { let n = 0; for (const it of G().inv || []) if (it && GD.ITEMS[it.i].type === 'potion' && GD.ITEMS[it.i][k]) n += it.q; return n; };
  UI.portrait = function () {
    const c = $('portrait').getContext('2d'), g = G(); c.clearRect(0, 0, 64, 64);
    R.drawChar(c, 32, 76, { app: g.me.app, cls: g.me.cls, scale: 1.7, t: 0, noHat: true });
  };

  // ---------------- chat & messages ----------------
  UI.chat = function (html, cls) {
    const log = $('chat-log'), d = document.createElement('div'); if (cls) d.className = cls; d.innerHTML = html; log.appendChild(d);
    while (log.children.length > 80) log.removeChild(log.firstChild);
    log.scrollTop = log.scrollHeight;
  };
  UI.sys = (m, col) => UI.chat(`<span style="color:${col || '#c9cfe6'}">${esc(m)}</span>`);
  UI.chatMsg = m => {
    const tag = { say: '', g: '[World] ', p: '[Party] ', G: '[Guild] ', w: '[Whisper] ' }[m.ch] || '';
    UI.chat(`${tag}<b>${esc(m.f)}:</b> ${esc(m.m)}`, 'ch-' + m.ch);
    if (m.ch === 'say' && m.id) { const e = G().ents.get(m.id) || (m.id === G().me.id ? G().self : null); if (e) { e.bubble = m.m.slice(0, 60); e.bubbleT = performance.now() + 4000; } }
  };
  UI.openChat = function () { $('chat-input-row').classList.remove('hidden'); $('chat').classList.add('open'); $('chat-input').focus(); };
  UI.sendChat = function () {
    const inp = $('chat-input'); let v = inp.value.trim(); inp.value = '';
    if (!v) { inp.blur(); $('chat-input-row').classList.add('hidden'); return; }
    let ch = $('chat-ch').value, to;
    const m = v.match(/^\/(\w+)\s*(.*)$/);
    if (m) {
      const c = m[1].toLowerCase(), rest = m[2];
      if (c === 'w' || c === 'whisper') { const s = rest.indexOf(' '); if (s < 0) return; to = rest.slice(0, s); v = rest.slice(s + 1); ch = 'w'; }
      else if (c === 'g' || c === 'world') { ch = 'g'; v = rest; } else if (c === 'p') { ch = 'p'; v = rest; } else if (c === 'gu') { ch = 'G'; v = rest; }
      else if (c === 'invite') return send({ t: 'pi', name: rest }); else if (c === 'trade') return send({ t: 'tr', name: rest });
      else if (c === 'friend') return send({ t: 'fa', name: rest }); else if (c === 'ginvite') return send({ t: 'gi', name: rest });
      else return UI.sys('Commands: /w name msg, /g, /p, /gu, /invite name, /trade name, /friend name, /ginvite name');
    }
    send({ t: 'c', ch, m: v, to });
  };
  UI.center = function (txt, ms) { const el = $('center-msg'); el.textContent = txt; el.style.opacity = 1; clearTimeout(UI._ct); UI._ct = setTimeout(() => el.style.opacity = 0, ms || 2500); };
  UI.zoneBanner = function (z) { const el = $('zone-banner'); el.innerHTML = `${esc(z.name)}<small>${z.safe ? 'Safe Zone' : z.pvp ? 'PvP Zone (flagged players only)' : `Lv ${z.lvl[0]}–${z.lvl[1]}`}</small>`; el.style.opacity = 1; clearTimeout(UI._zt); UI._zt = setTimeout(() => el.style.opacity = 0, 3000); $('zone-name').textContent = z.name; };
  UI.invite = function (text, yes, no) {
    const d = document.createElement('div'); d.className = 'invite'; d.innerHTML = `<span>${esc(text)}</span>`;
    const a = document.createElement('button'); a.className = 'btn sm gold'; a.textContent = 'Accept'; a.onclick = () => { yes(); d.remove(); };
    const b = document.createElement('button'); b.className = 'btn sm'; b.textContent = 'Decline'; b.onclick = () => { no && no(); d.remove(); };
    d.append(a, b); $('invites').appendChild(d); setTimeout(() => d.remove(), 30000);
  };
  UI.tip = function (e, html) {
    const t = $('tooltip'); if (!html) { t.classList.add('hidden'); return; }
    t.innerHTML = html; t.classList.remove('hidden');
    const x = Math.min(innerWidth - 270, e.clientX + 12), y = Math.min(innerHeight - t.offsetHeight - 8, e.clientY + 12); t.style.left = x + 'px'; t.style.top = y + 'px';
  };

  // ---------------- item helpers ----------------
  UI.itemHtml = function (it, extra) {
    const d = GD.ITEMS[it.i]; if (!d) return '';
    const r = GD.RARITY[it.r || 0], st = GD.itemStats(it), g = G();
    let h = `<div style="color:${r.c};font-weight:800">${esc(GD.itemName(it))}</div><div class="dim">${d.type === 'equip' ? `${r.n} ${d.slot}` : d.type}${d.lvl > 1 ? ` · Lv ${d.lvl}` : ''}${d.cls ? ' · ' + d.cls.map(c => GD.CLASSES[c].name).join('/') : ''}</div>`;
    if (d.type === 'equip') { const bonus = it.b || {}; for (const k in st) h += `<div>${GD.STAT_NAMES[k]} <b class="${bonus[k] ? 'good' : ''}">+${st[k]}</b></div>`; if (d.lvl > g.stats.lv) h += '<div class="bad">Level too low</div>'; if (d.cls && !d.cls.includes(g.me.cls)) h += '<div class="bad">Wrong class</div>'; }
    if (d.heal) h += `<div class="good">Restores ${d.heal} HP</div>`; if (d.mana) h += `<div style="color:#7fb4ff">Restores ${d.mana} MP</div>`;
    if (d.price) h += `<div class="dim">Sell: ${Math.floor(d.price / 4 * (d.type === 'equip' ? 1 + (it.r || 0) * 0.5 + (it.u || 0) * 0.2 : 1))}g</div>`;
    return h + (extra || '');
  };
  function cellHtml(it, i, cls) {
    if (!it) return `<div class="cell ${cls || ''}" data-i="${i}"></div>`;
    const r = GD.RARITY[it.r || 0];
    return `<div class="cell ${cls || ''}" data-i="${i}" style="border-color:${r.c}88;background:radial-gradient(${r.c}22,#0c1022)">${it.u ? `<span class="u">+${it.u}</span>` : ''}${it.q > 1 ? `<span class="q">${it.q}</span>` : ''}</div>`;
  }
  function paintIcons(root, list, attr) {
    root.querySelectorAll(`.cell[${attr}]`).forEach(c => { const it = list(c.getAttribute(attr)); if (it) { const ic = R.itemIcon(it.i), cv = document.createElement('canvas'); cv.width = cv.height = 40; cv.getContext('2d').drawImage(ic, 0, 0); c.prepend(cv); } });
  }

  // ---------------- panels ----------------
  UI.toggle = name => { if (UI.panel === name) UI.close(); else UI.open(name); };
  UI.open = function (name, opts) {
    UI.panel = name; UI.opts = opts || {}; UI.sel = null; $('panel').classList.remove('hidden'); Audio2.sfx('ui');
    if (name === 'guild') send({ t: 'ginfo' }); if (name === 'social') { send({ t: 'fl' }); send({ t: 'lb' }); }
    UI.refresh();
  };
  UI.close = function () { UI.panel = null; $('panel').classList.add('hidden'); UI.tip(); if (G().trade) send({ t: 'tx' }); };
  UI.refresh = function () {
    if (!UI.panel) return; const fn = P[UI.panel]; if (!fn) return;
    const body = $('panel-body'), scroll = body.scrollTop;
    const r = fn(); $('panel-title').textContent = r.title; body.innerHTML = r.html; if (r.after) r.after(body);
    body.scrollTop = scroll;
  };
  UI.refreshIf = (...names) => { if (names.includes(UI.panel)) UI.refresh(); };
  const tabs = (list, cur, key) => `<div class="ptabs">${list.map(([k, l]) => `<button data-tab="${k}" class="${cur === k ? 'active' : ''}">${l}</button>`).join('')}</div>`;
  const bindTabs = (body, key) => body.querySelectorAll('.ptabs button').forEach(b => b.onclick = () => { UI.opts[key] = b.dataset.tab; UI.sel = null; UI.refresh(); });

  const P = {};
  P.inventory = function () {
    const g = G(), inv = g.inv || [], eq = g.eq || {}, tr = g.trade, npc = UI.opts.npc;
    const off = tr ? tr.me.s : [];
    let h = `<div class="eq-grid">${GD.SLOTS.map(s => cellHtml(eq[s], 'e:' + s, UI.sel === 'e:' + s ? 'sel' : '').replace('class="cell', `data-l="${s}" class="cell`)).join('')}</div>`;
    h += `<div class="inv-grid">${inv.map((it, i) => cellHtml(it, i, (UI.sel === String(i) ? 'sel ' : '') + (off.includes(i) ? 'off' : ''))).join('')}</div>`;
    h += `<div class="row" style="justify-content:space-between;align-items:center"><span class="gold">💰 ${g.stats.gold} gold</span><button class="btn sm" id="inv-sort">Sort</button></div>`;
    let info = '<div class="dim">Tap an item to see details.</div>';
    const sel = UI.sel; let it = null, isEq = false;
    if (sel && sel.startsWith('e:')) { it = eq[sel.slice(2)]; isEq = true; } else if (sel !== null) it = inv[+sel];
    if (it) {
      const d = GD.ITEMS[it.i], acts = [];
      if (isEq) acts.push(['ue', 'Unequip']); else {
        if (d.type === 'equip') acts.push(['eq', 'Equip']); if (d.type === 'potion') acts.push(['use', 'Use']);
        if (tr) acts.push(['offer', off.includes(+sel) ? 'Remove from trade' : 'Offer in trade']);
        if (npc && npc.role === 'merchant') acts.push(['sell', 'Sell'], ...(it.q > 1 ? [['sellall', 'Sell all']] : []));
        if (g.stats.gname) acts.push(['gd', 'Guild deposit']);
        acts.push(['drop', 'Drop']);
      }
      if (npc && npc.role === 'blacksmith' && d.type === 'equip') acts.push(['up', 'Upgrade']);
      info = UI.itemHtml(it) + `<div class="acts">${acts.map(([k, l]) => `<button class="btn sm ${k === 'drop' ? 'red' : ''}" data-act="${k}">${l}</button>`).join('')}</div>`;
    }
    h += `<div class="item-info">${info}</div>`;
    return {
      title: tr ? 'Inventory — select items to offer' : npc && npc.role === 'merchant' ? 'Sell items' : 'Inventory', html: h, after: body => {
        paintIcons(body, k => k.startsWith('e:') ? eq[k.slice(2)] : inv[+k], 'data-i');
        body.querySelectorAll('.cell').forEach(c => c.onclick = () => { UI.sel = c.dataset.i; UI.refresh(); });
        body.querySelectorAll('.cell').forEach(c => c.ondblclick = () => { const k = c.dataset.i; if (k.startsWith('e:')) send({ t: 'ue', sl: k.slice(2) }); else if (inv[+k]) send({ t: 'use', s: +k }); });
        $('inv-sort').onclick = () => { UI.sel = null; send({ t: 'sort' }); };
        body.querySelectorAll('[data-act]').forEach(b => b.onclick = () => {
          const a = b.dataset.act, s = +sel;
          if (a === 'ue') send({ t: 'ue', sl: sel.slice(2) }); else if (a === 'eq') send({ t: 'eq', s }); else if (a === 'use') send({ t: 'use', s });
          else if (a === 'drop') { if (confirm('Drop this item?')) send({ t: 'drop', s }); } else if (a === 'sell') send({ t: 'sell', n: npc.id, s, q: 1 }); else if (a === 'sellall') send({ t: 'sell', n: npc.id, s, q: 999 });
          else if (a === 'offer') send({ t: 'to', s }); else if (a === 'gd') send({ t: 'gd', s });
          else if (a === 'up') send(isEq ? { t: 'up', n: npc.id, sl: sel.slice(2) } : { t: 'up', n: npc.id, s });
          if (a !== 'up' && a !== 'sell') UI.sel = null;
        });
      }
    };
  };
  P.character = function () {
    const g = G(), st = g.stats, s = st.st;
    let h = `<div class="li"><div><div class="t">${esc(g.me.name)} — ${GD.CLASSES[g.me.cls].name} Lv ${st.lv}</div><div class="s">${st.gname ? `Guild «${esc(st.gname)}» (${st.grank})` : 'No guild'} · Arena rating ${st.rating} (${st.wins}W/${st.losses}L)</div></div></div>`;
    h += `<h3 style="margin-top:12px;font-size:14px">Stats</h3><div class="stat-grid">${GD.STAT_KEYS.map(k => `<div><span>${GD.STAT_NAMES[k]}</span><b>${s[k]}</b></div>`).join('')}</div>`;
    h += `<h3 style="margin-top:12px;font-size:14px">Stat points: <span class="gold">${st.pts}</span></h3><div class="list">${Object.keys(GD.ALLOC).map(k => `<div class="li"><span>${GD.ALLOC[k]} <b class="gold">${st.al[k]}</b></span><span><button class="btn sm" data-al="${k}" ${st.pts ? '' : 'disabled'}>+1</button> <button class="btn sm" data-al5="${k}" ${st.pts >= 5 ? '' : 'disabled'}>+5</button></span></div>`).join('')}</div>`;
    h += `<div class="li" style="margin-top:10px"><div><div class="t">PvP flag: <span class="${st.pvp ? 'bad' : 'good'}">${st.pvp ? 'ON' : 'OFF'}</span></div><div class="s">Only flagged players inside Crimson Arena zone can fight each other.</div></div><button class="btn sm ${st.pvp ? '' : 'red'}" id="pvp-t">${st.pvp ? 'Disable' : 'Enable'}</button></div>`;
    h += `<h3 style="margin-top:12px;font-size:14px">Feats</h3><div class="list">${Object.keys(GD.FEATS).map(k => { const f = GD.FEATS[k], has = st.feats.includes(k), v = f.counter === 'zones' ? st.zones.length : (st.cnt[f.counter] || 0); return `<div class="li ${has ? 'done' : ''}"><div><div class="t">${has ? '✦ ' : ''}${f.n}</div><div class="s">${f.desc} — ${Object.entries(f.bonus).map(([a, b]) => `${a.replace('Pct', '')} +${b}${a.endsWith('Pct') || a === 'reflect' ? '%' : ''}`).join(', ')}</div></div><span class="${has ? 'good' : 'dim'}">${has ? 'Unlocked' : `${Math.min(v, f.need)}/${f.need}`}</span></div>`; }).join('')}</div>`;
    return { title: 'Character', html: h, after: body => { body.querySelectorAll('[data-al]').forEach(b => b.onclick = () => send({ t: 'al', k: b.dataset.al })); body.querySelectorAll('[data-al5]').forEach(b => b.onclick = () => send({ t: 'al', k: b.dataset.al5, n: 5 })); $('pvp-t').onclick = () => send({ t: 'pvp', on: !st.pvp }); } };
  };
  UI.skillTip = s => { const S = GD.SKILLS[s]; return `<b class="gold">${S.n}</b> <span class="dim">Lv ${S.lvl}</span><br>${S.desc}<br><span class="dim">MP ${S.mp} · CD ${S.cd / 1000}s</span>`; };
  P.skills = function () {
    const g = G(), C = GD.CLASSES[g.me.cls];
    let h = `<div class="dim" style="margin-bottom:8px">${C.desc}</div><div class="list">`;
    C.skills.forEach((s, i) => { const S = GD.SKILLS[s], ok = g.stats.lv >= S.lvl; h += `<div class="li ${ok ? '' : ''}" style="${ok ? '' : 'opacity:.5'}"><div style="font-size:24px">${R.SKILL_ICON[s]}</div><div style="flex:1"><div class="t">[${i + 1}] ${S.n} <span class="dim">Lv ${S.lvl}</span></div><div class="s">${S.desc} · MP ${S.mp} · CD ${S.cd / 1000}s</div></div><span class="${ok ? 'good' : 'bad'}">${ok ? 'Learned' : 'Locked'}</span></div>`; });
    h += `</div><h3 style="margin-top:12px;font-size:14px">Core actions</h3><div class="s dim">Basic attack (LMB / ⚔) · Dodge roll with i-frames (Space / 💨) · Block (Q / RMB / 🛡): Guardians take only 25% damage and reflect 15% while blocking; other classes take 60%.</div>`;
    return { title: 'Skills', html: h };
  };
  P.quests = function () {
    const g = G(), q = g.quests || { a: {}, d: [] };
    const ids = Object.keys(q.a);
    let h = ids.length ? '<div class="list">' : '<div class="dim">No active quests. Visit a Quest Master (yellow "!") in town.</div>';
    for (const id of ids) {
      const Q = GD.QUESTS[id], st = q.a[id];
      h += `<div class="li"><div style="flex:1"><div class="t">[${Q.type}] ${esc(Q.n)}</div><div class="s">${esc(Q.desc)}</div>${Q.obj.map((o, i) => `<div class="s">• ${UI.objText(o, st.p[i])}</div>`).join('')}<div class="s gold">Reward: ${Q.rew.exp} EXP · ${Q.rew.gold}g${(Q.rew.items || []).map(([it, n]) => ` · ${GD.ITEMS[it].n} x${n}`).join('')}</div></div><button class="btn sm" data-ab="${id}">Abandon</button></div>`;
    }
    if (ids.length) h += '</div>';
    h += `<div class="dim" style="margin-top:10px">Completed quests: ${q.d.length} / ${Object.keys(GD.QUESTS).length}</div>`;
    return { title: 'Quest Log', html: h, after: b => b.querySelectorAll('[data-ab]').forEach(x => x.onclick = () => { if (confirm('Abandon quest?')) send({ t: 'qx', q: x.dataset.ab }); }) };
  };
  UI.objDone = (o, p) => o.k === 'collect' ? UI.countItem(o.i) >= o.n : (p || 0) >= (o.n || 1);
  UI.countItem = id => (G().inv || []).reduce((a, it) => a + (it && it.i === id ? it.q : 0), 0);
  UI.objText = function (o, p) {
    const done = UI.objDone(o, p), mark = done ? '<span class="good">✔</span>' : '';
    if (o.k === 'kill') return `Defeat ${GD.MONSTERS[o.m].n}: ${Math.min(p || 0, o.n)}/${o.n} ${mark}`;
    if (o.k === 'collect') return `Collect ${GD.ITEMS[o.i].n}: ${Math.min(UI.countItem(o.i), o.n)}/${o.n} ${mark}`;
    if (o.k === 'explore') return `Discover ${GD.ZONES[GD.ZONE_IDX[o.z]].name} ${mark}`;
    if (o.k === 'escort') return `Escort Pilgrim Mara to the forest heart ${mark}`;
    return '';
  };
  P.map = function () {
    return {
      title: 'World Map', html: `<div class="wm"><canvas id="wm-cv" width="768" height="768"></canvas></div><div class="dim" style="margin-top:6px">D = dungeon entrance · ★ = you · ◆ = party</div>`, after: () => {
        const c = $('wm-cv').getContext('2d'), g = G(), W = 768, sc = W / GD.MAP_W;
        c.imageSmoothingEnabled = false; c.drawImage(window.Game.worldImg, 0, 0, W, W);
        c.textAlign = 'center'; c.font = '800 15px Cinzel,serif';
        GD.ZONES.forEach(z => { if (z.id === 'plains') return; const known = g.stats.zones.includes(z.id); c.fillStyle = '#000a'; c.fillText(z.name, z.x * sc + 1, z.y * sc + 1); c.fillStyle = known ? '#fff' : '#bbb'; c.fillText(z.name, z.x * sc, z.y * sc); c.font = '700 11px Nunito'; c.fillStyle = z.safe ? '#9fe870' : z.pvp ? '#ff8a8a' : '#ffd34d'; c.fillText(z.safe ? 'Safe' : z.pvp ? 'PvP' : `Lv ${z.lvl[0]}-${z.lvl[1]}${z.req > g.stats.lv ? ' 🔒' : ''}`, z.x * sc, z.y * sc + 14); c.font = '800 15px Cinzel,serif'; });
        for (const k in GD.DUNGEONS) { const D = GD.DUNGEONS[k], x = D.entrance[0] * sc, y = D.entrance[1] * sc; c.fillStyle = '#b05aff'; c.strokeStyle = '#fff'; c.lineWidth = 2; c.beginPath(); c.arc(x, y, 8, 0, 6.3); c.fill(); c.stroke(); c.fillStyle = '#fff'; c.font = '800 10px Nunito'; c.fillText('D', x, y + 4); c.font = '800 15px Cinzel,serif'; }
        (g.party && g.party.m || []).forEach(m => { if (m.id !== g.me.id && m.map === 'world') { c.fillStyle = '#7fe07f'; c.fillText('◆', m.x / 32 * sc, m.y / 32 * sc + 5); } });
        if (g.map.kind === 'world') { c.fillStyle = '#ffd34d'; c.font = '800 20px sans-serif'; c.fillText('★', g.self.x / 32 * sc, g.self.y / 32 * sc + 7); }
      }
    };
  };
  P.party = function () {
    const g = G(), pt = g.party && g.party.m && g.party.m.length ? g.party : null, lead = pt && pt.leader === g.me.id;
    let h = pt ? `<div class="list">${pt.m.map(m => `<div class="li"><div style="flex:1"><div class="t">${m.id === pt.leader ? '♛ ' : ''}${esc(m.n)} <span class="dim">Lv ${m.lv} ${GD.CLASSES[m.c].name}</span></div><div class="bar hp" style="margin-top:4px"><i style="width:${m.hp / m.mhp * 100}%"></i><span>${m.hp}/${m.mhp}</span></div></div>${lead && m.id !== g.me.id ? `<button class="btn sm red" data-k="${m.id}">Kick</button>` : ''}</div>`).join('')}</div><div class="row"><button class="btn red" id="p-leave">Leave Party</button></div>` : '<div class="dim">You are not in a party. Invite players by name (max 5). Party members share EXP, quest kills and dungeon instances.</div>';
    h += `<div class="row" style="justify-content:flex-start"><input id="p-name" placeholder="Player name" style="flex:1"><button class="btn gold" id="p-inv">Invite</button></div>`;
    return { title: 'Party', html: h, after: b => { $('p-inv').onclick = () => send({ t: 'pi', name: $('p-name').value }); const l = $('p-leave'); if (l) l.onclick = () => send({ t: 'pl' }); b.querySelectorAll('[data-k]').forEach(x => x.onclick = () => send({ t: 'pk', id: +x.dataset.k })); } };
  };
  P.guild = function () {
    const g = G(), gd = g.guild;
    if (!gd) return { title: 'Guild', html: '<div class="dim">You are not in a guild. Visit <b>Castor, Guild Master</b> in Dawnshield Village to found one (1000 gold), or ask a guild officer to invite you.</div>' };
    const lead = gd.rank === 'leader', off = lead || gd.rank === 'officer';
    let h = `<div class="li"><div><div class="t">«${esc(gd.name)}» — Level ${gd.level}</div><div class="s">Guild EXP ${gd.exp}/${gd.next} · Members ${gd.members.length}/${gd.cap - 0}</div></div></div>`;
    h += `<h3 style="margin-top:10px;font-size:14px">Members</h3><div class="list">${gd.members.map(m => `<div class="li"><span>${m.online ? '🟢' : '⚫'} ${esc(m.name)} <span class="dim">Lv ${m.level} ${GD.CLASSES[m.cls].name} · ${m.rank}</span></span>${lead && m.rank !== 'leader' ? `<span><button class="btn sm" data-pr="${m.id}">${m.rank === 'officer' ? 'Demote' : 'Promote'}</button> <button class="btn sm red" data-gk="${m.id}">Kick</button></span>` : ''}</div>`).join('')}</div>`;
    h += `<h3 style="margin-top:10px;font-size:14px">Storage (${gd.storage.length}/${gd.cap})</h3><div class="inv-grid">${gd.storage.map((it, i) => cellHtml(it, i)).join('')}</div><div class="dim">Tap an item to withdraw. Deposit from your inventory.</div>`;
    if (off) h += `<div class="row" style="justify-content:flex-start"><input id="g-name" placeholder="Invite player" style="flex:1"><button class="btn gold" id="g-inv">Invite</button></div>`;
    h += `<div class="row"><button class="btn red" id="g-leave">Leave Guild</button></div>`;
    return {
      title: 'Guild', html: h, after: b => {
        paintIcons(b, k => gd.storage[+k], 'data-i');
        b.querySelectorAll('.cell').forEach(c => { c.onclick = () => send({ t: 'gw', i: +c.dataset.i }); c.onmouseenter = e => UI.tip(e, UI.itemHtml(gd.storage[+c.dataset.i])); c.onmouseleave = () => UI.tip(); });
        b.querySelectorAll('[data-gk]').forEach(x => x.onclick = () => send({ t: 'gk', cid: +x.dataset.gk })); b.querySelectorAll('[data-pr]').forEach(x => x.onclick = () => send({ t: 'gp', cid: +x.dataset.pr }));
        if ($('g-inv')) $('g-inv').onclick = () => send({ t: 'gi', name: $('g-name').value });
        $('g-leave').onclick = () => { if (confirm('Leave guild?')) send({ t: 'gl' }); };
      }
    };
  };
  P.social = function () {
    const g = G(), tab = UI.opts.tab || 'friends';
    let h = tabs([['friends', 'Friends'], ['lb', 'Leaderboard'], ['pvp', 'Arena Ranking']], tab);
    if (tab === 'friends') {
      h += `<div class="list">${(g.friends || []).map(f => `<div class="li"><span>${f.online ? '🟢' : '⚫'} ${esc(f.name)} <span class="dim">Lv ${f.level} ${GD.CLASSES[f.cls].name}</span></span><span>${f.online ? `<button class="btn sm" data-w="${esc(f.name)}">Whisper</button> <button class="btn sm" data-pi="${esc(f.name)}">Invite</button> ` : ''}<button class="btn sm red" data-fr="${f.id}">✕</button></span></div>`).join('') || '<div class="dim">No friends yet.</div>'}</div>`;
      h += `<div class="row" style="justify-content:flex-start"><input id="f-name" placeholder="Character name" style="flex:1"><button class="btn gold" id="f-add">Add Friend</button></div>`;
      h += `<div class="row" style="justify-content:flex-start"><input id="t-name" placeholder="Trade with (nearby player)" style="flex:1"><button class="btn" id="t-req">Request Trade</button></div>`;
    } else {
      const L = g.lb ? (tab === 'lb' ? g.lb.level : g.lb.pvp) : [];
      h += `<div class="list">${L.map((r, i) => `<div class="li"><span><b class="gold">#${i + 1}</b> ${esc(r.name)} <span class="dim">${GD.CLASSES[r.cls].name}</span></span><span>${tab === 'lb' ? `Lv ${r.level}` : `${r.rating} (${r.wins}W/${r.losses}L)`}</span></div>`).join('') || '<div class="dim">No entries yet.</div>'}</div>`;
    }
    return {
      title: 'Social', html: h, after: b => {
        bindTabs(b, 'tab');
        if ($('f-add')) { $('f-add').onclick = () => send({ t: 'fa', name: $('f-name').value }); $('t-req').onclick = () => send({ t: 'tr', name: $('t-name').value }); }
        b.querySelectorAll('[data-fr]').forEach(x => x.onclick = () => send({ t: 'fr', cid: +x.dataset.fr }));
        b.querySelectorAll('[data-w]').forEach(x => x.onclick = () => { UI.close(); UI.openChat(); $('chat-input').value = `/w ${x.dataset.w} `; });
        b.querySelectorAll('[data-pi]').forEach(x => x.onclick = () => send({ t: 'pi', name: x.dataset.pi }));
      }
    };
  };
  P.settings = function () {
    const s = G().settings;
    const h = `<div class="list">
      <div class="li"><span>Music</span><button class="btn sm" data-s="music">${s.music ? 'ON' : 'OFF'}</button></div>
      <div class="li"><span>Sound effects</span><button class="btn sm" data-s="sfx">${s.sfx ? 'ON' : 'OFF'}</button></div>
      <div class="li"><span>Graphics quality <span class="dim">(Low = better for phones)</span></span><button class="btn sm" data-s="quality">${s.quality.toUpperCase()}</button></div>
      <div class="li"><span>Show monster names</span><button class="btn sm" data-s="names">${s.names ? 'ON' : 'OFF'}</button></div>
      <div class="li"><span>Movement mode (Z)</span><button class="btn sm" data-s="walk">${Input.walk ? 'WALK' : 'RUN'}</button></div>
    </div>
    <h3 style="margin-top:12px;font-size:14px">Controls</h3>
    <div class="s dim">WASD move · Shift walk · LMB attack/interact · RMB or Q block · Space dodge · 1-5 skills · F/R potions · E interact · Tab target · Enter chat · I C K J M P G O panels · Wheel zoom<br>Mobile: left side joystick, right side buttons, tap to target/talk, pinch to zoom.</div>
    <div class="row"><button class="btn" id="s-chars">Character Select</button><button class="btn red" id="s-logout">Logout</button></div>`;
    return {
      title: 'Settings', html: h, after: b => {
        b.querySelectorAll('[data-s]').forEach(x => x.onclick = () => {
          const k = x.dataset.s;
          if (k === 'quality') s.quality = s.quality === 'high' ? 'low' : 'high'; else if (k === 'walk') Input.walk = !Input.walk; else s[k] = !s[k];
          window.Game.applySettings(); UI.refresh();
        });
        $('s-chars').onclick = () => window.Game.exitToSelect(); $('s-logout').onclick = () => window.Game.logout();
      }
    };
  };
  P.trade = function () {
    const g = G(), tr = g.trade; if (!tr) return { title: 'Trade', html: '<div class="dim">No trade.</div>' };
    const mine = tr.me.s.map(i => g.inv[i]).filter(Boolean);
    let h = `<div class="dim">Select items from your inventory (button below) to offer. Both players must confirm. Any change resets confirmation.</div>`;
    h += `<h3 style="margin-top:10px;font-size:14px">Your offer ${tr.me.ok ? '<span class="good">✔ confirmed</span>' : ''}</h3><div class="inv-grid">${mine.map((it, i) => cellHtml(it, 'm' + i)).join('')}</div><div class="row" style="justify-content:flex-start"><span>Gold:</span><input id="tr-g" type="number" min="0" value="${tr.me.g}" style="width:120px"><button class="btn sm" id="tr-gs">Set</button><button class="btn sm" id="tr-inv">Add items…</button></div>`;
    h += `<h3 style="margin-top:10px;font-size:14px">${esc(tr.name)}'s offer ${tr.them.ok ? '<span class="good">✔ confirmed</span>' : ''}</h3><div class="inv-grid">${tr.them.items.map((it, i) => cellHtml(it, 't' + i)).join('')}</div><div class="gold">Gold: ${tr.them.g}</div>`;
    h += `<div class="row"><button class="btn red" id="tr-x">Cancel</button><button class="btn gold" id="tr-ok" ${tr.me.ok ? 'disabled' : ''}>Confirm</button></div>`;
    return {
      title: 'Trade with ' + tr.name, html: h, after: b => {
        paintIcons(b, k => k[0] === 'm' ? mine[+k.slice(1)] : tr.them.items[+k.slice(1)], 'data-i');
        b.querySelectorAll('.cell').forEach(c => { const k = c.dataset.i, it = k[0] === 'm' ? mine[+k.slice(1)] : tr.them.items[+k.slice(1)]; c.onmouseenter = e => it && UI.tip(e, UI.itemHtml(it)); c.onmouseleave = () => UI.tip(); c.onclick = () => { if (k[0] === 'm') send({ t: 'to', s: tr.me.s[+k.slice(1)] }); else if (it) UI.center(GD.itemName(it), 1500); }; });
        $('tr-gs').onclick = () => send({ t: 'tg', g: +$('tr-g').value }); $('tr-ok').onclick = () => send({ t: 'tc' }); $('tr-x').onclick = () => send({ t: 'tx' });
        $('tr-inv').onclick = () => { UI.panel = 'inventory'; UI.refresh(); };
      }
    };
  };

  // ---------------- NPC dialogs ----------------
  P.npc = function () {
    const n = UI.opts.npc, g = G(); if (!n) return { title: '', html: '' };
    const role = n.role; let h = '', after = null;
    const greet = { quest: 'Adventurer! The realm needs a steady shield.', merchant: 'Potions, blades, armor — fair prices!', blacksmith: 'Bring me ore and I will forge or hone your gear.', trainer: 'Every skill is earned. Some are found by doing the impossible.', healer: 'Rest a moment, child.', guild: 'Bands of heroes are stronger than any lone blade.', dungeon: 'Instanced dungeons — your party enters its own copy.', arena: 'Glory awaits in the arena!' }[role];
    h += `<div class="dim" style="margin-bottom:10px">“${greet}”</div>`;
    if (role === 'quest') {
      const q = g.quests || { a: {}, d: [] };
      const list = Object.keys(GD.QUESTS).filter(id => !q.d.includes(id));
      h += `<div class="list">${list.map(id => {
        const Q = GD.QUESTS[id], act = q.a[id], locked = (Q.pre && !q.d.includes(Q.pre)) || Q.lvl > g.stats.lv;
        if (locked && !act) return Q.lvl > g.stats.lv + 6 ? '' : `<div class="li" style="opacity:.45"><div><div class="t">${esc(Q.n)}</div><div class="s">Requires Lv ${Q.lvl}${Q.pre ? ` · after "${GD.QUESTS[Q.pre].n}"` : ''}</div></div></div>`;
        const ready = act && Q.obj.every((o, i) => UI.objDone(o, act.p[i]));
        const esc2 = act && Q.obj.some(o => o.k === 'escort') && !ready;
        return `<div class="li ${ready ? 'done' : ''}"><div style="flex:1"><div class="t">[${Q.type}] ${esc(Q.n)} <span class="dim">Lv ${Q.lvl}</span></div><div class="s">${esc(Q.desc)}</div>${Q.obj.map((o, i) => `<div class="s">• ${UI.objText(o, act ? act.p[i] : 0)}</div>`).join('')}<div class="s gold">${Q.rew.exp} EXP · ${Q.rew.gold}g${(Q.rew.items || []).map(([it, c]) => ` · ${GD.ITEMS[it].n} x${c}`).join('')}</div></div>${!act ? `<button class="btn sm gold" data-qa="${id}">Accept</button>` : ready ? `<button class="btn sm gold" data-qt="${id}">Complete</button>` : esc2 ? `<button class="btn sm" data-qa="${id}">Summon Mara</button>` : '<span class="dim">In progress</span>'}</div>`;
      }).join('')}</div>`;
      after = b => { b.querySelectorAll('[data-qa]').forEach(x => x.onclick = () => send({ t: 'qa', n: n.id, q: x.dataset.qa })); b.querySelectorAll('[data-qt]').forEach(x => x.onclick = () => send({ t: 'qt', n: n.id, q: x.dataset.qt })); };
    } else if (role === 'merchant') {
      const tab = UI.opts.tab || 'buy';
      h += tabs([['buy', 'Buy'], ['sell', 'Sell']], tab);
      if (tab === 'buy') {
        h += `<div class="gold" style="margin-bottom:6px">💰 ${g.stats.gold}g</div><div class="list">${GD.SHOPS[n.shop].map(id => { const d = GD.ITEMS[id]; const usable = !d.cls || d.cls.includes(g.me.cls); return `<div class="li" style="${usable ? '' : 'opacity:.55'}"><div class="cell" data-i="${id}" style="width:40px;flex:none"></div><div style="flex:1"><div class="t">${esc(d.n)}</div><div class="s">${d.type === 'equip' ? `${d.slot} · Lv ${d.lvl} · ${Object.entries(d.stats).map(([k, v]) => `${GD.STAT_NAMES[k]} +${v}`).join(', ')}${d.cls ? ' · ' + d.cls.map(c => GD.CLASSES[c].name).join('/') : ''}` : d.heal ? `+${d.heal} HP` : `+${d.mana} MP`}</div></div><span class="gold">${d.price}g</span><button class="btn sm" data-b="${id}">Buy</button>${d.stack > 1 ? `<button class="btn sm" data-b10="${id}">x10</button>` : ''}</div>`; }).join('')}</div>`;
        after = b => { bindTabs(b, 'tab'); paintIcons(b, k => ({ i: k }), 'data-i'); b.querySelectorAll('[data-b]').forEach(x => x.onclick = () => send({ t: 'buy', n: n.id, id: x.dataset.b, q: 1 })); b.querySelectorAll('[data-b10]').forEach(x => x.onclick = () => send({ t: 'buy', n: n.id, id: x.dataset.b10, q: 10 })); };
      } else { setTimeout(() => UI.open('inventory', { npc: n }), 0); }
    } else if (role === 'blacksmith') {
      const tab = UI.opts.tab || 'craft';
      h += tabs([['craft', 'Craft'], ['upgrade', 'Upgrade']], tab);
      if (tab === 'craft') {
        const rs = GD.RECIPES.map((r, i) => [r, i]).filter(([r]) => { const d = GD.ITEMS[r.out]; return !d.cls || d.cls.includes(g.me.cls); });
        h += `<div class="list">${rs.map(([r, i]) => { const d = GD.ITEMS[r.out], can = g.stats.gold >= r.gold && r.mats.every(([m, c]) => UI.countItem(m) >= c); return `<div class="li"><div class="cell" data-i="${r.out}" style="width:40px;flex:none"></div><div style="flex:1"><div class="t">${esc(d.n)} <span class="dim">${d.lvl > 1 ? 'Lv ' + d.lvl : ''}</span></div><div class="s">${r.mats.map(([m, c]) => `<span class="${UI.countItem(m) >= c ? 'good' : 'bad'}">${GD.ITEMS[m].n} ${UI.countItem(m)}/${c}</span>`).join(' · ')} · <span class="${g.stats.gold >= r.gold ? 'gold' : 'bad'}">${r.gold}g</span></div></div><button class="btn sm ${can ? 'gold' : ''}" data-cr="${i}" ${can ? '' : 'disabled'}>Craft</button></div>`; }).join('')}</div><div class="dim" style="margin-top:6px">Crafted gear rolls a random rarity with bonus stats.</div>`;
        after = b => { bindTabs(b, 'tab'); paintIcons(b, k => ({ i: k }), 'data-i'); b.querySelectorAll('[data-cr]').forEach(x => x.onclick = () => send({ t: 'craft', n: n.id, r: +x.dataset.cr })); };
      } else {
        const eq = g.eq || {};
        h += `<div class="dim">Upgrade costs gold + Iron Ore. Success chance drops at higher levels (max +10). Each + adds 8% to base stats.</div><div class="list" style="margin-top:8px">${GD.SLOTS.filter(s => eq[s]).map(s => { const it = eq[s], c = GD.upgradeCost(it); return `<div class="li"><div style="flex:1"><div class="t" style="color:${GD.RARITY[it.r || 0].c}">${esc(GD.itemName(it))}</div><div class="s">${it.u >= 10 ? 'MAX' : `${c.gold}g · Iron Ore ${UI.countItem('iron_ore')}/${c.ore} · ${Math.round(c.chance * 100)}%`}</div></div>${it.u >= 10 ? '' : `<button class="btn sm gold" data-up="${s}">Upgrade</button>`}</div>`; }).join('')}</div><div class="row"><button class="btn sm" id="up-inv">Upgrade from inventory…</button></div>`;
        after = b => { bindTabs(b, 'tab'); b.querySelectorAll('[data-up]').forEach(x => x.onclick = () => send({ t: 'up', n: n.id, sl: x.dataset.up })); $('up-inv').onclick = () => UI.open('inventory', { npc: n }); };
      }
    } else if (role === 'healer') {
      h += `<button class="btn gold" id="heal-b">Restore HP & MP (free)</button>`; after = () => $('heal-b').onclick = () => send({ t: 'heal', n: n.id });
    } else if (role === 'trainer') {
      h += P.skills().html + `<div class="row"><button class="btn" id="tr-c">Allocate stat points…</button></div>`; after = () => $('tr-c').onclick = () => UI.open('character');
    } else if (role === 'guild') {
      if (g.stats.gname) h += `<div>You belong to «${esc(g.stats.gname)}».</div><div class="row"><button class="btn" id="g-open">Open Guild</button></div>`;
      else h += `<div>Found a guild for <b class="gold">1000 gold</b>.</div><div class="row" style="justify-content:flex-start"><input id="gc-name" placeholder="Guild name" maxlength="20" style="flex:1"><button class="btn gold" id="gc-b">Found Guild</button></div>`;
      after = () => { if ($('gc-b')) $('gc-b').onclick = () => send({ t: 'gc', n: n.id, name: $('gc-name').value }); if ($('g-open')) $('g-open').onclick = () => UI.open('guild'); };
    } else if (role === 'dungeon') {
      h += `<div class="list">${Object.entries(GD.DUNGEONS).map(([k, D]) => `<div class="li"><div style="flex:1"><div class="t">${esc(D.name)} <span class="dim">Lv ${D.lvl}+</span></div><div class="s">Mini boss: ${GD.MONSTERS[D.mini].n} · Final: ${GD.MONSTERS[D.boss].n}</div></div><button class="btn sm ${g.stats.lv >= D.lvl ? 'gold' : ''}" data-dg="${k}" ${g.stats.lv >= D.lvl ? '' : 'disabled'}>Enter</button></div>`).join('')}</div><div class="dim" style="margin-top:6px">${g.party && g.party.m && g.party.m.length ? 'Your whole party shares one instance.' : 'Solo instance. Form a party to share it.'}</div>`;
      after = b => b.querySelectorAll('[data-dg]').forEach(x => x.onclick = () => { send({ t: 'de', n: n.id, k: x.dataset.dg }); UI.close(); });
    } else if (role === 'arena') {
      h += `<div class="list">${[1, 2, 3].map(m => `<div class="li"><div><div class="t">${m}v${m} ${m === 3 ? 'Team Battle' : 'Duel'}</div><div class="s">Instanced match, 3 min. Win +20 rating.</div></div><button class="btn sm gold" data-aq="${m}">${g.arenaQ === m ? 'Queued…' : 'Join Queue'}</button></div>`).join('')}</div><div class="row"><button class="btn" id="aq-x">Leave Queue</button><button class="btn" id="aq-lb">Ranking</button></div><div class="dim">Open-world PvP only happens inside the Crimson Arena zone between players who enabled their PvP flag (Character panel).</div>`;
      after = b => { b.querySelectorAll('[data-aq]').forEach(x => x.onclick = () => send({ t: 'aq', mode: +x.dataset.aq })); $('aq-x').onclick = () => send({ t: 'aqx' }); $('aq-lb').onclick = () => UI.open('social', { tab: 'pvp' }); };
    }
    return { title: `${R.ROLE_ICON[role] || ''} ${n.n}`, html: h, after };
  };
  UI.openNpc = n => UI.open('npc', { npc: n });

  // ---------------- tutorial ----------------
  const TUT = [
    ['Welcome to <b>Aegis Online</b>! Move with <b>WASD</b> (PC) or the <b>left joystick</b> (mobile).', 'move'],
    ['Talk to <b>Orwin, Quest Master</b> (yellow <b>!</b>) north of the plaza. Click / tap him or press <b>E</b> nearby.', 'npc'],
    ['Accept <b>Ripples in the Meadow</b>, then leave the village gates and defeat slimes with <b>left click</b> / ⚔ and skills <b>1-5</b>.', 'kill'],
    ['Great! Press <b>J</b> for quests, <b>I</b> for inventory, <b>C</b> for stats. Use <b>Q</b>/🛡 to block and <b>Space</b>/💨 to dodge. Good luck, hero!', 'done']
  ];
  UI.tutStep = -1;
  UI.tutorial = function (step) {
    if (step === undefined) step = UI.tutStep + 1;
    UI.tutStep = step; const el = $('tutorial');
    if (step >= TUT.length) { el.classList.add('hidden'); send({ t: 'tut' }); return; }
    el.innerHTML = TUT[step][0] + (step === TUT.length - 1 ? '<div class="row" style="justify-content:center"><button class="btn sm gold" id="tut-ok">Got it</button></div>' : '<div class="row" style="justify-content:center"><button class="btn sm ghost" id="tut-skip">Skip tutorial</button></div>');
    el.classList.remove('hidden');
    const ok = $('tut-ok'), sk = $('tut-skip'); if (ok) ok.onclick = () => UI.tutorial(TUT.length); if (sk) sk.onclick = () => UI.tutorial(TUT.length);
  };
  UI.tutEvent = function (ev) { if (UI.tutStep < 0 || UI.tutStep >= TUT.length) return; if (TUT[UI.tutStep][1] === ev) UI.tutorial(); };
})();
