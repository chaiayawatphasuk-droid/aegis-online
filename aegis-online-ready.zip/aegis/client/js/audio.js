// Procedural music + SFX via WebAudio (no audio assets needed)
(function () {
  'use strict';
  const A = window.Audio2 = { ctx: null, master: null, music: null, sfxOn: true, musicOn: true, track: -1, timer: null, step: 0, lastSfx: {} };
  // [root midi, scale intervals, tempo ms, lead wave, pad wave]
  const TRACKS = [
    [60, [0, 2, 4, 7, 9], 300, 'triangle', 'sine'],     // 0 village
    [62, [0, 2, 4, 5, 7, 9, 11], 280, 'triangle', 'sine'], // 1 capital
    [57, [0, 3, 5, 7, 10], 170, 'square', 'sawtooth'],  // 2 arena
    [50, [0, 1, 5, 7, 8], 260, 'sawtooth', 'triangle'], // 3 grove
    [64, [0, 2, 4, 7, 9], 380, 'sine', 'sine'],         // 4 lake
    [55, [0, 2, 3, 7, 9], 330, 'triangle', 'sine'],     // 5 forest
    [48, [0, 1, 3, 7, 8], 360, 'sine', 'triangle'],     // 6 cave
    [53, [0, 2, 5, 7, 10], 310, 'triangle', 'sine'],    // 7 peaks
    [57, [0, 1, 4, 5, 7, 8, 10], 290, 'triangle', 'sine'], // 8 desert
    [45, [0, 1, 3, 6, 7], 240, 'sawtooth', 'triangle'], // 9 ash
    [62, [0, 2, 4, 7, 9], 320, 'triangle', 'sine'],     // 10 plains
    [52, [0, 3, 5, 6, 7, 10], 150, 'sawtooth', 'square'], // 11 boss
    [50, [0, 2, 3, 5, 7, 8], 300, 'triangle', 'sine']   // 12 dungeon
  ];
  const f = m => 440 * Math.pow(2, (m - 69) / 12);
  A.init = function () {
    if (A.ctx) { if (A.ctx.state === 'suspended') A.ctx.resume(); return; }
    try {
      A.ctx = new (window.AudioContext || window.webkitAudioContext)();
      A.master = A.ctx.createGain(); A.master.gain.value = 0.5; A.master.connect(A.ctx.destination);
      A.music = A.ctx.createGain(); A.music.gain.value = A.musicOn ? 0.16 : 0; A.music.connect(A.master);
    } catch (e) { A.ctx = null; }
  };
  function tone(freq, dur, type, vol, dest, t0, slide) {
    const c = A.ctx, t = t0 || c.currentTime, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq * slide), t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(dest || A.master); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(dur, vol, hp) {
    const c = A.ctx, n = c.createBufferSource(), b = c.createBuffer(1, c.sampleRate * dur, c.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
    n.buffer = b; const fl = c.createBiquadFilter(); fl.type = 'highpass'; fl.frequency.value = hp || 800;
    const g = c.createGain(); g.gain.value = vol; n.connect(fl); fl.connect(g); g.connect(A.master); n.start();
  }
  A.sfx = function (k) {
    if (!A.ctx || !A.sfxOn) return;
    const now = performance.now(); if (now - (A.lastSfx[k] || 0) < 60) return; A.lastSfx[k] = now;
    switch (k) {
      case 'swing': noise(0.12, 0.25, 1800); break;
      case 'hit': tone(180, 0.1, 'square', 0.12, null, 0, 0.5); break;
      case 'crit': tone(320, 0.18, 'sawtooth', 0.14, null, 0, 0.4); noise(0.1, 0.2, 1000); break;
      case 'hurt': tone(140, 0.15, 'sawtooth', 0.12, null, 0, 0.6); break;
      case 'block': tone(900, 0.08, 'square', 0.08); tone(1300, 0.12, 'triangle', 0.06); break;
      case 'cast': tone(500, 0.25, 'sine', 0.1, null, 0, 2); break;
      case 'arrow': noise(0.08, 0.15, 3000); break;
      case 'boom': noise(0.4, 0.35, 200); tone(80, 0.4, 'sine', 0.2, null, 0, 0.5); break;
      case 'heal': [0, 4, 7].forEach((s, i) => tone(f(72 + s), 0.3, 'sine', 0.07, null, A.ctx.currentTime + i * 0.06)); break;
      case 'level': [0, 4, 7, 12].forEach((s, i) => tone(f(67 + s), 0.35, 'triangle', 0.1, null, A.ctx.currentTime + i * 0.09)); break;
      case 'pickup': tone(880, 0.08, 'triangle', 0.08); tone(1320, 0.1, 'triangle', 0.06, null, A.ctx.currentTime + 0.05); break;
      case 'ui': tone(660, 0.05, 'triangle', 0.05); break;
      case 'warn': tone(220, 0.3, 'square', 0.06, null, 0, 1.5); break;
      case 'dodge': noise(0.15, 0.15, 2500); break;
    }
  };
  A.play = function (idx) {
    if (!A.ctx || idx === A.track) return;
    A.track = idx; A.step = 0; clearInterval(A.timer);
    const [root, sc, tempo, lead, pad] = TRACKS[idx] || TRACKS[0];
    let seed = idx * 977 + 13; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    const melody = Array.from({ length: 32 }, () => rnd() < 0.62 ? sc[Math.floor(rnd() * sc.length)] + (rnd() < 0.25 ? 12 : 0) : null);
    const chords = [0, sc[Math.min(3, sc.length - 1)], sc[Math.min(2, sc.length - 1)], sc[Math.min(4, sc.length - 1)]];
    A.timer = setInterval(() => {
      if (!A.ctx || !A.musicOn) return;
      const s = A.step++ % 32, t = A.ctx.currentTime;
      if (s % 8 === 0) { const c = chords[(s / 8) | 0]; tone(f(root - 12 + c), tempo * 8 / 1000, pad, 0.05, A.music, t); tone(f(root - 5 + c), tempo * 8 / 1000, pad, 0.03, A.music, t); }
      if (melody[s] != null) tone(f(root + melody[s]), tempo * 1.6 / 1000, lead, 0.06, A.music, t);
      if (idx === 11 || idx === 2) { if (s % 2 === 0) tone(f(root - 24), 0.12, 'square', 0.05, A.music, t); }
    }, tempo);
  };
  A.setMusic = on => { A.musicOn = on; if (A.music) A.music.gain.value = on ? 0.16 : 0; };
})();
