# Aegis Online — เริ่มตรงนี้

โปรเจกต์นี้เป็นเกม MMORPG 2D Top-down แบบเว็บที่มี Server + Multiplayer + SQLite อยู่ในชุดเดียว

## ถ้าคุณใช้มือถือ Android

คุณไม่จำเป็นต้องพิมพ์คำสั่ง Docker ตามภาพที่ Claude ส่งมา หากเป้าหมายคือเอาเกมขึ้นออนไลน์ ให้ใช้ GitHub + Render ตามขั้นตอนด้านล่าง

## วิธีเอาขึ้นเว็บ

1. สร้างบัญชี GitHub และสร้าง Repository ใหม่ เช่น `aegis-online`
2. แตกไฟล์ ZIP นี้ แล้วอัปโหลด **ไฟล์และโฟลเดอร์ข้างในโฟลเดอร์ `aegis/`** เข้า Repository โดยให้ `package.json`, `server/`, `client/`, `shared/`, `render.yaml` อยู่ที่ระดับบนสุดของ Repository
3. เข้า Render แล้วเลือก New → Blueprint
4. เชื่อม GitHub Repository ที่อัปโหลดไว้
5. Render จะอ่าน `render.yaml` และสร้าง Web Service พร้อม Persistent Disk และ `JWT_SECRET` ให้
6. รอ Build/Deploy เสร็จ
7. เปิด URL ที่ Render ให้มา เกมจะเปิดจากเบราว์เซอร์ได้เลย

## สำคัญ

- เกมต้องใช้ Node.js 22.13+ ตาม package.json
- เกมใช้ WebSocket สำหรับ Multiplayer
- SQLite ต้องอยู่บน Persistent Disk เพื่อไม่ให้ข้อมูลผู้เล่นหายเมื่อมีการ Deploy ใหม่
- ไม่ต้องใส่ JWT_SECRET จริงไว้ใน GitHub
- ถ้าแก้โค้ดแล้ว Push เข้า GitHub, Render จะ Deploy เวอร์ชันใหม่ให้อัตโนมัติ

## ทดสอบบนเครื่อง

ต้องมี Node.js 22.13+ แล้วรัน:

```bash
npm start
```

จากนั้นเปิด:

```text
http://localhost:3000
```

## สถานะไฟล์ที่ตรวจสอบ

- Server เริ่มทำงานได้
- HTTP หน้าเกมตอบกลับ 200 OK
- ระบบ Login/Register, Character, Multiplayer และระบบเกมหลักอยู่ในโปรเจกต์แล้ว
- ชุดทดสอบมีบางรายการที่ขึ้นกับค่าการสุ่มของ Combat จึงอาจมีผลไม่คงที่ในการรันทดสอบบางครั้ง แม้ตัว Server จะเริ่มทำงานได้ตามปกติ
