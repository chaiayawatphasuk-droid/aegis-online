/* Aegis Online — shared game data & pure logic (used by server via require, client via <script>) */
(function (root, factory) {
  const d = factory();
  if (typeof module === 'object' && module.exports) module.exports = d;
  else root.GD = d;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const TILE = 32, MAP_W = 256, MAP_H = 256, CHUNK = 16, VIEW = 1000, MAX_LEVEL = 120;
  const T = { GRASS: 0, FLOWER: 1, WATER: 2, TREE: 3, SAND: 4, ROCK: 5, MOUNTAIN: 6, ROAD: 7, TOWN: 8, WALL: 9, CAVE: 10, ASH: 11, LAVA: 12, SNOW: 13, ARENA: 14, GROVE: 15, DEEP: 16, CWALL: 17, ICE: 18, RUIN: 19, OBSID: 20 };
  const SOLID = []; [T.WATER, T.TREE, T.MOUNTAIN, T.WALL, T.LAVA, T.DEEP, T.CWALL].forEach(t => SOLID[t] = 1);
  const TILE_COLORS = ['#5daa4a', '#6cb556', '#3d8fd1', '#2f6b34', '#e2c98a', '#9a958a', '#6d6a66', '#c7a874', '#d8cbb0', '#7a6650', '#4a4250', '#5a4f4b', '#e2551f', '#e8eef2', '#a14a3a', '#3f7a45', '#2a6aa8', '#2b2530', '#bfe2f2', '#b8a98a', '#3a2c3c'];

  // ---------- deterministic noise ----------
  function hash(x, y, s) {
    let h = Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 668265263) ^ Math.imul(s | 0, 1442695041);
    h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16;
    return (h >>> 0) / 4294967296;
  }
  function vnoise(x, y, sc, s) {
    const fx = x / sc, fy = y / sc, x0 = Math.floor(fx), y0 = Math.floor(fy), tx = fx - x0, ty = fy - y0;
    const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
    const a = hash(x0, y0, s), b = hash(x0 + 1, y0, s), c = hash(x0, y0 + 1, s), d = hash(x0 + 1, y0 + 1, s);
    return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
  }

  // ---------- zones ----------
  const ZONES = [
    { id: 'town', name: 'Dawnshield Village', x: 128, y: 128, r: 13, safe: true, lvl: [1, 1], req: 1, music: 0, desc: 'Starting village. Safe zone.' },
    { id: 'capital', name: 'Aegis Capital', x: 218, y: 216, r: 16, safe: true, lvl: [15, 15], req: 1, music: 1, desc: 'The great walled capital. Safe zone.' },
    { id: 'arena', name: 'Crimson Arena', x: 168, y: 150, r: 7, pvp: true, lvl: [5, 99], req: 5, music: 2, desc: 'PvP zone for flagged players + arena queue.' },
    { id: 'grove', name: 'Elder Grove', x: 40, y: 40, r: 20, lvl: [20, 25], req: 18, music: 3, boss: true, desc: 'Lair of the Elderbark Warden.' },
    { id: 'lake', name: 'Mirrorveil Lake', x: 128, y: 48, r: 30, lvl: [8, 14], req: 6, music: 4, desc: 'Misty shores and drowned things.' },
    { id: 'forest', name: 'Whisperbough Forest', x: 58, y: 122, r: 38, lvl: [5, 11], req: 3, music: 5, desc: 'Goblin camps hide among the trees.' },
    { id: 'cave', name: 'Hollowdeep Caverns', x: 214, y: 132, r: 26, lvl: [12, 18], req: 10, music: 6, desc: 'Bones and golems in the dark.' },
    { id: 'peaks', name: 'Ironspine Peaks', x: 206, y: 52, r: 38, lvl: [15, 22], req: 12, music: 7, desc: 'Orc warbands and frost wyverns.' },
    { id: 'desert', name: 'Sunscour Dunes', x: 122, y: 214, r: 40, lvl: [18, 26], req: 15, music: 8, desc: 'Endless sand, wraiths and drakes.' },
    { id: 'ash', name: 'Ashen Wastes', x: 42, y: 212, r: 36, lvl: [28, 40], req: 25, music: 9, desc: 'High-level demon territory.' },
    { id: 'plains', name: 'Meadowlight Plains', x: 150, y: 110, r: 0, lvl: [1, 5], req: 1, music: 10, desc: 'Gentle fields around the village.' }
  ];
  const ZONE_IDX = {}; ZONES.forEach((z, i) => ZONE_IDX[z.id] = i);

  function terrain(z, x, y, d) {
    const id = z.id;
    if (id === 'town' || id === 'capital' || id === 'arena') {
      const gate = Math.abs(x - z.x) <= 1 || Math.abs(y - z.y) <= 1;
      if (d >= z.r - 1.2 && !gate) return T.WALL;
      return id === 'arena' ? T.ARENA : (d < 3 ? T.ROAD : T.TOWN);
    }
    if (id === 'grove') {
      const gate = Math.abs(x - z.x) <= 1 || Math.abs(y - z.y) <= 1;
      if (d > z.r * 0.82 && !gate) return T.TREE;
      return vnoise(x, y, 3, 41) > 0.7 ? T.FLOWER : T.GROVE;
    }
    if (id === 'lake') {
      if (d < z.r * 0.3) return T.DEEP;
      if (d < z.r * 0.55) return T.WATER;
      if (d < z.r * 0.68) return T.SAND;
      return vnoise(x, y, 3, 43) > 0.7 ? T.FLOWER : T.GRASS;
    }
    if (id === 'forest') {
      if (vnoise(x, y, 3, 11) > 0.56) return T.TREE;
      return vnoise(x, y, 3, 12) > 0.75 ? T.FLOWER : T.GRASS;
    }
    if (id === 'peaks') { const n = vnoise(x, y, 5, 19); return n > 0.62 ? T.MOUNTAIN : n > 0.5 ? T.ROCK : T.SNOW; }
    if (id === 'cave') return vnoise(x, y, 3, 23) > 0.6 ? T.CWALL : T.CAVE;
    if (id === 'desert') return vnoise(x, y, 6, 29) > 0.78 ? T.ROCK : T.SAND;
    if (id === 'ash') { const n = vnoise(x, y, 4, 31); return n > 0.68 ? T.LAVA : n > 0.56 ? T.ROCK : T.ASH; }
    if (vnoise(x, y, 4, 13) > 0.84) return T.TREE;
    return vnoise(x, y, 3, 17) > 0.72 ? T.FLOWER : T.GRASS;
  }

  function buildWorld() {
    const tiles = new Uint8Array(MAP_W * MAP_H), zone = new Uint8Array(MAP_W * MAP_H);
    const last = ZONES.length - 1;
    for (let y = 0; y < MAP_H; y++) for (let x = 0; x < MAP_W; x++) {
      const w = (vnoise(x, y, 9, 7) - 0.5) * 8;
      let zi = last, dd = 0;
      for (let i = 0; i < last; i++) {
        const z = ZONES[i]; const raw = Math.hypot(x - z.x, y - z.y);
        const d = raw + (z.safe || z.pvp ? 0 : w);
        if (d < z.r) { zi = i; dd = (z.safe || z.pvp) ? raw : d; break; }
      }
      const i = y * MAP_W + x; zone[i] = zi; tiles[i] = terrain(ZONES[zi], x, y, dd);
    }
    const paint = (cx, cy, rad, t, keepSafe) => {
      for (let yy = cy - rad; yy <= cy + rad; yy++) for (let xx = cx - rad; xx <= cx + rad; xx++) {
        if (xx <= 1 || yy <= 1 || xx >= MAP_W - 2 || yy >= MAP_H - 2) continue;
        const z = ZONES[zone[yy * MAP_W + xx]];
        if (keepSafe && (z.safe || z.pvp)) continue;
        tiles[yy * MAP_W + xx] = t;
      }
    };
    const road = (x0, y0, x1, y1) => {
      const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
      for (let s = 0; s <= n; s++) paint(Math.round(x0 + (x1 - x0) * s / n), Math.round(y0 + (y1 - y0) * s / n), 1, T.ROAD, true);
    };
    for (let i = 1; i < last; i++) road(128, 128, ZONES[i].x, ZONES[i].y);
    road(218, 216, 122, 214); road(218, 216, 214, 132);
    for (const k in DUNGEONS) { const e = DUNGEONS[k].entrance; paint(e[0], e[1], 2, T.ROAD); }
    for (let y = 0; y < MAP_H; y++) for (let x = 0; x < MAP_W; x++)
      if (x < 2 || y < 2 || x >= MAP_W - 2 || y >= MAP_H - 2) tiles[y * MAP_W + x] = T.MOUNTAIN;
    return { w: MAP_W, h: MAP_H, tiles, zone };
  }

  // ---------- dungeons / arena maps ----------
  const DUNGEONS = {
    goblin: { name: 'Goblin Warren', lvl: 6, entrance: [74, 104], floor: T.CAVE, mobs: ['goblin', 'goblin_slinger'], mini: 'goblin_brute', boss: 'goblin_king', mlvl: 9 },
    ruins: { name: 'Sunken Ruins', lvl: 16, entrance: [134, 198], floor: T.RUIN, mobs: ['skeleton', 'wraith'], mini: 'bone_knight', boss: 'sand_revenant', mlvl: 20 },
    frost: { name: 'Frostfang Temple', lvl: 21, entrance: [194, 72], floor: T.ICE, mobs: ['orc', 'wyvern'], mini: 'frost_ogre', boss: 'glacier_wyrm', mlvl: 25 },
    demon: { name: 'Obsidian Citadel', lvl: 30, entrance: [56, 198], floor: T.OBSID, mobs: ['demon', 'hound'], mini: 'pit_lord', boss: 'abyss_regent', mlvl: 35 }
  };
  function buildDungeon(key) {
    const D = DUNGEONS[key], RW = 16, RH = 14, GAP = 4, N = 4;
    const w = N * RW + (N - 1) * GAP + 2, h = RH + 4;
    const tiles = new Uint8Array(w * h).fill(T.WALL), rooms = [];
    for (let r = 0; r < N; r++) {
      const x0 = 1 + r * (RW + GAP), y0 = 2;
      for (let y = y0; y < y0 + RH; y++) for (let x = x0; x < x0 + RW; x++) tiles[y * w + x] = D.floor;
      if (r > 0 && r < N - 1) for (let k = 0; k < 3; k++) { const px = x0 + 3 + Math.floor(hash(r, k, 5) * (RW - 6)), py = y0 + 3 + Math.floor(hash(k, r, 6) * (RH - 6)); tiles[py * w + px] = T.WALL; }
      if (r < N - 1) for (let x = x0 + RW; x < x0 + RW + GAP; x++) for (let y = y0 + RH / 2 - 2; y < y0 + RH / 2 + 1; y++) tiles[y * w + x] = D.floor;
      rooms.push({ x0, y0, w: RW, h: RH, cx: (x0 + RW / 2) * TILE, cy: (y0 + RH / 2) * TILE });
    }
    return { w, h, tiles, rooms, spawn: [(2.5) * TILE, (2 + RH / 2) * TILE] };
  }
  function buildArena() {
    const w = 30, h = 20, tiles = new Uint8Array(w * h).fill(T.ARENA);
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (x === 0 || y === 0 || x === w - 1 || y === h - 1) tiles[y * w + x] = T.WALL;
    [[10, 6], [19, 6], [10, 13], [19, 13], [14, 9], [15, 10]].forEach(([x, y]) => tiles[y * w + x] = T.WALL);
    return { w, h, tiles };
  }

  // ---------- collision ----------
  function solidAt(m, px, py) {
    const tx = Math.floor(px / TILE), ty = Math.floor(py / TILE);
    if (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h) return true;
    return SOLID[m.tiles[ty * m.w + tx]] === 1;
  }
  function hitBox(m, x, y, r) { return solidAt(m, x - r, y - r) || solidAt(m, x + r, y - r) || solidAt(m, x - r, y + r) || solidAt(m, x + r, y + r); }
  function tryMove(m, x, y, nx, ny, r) {
    let rx = x, ry = y;
    if (!hitBox(m, nx, y, r)) rx = nx;
    if (!hitBox(m, rx, ny, r)) ry = ny;
    return [rx, ry];
  }
  function zoneAt(world, px, py) {
    const tx = Math.floor(px / TILE), ty = Math.floor(py / TILE);
    if (tx < 0 || ty < 0 || tx >= MAP_W || ty >= MAP_H) return ZONES.length - 1;
    return world.zone[ty * MAP_W + tx];
  }

  // ---------- stats ----------
  const STAT_KEYS = ['hp', 'mp', 'atk', 'def', 'matk', 'mdef', 'crit', 'spd', 'block', 'dodge', 'cdr', 'reflect'];
  const STAT_NAMES = { hp: 'HP', mp: 'MP', atk: 'ATK', def: 'DEF', matk: 'MAGIC ATK', mdef: 'MAGIC DEF', crit: 'CRIT %', spd: 'SPEED', block: 'BLOCK %', dodge: 'DODGE %', cdr: 'COOLDOWN -%', reflect: 'REFLECT %' };
  const ALLOC = { vit: 'VIT (+12 HP)', str: 'STR (+2 ATK)', int: 'INT (+2 MATK, +5 MP)', dex: 'DEX (+0.3 CRIT, +0.2 DODGE)', end: 'END (+2 DEF, +1 MDEF)' };

  const CLASSES = {
    guardian: {
      name: 'Guardian', color: '#4f8fd8', desc: 'Unbreakable shield-bearer. Huge HP/DEF, blocks, reflects and protects allies.',
      base: { hp: 170, mp: 50, atk: 9, def: 18, matk: 4, mdef: 12, crit: 3, spd: 140, block: 15, dodge: 2, cdr: 0, reflect: 5 },
      grow: { hp: 24, mp: 3, atk: 1.6, def: 3.2, matk: 0.4, mdef: 2, block: 0.15 },
      basic: { kind: 'melee', range: 62, arc: 110, mult: 1, cd: 700, fx: 'slash' }, threat: 2.5,
      skills: ['g_bulwark', 'g_taunt', 'g_aegis', 'g_thorns', 'g_fortress']
    },
    warrior: {
      name: 'Warrior', color: '#d8574f', desc: 'Frontline berserker. High melee damage and cleaves.',
      base: { hp: 125, mp: 40, atk: 16, def: 10, matk: 3, mdef: 6, crit: 6, spd: 150, block: 5, dodge: 4, cdr: 0, reflect: 0 },
      grow: { hp: 18, mp: 2.5, atk: 3, def: 2, matk: 0.3, mdef: 1.2, crit: 0.05 },
      basic: { kind: 'melee', range: 72, arc: 130, mult: 1, cd: 620, fx: 'slash' }, threat: 1.2,
      skills: ['w_cleave', 'w_charge', 'w_warcry', 'w_whirl', 'w_execute']
    },
    mage: {
      name: 'Mage', color: '#9a5fe0', desc: 'Arcane artillery. Long range magic, huge mana, heals.',
      base: { hp: 85, mp: 130, atk: 5, def: 5, matk: 18, mdef: 12, crit: 5, spd: 145, block: 0, dodge: 5, cdr: 0, reflect: 0 },
      grow: { hp: 11, mp: 9, atk: 0.5, def: 1, matk: 3.2, mdef: 2 },
      basic: { kind: 'proj', range: 380, speed: 460, mult: 1, cd: 800, fx: 'arcane', magic: true }, threat: 1,
      skills: ['m_fire', 'm_ice', 'm_bolt', 'm_heal', 'm_meteor']
    },
    ranger: {
      name: 'Ranger', color: '#5cb85c', desc: 'Mobile archer. Long range, multi-shots and traps.',
      base: { hp: 100, mp: 60, atk: 14, def: 7, matk: 4, mdef: 7, crit: 10, spd: 168, block: 0, dodge: 10, cdr: 0, reflect: 0 },
      grow: { hp: 13, mp: 4, atk: 2.6, def: 1.3, matk: 0.4, mdef: 1.3, crit: 0.06, dodge: 0.05 },
      basic: { kind: 'proj', range: 430, speed: 640, mult: 1, cd: 560, fx: 'arrow' }, threat: 1,
      skills: ['r_multi', 'r_poison', 'r_roll', 'r_rain', 'r_snipe']
    },
    assassin: {
      name: 'Assassin', color: '#3d3d55', desc: 'Shadow striker. Very fast, critical-heavy burst.',
      base: { hp: 95, mp: 55, atk: 15, def: 6, matk: 3, mdef: 6, crit: 22, spd: 178, block: 0, dodge: 15, cdr: 0, reflect: 0 },
      grow: { hp: 12, mp: 3, atk: 2.8, def: 1.2, matk: 0.3, mdef: 1.1, crit: 0.1, dodge: 0.06 },
      basic: { kind: 'melee', range: 56, arc: 100, mult: 1, cd: 420, fx: 'slash2' }, threat: 1,
      skills: ['a_backstab', 'a_step', 'a_venom', 'a_fan', 'a_vanish']
    }
  };

  // type: buff | taunt | ally_shield | arc | dash | proj | chain | ground | heal | blink | nova
  const SKILLS = {
    g_bulwark: { n: 'Bulwark Stance', lvl: 1, mp: 12, cd: 14000, type: 'buff', buffs: [['def_up', 8000, 1.7], ['mdef_up', 8000, 1.5]], fx: 'shield', desc: 'DEF x1.7, MDEF x1.5 for 8s.' },
    g_taunt: { n: 'Challenge Roar', lvl: 3, mp: 10, cd: 9000, type: 'taunt', radius: 200, mult: 0.6, dur: 6000, fx: 'roar', desc: 'Force nearby monsters to attack you for 6s.' },
    g_aegis: { n: 'Aegis Link', lvl: 6, mp: 25, cd: 18000, type: 'ally_shield', radius: 240, dur: 10000, fx: 'shield', desc: 'Shield yourself and party nearby (absorb = DEF×4 + 10% max HP).' },
    g_thorns: { n: 'Thorn Mirror', lvl: 10, mp: 20, cd: 20000, type: 'buff', buffs: [['reflect_up', 7000, 40]], fx: 'thorns', desc: '+40% damage reflection for 7s.' },
    g_fortress: { n: 'Unbroken Citadel', lvl: 15, mp: 40, cd: 45000, type: 'taunt', radius: 260, mult: 1.2, dur: 5000, buffs: [['fortress', 5000, 0.15]], fx: 'fortress', desc: 'Take only 15% damage for 5s and taunt everything around.' },

    w_cleave: { n: 'Rending Cleave', lvl: 1, mp: 8, cd: 4000, type: 'arc', range: 95, arc: 160, mult: 1.7, fx: 'bigslash', desc: 'Wide 1.7x cleave.' },
    w_charge: { n: 'Iron Charge', lvl: 3, mp: 10, cd: 8000, type: 'dash', dist: 220, radius: 60, mult: 1.5, status: ['stun', 800], fx: 'dash', desc: 'Dash forward and stun.' },
    w_warcry: { n: 'War Cry', lvl: 6, mp: 15, cd: 20000, type: 'buff', buffs: [['atk_up', 9000, 1.4]], fx: 'buff', desc: 'ATK x1.4 for 9s.' },
    w_whirl: { n: 'Steel Cyclone', lvl: 10, mp: 22, cd: 10000, type: 'nova', radius: 115, mult: 2.2, fx: 'whirl', desc: '2.2x spin around you.' },
    w_execute: { n: 'Headsman\'s Verdict', lvl: 15, mp: 25, cd: 14000, type: 'arc', range: 85, arc: 70, mult: 3.6, execute: 0.3, fx: 'bigslash', desc: '3.6x, double vs targets under 30% HP.' },

    m_fire: { n: 'Flare Orb', lvl: 1, mp: 14, cd: 3500, type: 'proj', speed: 420, range: 400, mult: 1.9, magic: true, explode: 70, status: ['burn', 3000], fx: 'fire', desc: 'Exploding fireball with burn.' },
    m_ice: { n: 'Frost Lance', lvl: 3, mp: 12, cd: 5000, type: 'proj', speed: 520, range: 420, mult: 1.4, magic: true, status: ['slow', 3000], pierce: true, fx: 'ice', desc: 'Piercing lance that slows.' },
    m_bolt: { n: 'Chain Lightning', lvl: 6, mp: 20, cd: 7000, type: 'chain', range: 360, jumps: 4, mult: 1.8, magic: true, fx: 'lightning', desc: 'Lightning that jumps to 4 targets.' },
    m_heal: { n: 'Dawnlight Mend', lvl: 10, mp: 30, cd: 12000, type: 'heal', radius: 240, mult: 3.2, fx: 'heal', desc: 'Heal self and party nearby.' },
    m_meteor: { n: 'Starfall', lvl: 15, mp: 45, cd: 18000, type: 'ground', range: 420, radius: 120, delay: 900, mult: 4, magic: true, status: ['burn', 4000], fx: 'explosion', desc: 'Massive delayed meteor.' },

    r_multi: { n: 'Fan Volley', lvl: 1, mp: 8, cd: 4000, type: 'proj', count: 5, spread: 0.5, speed: 620, range: 380, mult: 0.9, fx: 'arrow', desc: '5 arrows in a fan.' },
    r_poison: { n: 'Viper Arrow', lvl: 3, mp: 10, cd: 6000, type: 'proj', speed: 640, range: 440, mult: 1.3, status: ['poison', 6000], fx: 'poison', desc: 'Poisons the target.' },
    r_roll: { n: 'Wind Step', lvl: 6, mp: 6, cd: 5000, type: 'blink', dist: 200, back: true, buffs: [['haste', 3000, 1.4]], fx: 'wind', desc: 'Leap backwards and gain speed.' },
    r_rain: { n: 'Arrow Storm', lvl: 10, mp: 25, cd: 12000, type: 'ground', range: 420, radius: 110, delay: 500, mult: 2.6, status: ['slow', 2000], fx: 'rain', desc: 'Arrows rain on an area.' },
    r_snipe: { n: 'Skypiercer', lvl: 15, mp: 30, cd: 14000, type: 'proj', speed: 1100, range: 700, mult: 4.2, pierce: true, fx: 'snipe', desc: 'Very long range piercing shot.' },

    a_backstab: { n: 'Shadow Fang', lvl: 1, mp: 8, cd: 3500, type: 'arc', range: 64, arc: 80, mult: 2.4, critBonus: 30, fx: 'slash2', desc: '2.4x strike, +30% crit chance.' },
    a_step: { n: 'Umbral Step', lvl: 3, mp: 10, cd: 7000, type: 'blink', dist: 260, toTarget: true, mult: 1.6, fx: 'shadow', desc: 'Teleport behind your target and strike.' },
    a_venom: { n: 'Venom Edge', lvl: 6, mp: 15, cd: 18000, type: 'buff', buffs: [['venom', 10000, 1], ['atk_up', 10000, 1.2]], fx: 'poison', desc: 'Attacks poison for 10s, ATK x1.2.' },
    a_fan: { n: 'Dagger Bloom', lvl: 10, mp: 20, cd: 9000, type: 'nova', radius: 130, mult: 1.9, status: ['poison', 4000], fx: 'fan', desc: 'Throw daggers all around.' },
    a_vanish: { n: 'Nightveil', lvl: 15, mp: 25, cd: 25000, type: 'buff', buffs: [['vanish', 3000, 1], ['haste', 3000, 1.5]], fx: 'shadow', desc: 'Evade every attack for 3s and gain speed.' }
  };

  // Feats: hidden achievements that grant permanent passive bonuses
  const FEATS = {
    stoneheart: { n: 'Stoneheart', desc: 'Block 100 attacks', counter: 'blocks', need: 100, bonus: { defPct: 15 } },
    thornhide: { n: 'Thornhide', desc: 'Reflect 3000 total damage', counter: 'reflected', need: 3000, bonus: { reflect: 10 } },
    titan: { n: "Titan's Patience", desc: 'Absorb 30000 total damage', counter: 'taken', need: 30000, bonus: { hpPct: 20 } },
    hunter: { n: 'Hunter of Hundreds', desc: 'Defeat 300 monsters', counter: 'kills', need: 300, bonus: { crit: 5 } },
    wanderer: { n: 'Far Wanderer', desc: 'Discover every region', counter: 'zones', need: 11, bonus: { spdPct: 8 } },
    unyielding: { n: 'Unyielding', desc: 'Survive 50 hits as a boss target', counter: 'bossHits', need: 50, bonus: { defPct: 10, hpPct: 10 } }
  };

  // ---------- items ----------
  const RARITY = [
    { n: 'Common', c: '#cfd3d6', m: 1, w: 600 }, { n: 'Uncommon', c: '#5fd16a', m: 1.15, w: 250 }, { n: 'Rare', c: '#4aa3ff', m: 1.3, w: 100 },
    { n: 'Epic', c: '#b065ff', m: 1.5, w: 40 }, { n: 'Legendary', c: '#ffa531', m: 1.8, w: 9 }, { n: 'Mythic', c: '#ff4d6d', m: 2.2, w: 1 }
  ];
  const SLOTS = ['weapon', 'offhand', 'helm', 'armor', 'boots', 'acc'];
  const ITEMS = {};
  const add = (id, o) => { o.id = id; o.stack = o.stack || 1; ITEMS[id] = o; };
  add('hp_s', { n: 'Minor Healing Draught', type: 'potion', heal: 90, lvl: 1, price: 20, stack: 99 });
  add('hp_m', { n: 'Healing Draught', type: 'potion', heal: 300, lvl: 8, price: 70, stack: 99 });
  add('hp_l', { n: 'Greater Healing Draught', type: 'potion', heal: 800, lvl: 18, price: 180, stack: 99 });
  add('mp_s', { n: 'Minor Mana Tonic', type: 'potion', mana: 60, lvl: 1, price: 25, stack: 99 });
  add('mp_m', { n: 'Mana Tonic', type: 'potion', mana: 200, lvl: 10, price: 80, stack: 99 });
  add('elixir', { n: 'Dawn Elixir', type: 'potion', heal: 1600, mana: 500, lvl: 25, price: 500, stack: 99 });
  [['slime_gel', 'Slime Gel', 4], ['wolf_pelt', 'Wolf Pelt', 8], ['goblin_ear', 'Goblin Charm', 10], ['bone_shard', 'Bone Shard', 14], ['golem_core', 'Golem Core', 30],
  ['orc_tusk', 'Orc Tusk', 22], ['drake_scale', 'Drake Scale', 45], ['demon_horn', 'Demon Horn', 70], ['herb', 'Glowcap Herb', 6], ['iron_ore', 'Iron Ore', 10],
  ['mana_crystal', 'Mana Crystal', 25], ['sun_fiber', 'Sun Fiber', 20], ['ember_core', 'Ember Core', 50], ['warden_heart', 'Warden Heartwood', 400], ['abyss_shard', 'Abyss Shard', 900]]
    .forEach(([id, n, p]) => add(id, { n, type: 'material', price: p, stack: 999, lvl: 1 }));

  const TIERS = [{ k: 'novice', n: 'Novice', l: 1 }, { k: 'iron', n: 'Iron', l: 8 }, { k: 'knight', n: 'Knight', l: 16 }, { k: 'royal', n: 'Royal', l: 26 }, { k: 'celestial', n: 'Celestial', l: 36 }];
  const WPN = { guardian: 'Warden Mace', warrior: 'Greatsword', mage: 'Staff', ranger: 'Longbow', assassin: 'Twin Fangs' };
  const R = o => { for (const k in o) o[k] = Math.round(o[k]); return o; };
  TIERS.forEach((t, ti) => {
    const l = t.l, price = Math.round(25 * Math.pow(l, 1.45) + 30);
    const ws = {
      guardian: { atk: 5 + l * 1.9, def: 2 + l * 0.6 }, warrior: { atk: 8 + l * 2.8 }, mage: { matk: 7 + l * 2.6, mp: 10 + l * 3 },
      ranger: { atk: 6 + l * 2.4, dodge: 1 + ti }, assassin: { atk: 5 + l * 2.3, crit: 2 + ti * 2 }
    };
    for (const c in WPN) add(`${t.k}_${c}_wpn`, { n: `${t.n} ${WPN[c]}`, type: 'equip', slot: 'weapon', cls: [c], lvl: l, stats: R(ws[c]), price, tier: ti });
    add(`${t.k}_heavy`, { n: `${t.n} Plate`, type: 'equip', slot: 'armor', cls: ['guardian', 'warrior'], lvl: l, stats: R({ def: 6 + l * 2.2, hp: 10 + l * 4, mdef: 2 + l * 0.8 }), price, tier: ti });
    add(`${t.k}_light`, { n: `${t.n} Leathers`, type: 'equip', slot: 'armor', cls: ['ranger', 'assassin'], lvl: l, stats: R({ def: 3 + l * 1.3, hp: 6 + l * 3, mdef: 2 + l, dodge: 1 + ti }), price, tier: ti });
    add(`${t.k}_robe`, { n: `${t.n} Robe`, type: 'equip', slot: 'armor', cls: ['mage'], lvl: l, stats: R({ def: 2 + l * 0.8, mdef: 5 + l * 2, mp: 10 + l * 4 }), price, tier: ti });
    add(`${t.k}_helm`, { n: `${t.n} Helm`, type: 'equip', slot: 'helm', lvl: l, stats: R({ def: 2 + l * 0.8, hp: 5 + l * 2 }), price: Math.round(price * 0.6), tier: ti });
    add(`${t.k}_boots`, { n: `${t.n} Boots`, type: 'equip', slot: 'boots', lvl: l, stats: R({ def: 1 + l * 0.5, spd: 4 + ti * 3 }), price: Math.round(price * 0.6), tier: ti });
    add(`${t.k}_ring`, { n: `${t.n} Ring`, type: 'equip', slot: 'acc', lvl: l, stats: R({ crit: 1 + ti, hp: 5 + l * 2 }), price: Math.round(price * 0.7), tier: ti });
    add(`${t.k}_amulet`, { n: `${t.n} Amulet`, type: 'equip', slot: 'acc', lvl: l, stats: R({ mdef: 2 + l, mp: 5 + l * 2 }), price: Math.round(price * 0.7), tier: ti });
  });
  add('buckler', { n: 'Oak Buckler', type: 'equip', slot: 'offhand', cls: ['guardian'], lvl: 1, stats: { def: 8, block: 2 }, price: 40 });
  add('iron_shield', { n: 'Iron Shield', type: 'equip', slot: 'offhand', cls: ['guardian'], lvl: 8, stats: { def: 20 }, price: 300 });
  add('knight_shield', { n: 'Knight Shield', type: 'equip', slot: 'offhand', cls: ['guardian'], lvl: 16, stats: { def: 50, block: 5 }, price: 1200 });
  add('guardian_shield', { n: 'Guardian Shield', type: 'equip', slot: 'offhand', cls: ['guardian'], lvl: 26, stats: { def: 100, block: 15, cdr: 5 }, price: 5000 });
  add('dawn_bastion', { n: 'Bastion of First Dawn', type: 'equip', slot: 'offhand', cls: ['guardian'], lvl: 36, stats: { def: 160, block: 20, reflect: 10, cdr: 8 }, price: 15000 });
  add('heartwood_mantle', { n: 'Heartwood Mantle', type: 'equip', slot: 'acc', lvl: 22, stats: { hp: 320, def: 30, reflect: 5 }, price: 4000 });
  add('regent_crown', { n: 'Crown of the Abyss Regent', type: 'equip', slot: 'helm', lvl: 34, stats: { hp: 500, def: 70, mdef: 70, crit: 6 }, price: 12000 });

  const BONUS_POOL = ['hp', 'atk', 'def', 'matk', 'mdef', 'crit', 'block', 'dodge', 'spd', 'cdr'];
  function bonusVal(k, l) { return ({ hp: 5 + l * 2.5, atk: 1 + l * 0.45, def: 1 + l * 0.45, matk: 1 + l * 0.45, mdef: 1 + l * 0.45, crit: 1 + l * 0.06, block: 1 + l * 0.05, dodge: 1 + l * 0.05, spd: 3 + l * 0.15, cdr: 1 + l * 0.04 })[k]; }
  function rollRarity(rng, boost) {
    let tot = 0; RARITY.forEach((r, i) => tot += r.w * (i ? (1 + (boost || 0)) : 1));
    let v = rng() * tot;
    for (let i = 0; i < RARITY.length; i++) { v -= RARITY[i].w * (i ? (1 + (boost || 0)) : 1); if (v <= 0) return i; }
    return 0;
  }
  function makeItem(id, qty, rng, boost) {
    const d = ITEMS[id]; if (!d) return null;
    const inst = { i: id, q: qty || 1 };
    if (d.type === 'equip') {
      rng = rng || Math.random; inst.q = 1; inst.u = 0;
      inst.r = boost === -1 ? 0 : rollRarity(rng, boost); inst.b = {};
      for (let k = 0; k < inst.r; k++) {
        const s = BONUS_POOL[Math.floor(rng() * BONUS_POOL.length)];
        inst.b[s] = (inst.b[s] || 0) + Math.max(1, Math.round(bonusVal(s, d.lvl) * (0.5 + rng() * 0.5) * (1 + inst.r * 0.15)));
      }
    }
    return inst;
  }
  function itemStats(inst) {
    const d = ITEMS[inst.i], out = {}; if (!d || !d.stats) return out;
    const m = RARITY[inst.r || 0].m * (1 + 0.08 * (inst.u || 0));
    for (const k in d.stats) out[k] = Math.round(d.stats[k] * m);
    for (const k in (inst.b || {})) out[k] = (out[k] || 0) + inst.b[k];
    return out;
  }
  function itemName(inst) { const d = ITEMS[inst.i]; return d ? (d.n + (inst.u ? ` +${inst.u}` : '')) : '?'; }

  function computeStats(cls, level, alloc, equip, feats) {
    const c = CLASSES[cls], s = {};
    for (const k of STAT_KEYS) s[k] = c.base[k] + (c.grow[k] || 0) * (level - 1);
    alloc = alloc || {};
    s.hp += (alloc.vit || 0) * 12; s.atk += (alloc.str || 0) * 2; s.matk += (alloc.int || 0) * 2; s.mp += (alloc.int || 0) * 5;
    s.crit += (alloc.dex || 0) * 0.3; s.dodge += (alloc.dex || 0) * 0.2; s.def += (alloc.end || 0) * 2; s.mdef += (alloc.end || 0);
    for (const sl in (equip || {})) { if (!equip[sl]) continue; const st = itemStats(equip[sl]); for (const k in st) s[k] += st[k]; }
    let defPct = 0, hpPct = 0, spdPct = 0;
    for (const f of (feats || [])) { const b = FEATS[f] && FEATS[f].bonus; if (!b) continue; defPct += b.defPct || 0; hpPct += b.hpPct || 0; spdPct += b.spdPct || 0; s.reflect += b.reflect || 0; s.crit += b.crit || 0; }
    s.def *= 1 + defPct / 100; s.hp *= 1 + hpPct / 100; s.spd *= 1 + spdPct / 100;
    s.crit = Math.min(75, s.crit); s.block = Math.min(75, s.block); s.dodge = Math.min(50, s.dodge); s.cdr = Math.min(40, s.cdr); s.reflect = Math.min(60, s.reflect); s.spd = Math.min(260, s.spd);
    for (const k of STAT_KEYS) s[k] = Math.round(s[k] * 10) / 10;
    s.hp = Math.round(s.hp); s.mp = Math.round(s.mp);
    return s;
  }
  const expToNext = l => Math.floor(50 * Math.pow(l, 1.6));

  // ---------- monsters ----------
  // shape: slime wolf goblin skeleton orc golem dragon demon undead beast tree
  const MONSTERS = {
    slime: { n: 'Dewdrop Slime', lvl: 1, shape: 'slime', col: '#6fd36f', size: 14, drops: [['slime_gel', 0.5], ['hp_s', 0.08]] },
    slime_gold: { n: 'Gilded Slime', lvl: 6, shape: 'slime', col: '#ffd34d', size: 16, m: { exp: 6, gold: 5 }, drops: [['slime_gel', 1], ['mana_crystal', 0.3]], event: true },
    wolf: { n: 'Meadow Wolf', lvl: 3, shape: 'wolf', col: '#9a8f80', size: 15, flee: true, m: { spd: 1.2 }, drops: [['wolf_pelt', 0.45]] },
    goblin: { n: 'Thicket Goblin', lvl: 6, shape: 'goblin', col: '#7bb04c', size: 13, drops: [['goblin_ear', 0.5], ['hp_s', 0.1]] },
    goblin_slinger: { n: 'Goblin Slinger', lvl: 7, shape: 'goblin', col: '#a3c25a', size: 13, ranged: true, drops: [['goblin_ear', 0.5]] },
    boar: { n: 'Mossback Boar', lvl: 9, shape: 'beast', col: '#6b5a3a', size: 18, m: { hp: 1.3 }, drops: [['wolf_pelt', 0.5], ['herb', 0.2]] },
    mire_slime: { n: 'Mire Slime', lvl: 10, shape: 'slime', col: '#4aa3d8', size: 15, ranged: true, drops: [['slime_gel', 0.6], ['mana_crystal', 0.15]] },
    lurker: { n: 'Drowned Lurker', lvl: 12, shape: 'undead', col: '#5d7f8a', size: 15, magic: true, drops: [['mana_crystal', 0.2], ['bone_shard', 0.3]] },
    skeleton: { n: 'Hollow Skeleton', lvl: 13, shape: 'skeleton', col: '#e6e0cc', size: 14, drops: [['bone_shard', 0.5]] },
    golem: { n: 'Cavern Golem', lvl: 16, shape: 'golem', col: '#8b8b9a', size: 22, m: { hp: 1.8, spd: 0.6, def: 1.5 }, drops: [['golem_core', 0.3], ['iron_ore', 0.5]] },
    orc: { n: 'Ironspine Orc', lvl: 17, shape: 'orc', col: '#6f8f4f', size: 18, m: { atk: 1.2 }, drops: [['orc_tusk', 0.45], ['iron_ore', 0.3]] },
    wyvern: { n: 'Frost Wyvern', lvl: 20, shape: 'dragon', col: '#9fd0ee', size: 20, ranged: true, magic: true, drops: [['drake_scale', 0.25]] },
    wraith: { n: 'Dune Wraith', lvl: 21, shape: 'undead', col: '#d8c48a', size: 15, magic: true, flee: true, drops: [['sun_fiber', 0.35], ['bone_shard', 0.3]] },
    drake: { n: 'Sun Drake', lvl: 24, shape: 'dragon', col: '#e0903a', size: 22, ranged: true, drops: [['drake_scale', 0.35], ['sun_fiber', 0.3]] },
    demon: { n: 'Ash Demon', lvl: 30, shape: 'demon', col: '#c0392b', size: 19, ranged: true, magic: true, drops: [['demon_horn', 0.3], ['ember_core', 0.2]] },
    hound: { n: 'Cinder Hound', lvl: 32, shape: 'wolf', col: '#e2582b', size: 17, flee: true, m: { spd: 1.3 }, drops: [['demon_horn', 0.15], ['ember_core', 0.25]] },
    // dungeon / bosses
    goblin_brute: { n: 'Goblin Brute', lvl: 9, shape: 'orc', col: '#5f8a3a', size: 24, mini: true, drops: [['iron_shield', 0.5], ['goblin_ear', 1]] },
    goblin_king: { n: 'Grubtooth the Goblin King', lvl: 11, shape: 'goblin', col: '#c9a227', size: 30, boss: 'king', drops: [['iron_ore', 1], ['knight_shield', 0.15], ['hp_m', 1]] },
    bone_knight: { n: 'Bone Knight', lvl: 19, shape: 'skeleton', col: '#cfc6a8', size: 24, mini: true, drops: [['bone_shard', 1]] },
    sand_revenant: { n: 'Sandcrowned Revenant', lvl: 21, shape: 'undead', col: '#e9c46a', size: 32, boss: 'revenant', magic: true, drops: [['sun_fiber', 1], ['heartwood_mantle', 0.1]] },
    frost_ogre: { n: 'Frost Ogre', lvl: 24, shape: 'orc', col: '#9cc9e8', size: 26, mini: true, drops: [['drake_scale', 1]] },
    glacier_wyrm: { n: 'Glacier Wyrm', lvl: 26, shape: 'dragon', col: '#bfe9ff', size: 36, boss: 'wyrm', magic: true, drops: [['guardian_shield', 0.15], ['drake_scale', 1]] },
    pit_lord: { n: 'Pit Lord', lvl: 34, shape: 'demon', col: '#8e1b1b', size: 28, mini: true, drops: [['demon_horn', 1]] },
    abyss_regent: { n: 'Abyss Regent', lvl: 36, shape: 'demon', col: '#5b1f7a', size: 38, boss: 'regent', magic: true, drops: [['abyss_shard', 1], ['regent_crown', 0.2]] },
    elderbark: { n: 'Elderbark Warden', lvl: 24, shape: 'tree', col: '#4a7a3a', size: 40, boss: 'warden', drops: [['warden_heart', 1], ['heartwood_mantle', 0.25], ['guardian_shield', 0.08]], summon: 'boar' }
  };
  const BOSS_PHASES = {
    warden: [{ at: 1, p: ['slam', 'targets'] }, { at: 0.66, p: ['slam', 'summon', 'targets'] }, { at: 0.33, p: ['ring', 'targets', 'slam', 'charge'], enrage: 1.3 }],
    king: [{ at: 1, p: ['slam'] }, { at: 0.6, p: ['slam', 'summon'] }, { at: 0.3, p: ['charge', 'slam', 'targets'], enrage: 1.2 }],
    revenant: [{ at: 1, p: ['targets'] }, { at: 0.66, p: ['targets', 'summon'] }, { at: 0.33, p: ['ring', 'targets', 'slam'], enrage: 1.3 }],
    wyrm: [{ at: 1, p: ['slam', 'ring'] }, { at: 0.6, p: ['targets', 'ring'] }, { at: 0.3, p: ['charge', 'ring', 'targets'], enrage: 1.3 }],
    regent: [{ at: 1, p: ['targets', 'slam'] }, { at: 0.66, p: ['summon', 'ring'] }, { at: 0.33, p: ['ring', 'targets', 'charge', 'slam'], enrage: 1.4 }]
  };
  function monsterStats(id, lvlOverride) {
    const d = MONSTERS[id], l = lvlOverride || d.lvl, m = d.m || {};
    const mul = d.boss ? 22 : d.mini ? 7 : 1;
    return {
      lvl: l,
      hp: Math.round((40 + l * l * 2.4 + l * 16) * (m.hp || 1) * mul),
      atk: Math.round((7 + l * 3.4) * (m.atk || 1) * (d.boss ? 1.5 : d.mini ? 1.25 : 1)),
      def: Math.round((2 + l * 2.1) * (m.def || 1)),
      mdef: Math.round((2 + l * 1.9) * (m.def || 1)),
      spd: Math.round(95 * (m.spd || 1) * (d.boss ? 0.9 : 1)),
      exp: Math.round((8 + l * l * 1.5) * (m.exp || 1) * (d.boss ? 15 : d.mini ? 5 : 1)),
      gold: Math.round((2 + l * 1.8) * (m.gold || 1) * (d.boss ? 20 : d.mini ? 6 : 1)),
      range: d.ranged ? 280 : (d.boss ? 70 : 34 + d.size)
    };
  }
  const ZONE_SPAWNS = {
    plains: [['slime', 26], ['wolf', 14]], forest: [['goblin', 16], ['goblin_slinger', 9], ['boar', 10]], lake: [['mire_slime', 14], ['lurker', 10]],
    cave: [['skeleton', 16], ['golem', 8]], peaks: [['orc', 16], ['wyvern', 9]], desert: [['wraith', 14], ['drake', 9]], ash: [['demon', 14], ['hound', 12]], grove: [['boar', 6]]
  };
  const ZONE_RES = { plains: 'herb', forest: 'herb', lake: 'mana_crystal', cave: 'iron_ore', peaks: 'iron_ore', desert: 'sun_fiber', ash: 'ember_core', grove: 'herb' };

  // ---------- NPCs ----------
  const NPCS = [
    { id: 'smith', n: 'Brann the Blacksmith', role: 'blacksmith', x: 122, y: 123, col: '#8a4b2a' },
    { id: 'merchant', n: 'Lila the Merchant', role: 'merchant', shop: 'village', x: 134, y: 123, col: '#d9a441' },
    { id: 'quest', n: 'Orwin, Quest Master', role: 'quest', x: 128, y: 120, col: '#3f7fbf' },
    { id: 'trainer', n: 'Sera, Skill Trainer', role: 'trainer', x: 121, y: 133, col: '#7a4fbf' },
    { id: 'healer', n: 'Mother Ivy', role: 'healer', x: 135, y: 133, col: '#e8e8e8' },
    { id: 'guild', n: 'Castor, Guild Master', role: 'guild', x: 125, y: 137, col: '#2f5f4f' },
    { id: 'dungeon', n: 'Vex, Dungeon Keeper', role: 'dungeon', x: 131, y: 137, col: '#4a2f5f' },
    { id: 'herald', n: 'Arena Herald', role: 'arena', x: 118, y: 128, col: '#a83232' },
    { id: 'herald2', n: 'Arena Warden', role: 'arena', x: 168, y: 145, col: '#a83232' },
    { id: 'smith2', n: 'Royal Forgemaster', role: 'blacksmith', x: 224, y: 211, col: '#8a4b2a' },
    { id: 'merchant2', n: 'Capital Exchange', role: 'merchant', shop: 'capital', x: 212, y: 211, col: '#d9a441' },
    { id: 'quest2', n: 'Lady Quell, Commander', role: 'quest', x: 218, y: 208, col: '#3f7fbf' },
    { id: 'healer2', n: 'Temple Healer', role: 'healer', x: 218, y: 224, col: '#e8e8e8' },
    { id: 'dungeon2', n: 'Gatewatcher', role: 'dungeon', x: 212, y: 222, col: '#4a2f5f' }
  ];
  const all = (pre) => Object.keys(ITEMS).filter(k => k.startsWith(pre));
  const SHOPS = {
    village: ['hp_s', 'mp_s', 'hp_m', 'mp_m', 'buckler', ...all('novice_'), ...all('iron_')],
    capital: ['hp_m', 'mp_m', 'hp_l', 'elixir', 'iron_shield', ...all('knight_')]
  };
  const TIER_MATS = [null, [['iron_ore', 5], ['wolf_pelt', 3]], [['iron_ore', 10], ['golem_core', 2], ['orc_tusk', 3]], [['drake_scale', 6], ['mana_crystal', 4], ['sun_fiber', 4]], [['demon_horn', 6], ['ember_core', 4]]];
  const RECIPES = [
    { out: 'hp_m', mats: [['herb', 3]], gold: 15 }, { out: 'hp_l', mats: [['herb', 6], ['mana_crystal', 1]], gold: 50 }, { out: 'mp_m', mats: [['mana_crystal', 2]], gold: 30 },
    { out: 'elixir', mats: [['herb', 10], ['ember_core', 1], ['mana_crystal', 3]], gold: 200 },
    { out: 'iron_shield', mats: [['iron_ore', 6]], gold: 80 }, { out: 'knight_shield', mats: [['iron_ore', 12], ['golem_core', 3]], gold: 400 },
    { out: 'guardian_shield', mats: [['warden_heart', 1], ['iron_ore', 20], ['mana_crystal', 5]], gold: 1500 },
    { out: 'dawn_bastion', mats: [['abyss_shard', 1], ['demon_horn', 10], ['ember_core', 8]], gold: 6000 },
    { out: 'heartwood_mantle', mats: [['warden_heart', 2], ['herb', 20]], gold: 1200 }
  ];
  Object.values(ITEMS).forEach(it => { if (it.tier > 0 && TIER_MATS[it.tier]) RECIPES.push({ out: it.id, mats: TIER_MATS[it.tier], gold: Math.round(it.price * 0.4) }); });
  const upgradeCost = inst => { const d = ITEMS[inst.i], u = inst.u || 0; return { gold: Math.round(60 * (u + 1) * (1 + d.lvl / 5)), ore: u + 1, chance: Math.max(0.2, 1 - u * 0.09) }; };

  // ---------- quests ----------
  const QUESTS = {
    q1: { n: 'Ripples in the Meadow', type: 'Story', lvl: 1, desc: 'Orwin asks you to thin the slimes swelling around the village walls.', obj: [{ k: 'kill', m: 'slime', n: 5 }], rew: { exp: 90, gold: 40, items: [['hp_s', 5]] } },
    q2: { n: 'The Howling Fields', type: 'Kill', lvl: 2, pre: 'q1', desc: 'Wolves stalk the traders. Drive them off.', obj: [{ k: 'kill', m: 'wolf', n: 6 }], rew: { exp: 260, gold: 70, items: [['iron_ore', 3]] } },
    q3: { n: "The Herbalist's Request", type: 'Collect', lvl: 2, pre: 'q1', desc: 'Gather Glowcap Herbs that sprout across the plains.', obj: [{ k: 'collect', i: 'herb', n: 5 }], rew: { exp: 220, gold: 60, items: [['hp_m', 3]] } },
    q4: { n: 'Beyond the Walls', type: 'Explore', lvl: 3, pre: 'q1', desc: 'Scout the lands: the forest, the lake and the arena.', obj: [{ k: 'explore', z: 'forest' }, { k: 'explore', z: 'lake' }, { k: 'explore', z: 'arena' }], rew: { exp: 600, gold: 120 } },
    q5: { n: 'Thicket Raiders', type: 'Kill', lvl: 5, pre: 'q2', desc: 'Goblins raid caravans from Whisperbough.', obj: [{ k: 'kill', m: 'goblin', n: 8 }, { k: 'kill', m: 'goblin_slinger', n: 4 }], rew: { exp: 1100, gold: 180, items: [['iron_shield', 1]] } },
    q6: { n: "The Pilgrim's Road", type: 'Escort', lvl: 5, pre: 'q1', desc: 'Escort pilgrim Mara safely to the heart of Whisperbough Forest.', obj: [{ k: 'escort', to: [58, 122] }], rew: { exp: 1300, gold: 220, items: [['hp_m', 5]] } },
    q7: { n: 'Shadows in the Grove', type: 'Story', lvl: 8, pre: 'q4', desc: 'Something stirs the beasts. Hunt boars and bring pelts as proof.', obj: [{ k: 'kill', m: 'boar', n: 5 }, { k: 'collect', i: 'wolf_pelt', n: 5 }], rew: { exp: 2200, gold: 300 } },
    q8: { n: 'Into the Goblin Warren', type: 'Boss', lvl: 8, pre: 'q5', desc: 'Enter the Goblin Warren dungeon and defeat its king.', obj: [{ k: 'kill', m: 'goblin_king', n: 1 }], rew: { exp: 4000, gold: 600, items: [['hp_m', 10]] } },
    q9: { n: 'Bones Beneath', type: 'Kill', lvl: 12, desc: 'Skeletons crawl in Hollowdeep Caverns.', obj: [{ k: 'kill', m: 'skeleton', n: 12 }], rew: { exp: 5200, gold: 500 } },
    q10: { n: 'Heart of Stone', type: 'Collect', lvl: 14, desc: 'The forge needs Golem Cores.', obj: [{ k: 'collect', i: 'golem_core', n: 5 }], rew: { exp: 6500, gold: 900, items: [['knight_shield', 1]] } },
    q11: { n: 'Peak Warlords', type: 'Kill', lvl: 16, desc: 'Break the orc warbands of Ironspine.', obj: [{ k: 'kill', m: 'orc', n: 15 }], rew: { exp: 9000, gold: 1100 } },
    q12: { n: 'The Warden Awakens', type: 'Boss', lvl: 20, pre: 'q7', desc: 'The Elderbark Warden has woken in the Elder Grove. Gather a party and fell it.', obj: [{ k: 'kill', m: 'elderbark', n: 1 }], rew: { exp: 25000, gold: 3000, items: [['hp_l', 10]] } },
    q13: { n: 'Sands of the Revenant', type: 'Boss', lvl: 17, desc: 'Clear the Sunken Ruins.', obj: [{ k: 'kill', m: 'sand_revenant', n: 1 }], rew: { exp: 22000, gold: 2500 } },
    q14: { n: 'Ash and Ember', type: 'Kill', lvl: 28, desc: 'Push back the demons of the Ashen Wastes.', obj: [{ k: 'kill', m: 'demon', n: 15 }], rew: { exp: 60000, gold: 5000 } },
    q15: { n: 'The Abyss Regent', type: 'Boss', lvl: 30, desc: 'End the Regent in the Obsidian Citadel.', obj: [{ k: 'kill', m: 'abyss_regent', n: 1 }], rew: { exp: 150000, gold: 12000, items: [['elixir', 10]] } }
  };

  const APPEARANCE = {
    skins: ['#ffe0c4', '#f3c69b', '#d9a066', '#a8703f', '#6e4526', '#c9e4ff'],
    hairs: ['#2b2b2b', '#f2d16b', '#c0392b', '#e8e8f0', '#5b8def', '#e86fb2', '#7a4a2a', '#4fbf8f'],
    outfits: ['#3f6fbf', '#bf3f3f', '#3fbf6f', '#8f3fbf', '#bf8f3f', '#2f2f3f', '#e8e8e8', '#3fbfbf'],
    styles: ['Short', 'Long', 'Ponytail', 'Twin tails', 'Spiky'],
    accs: ['None', 'Circlet', 'Cape', 'Elf ears', 'Ribbon']
  };

  return {
    TILE, MAP_W, MAP_H, CHUNK, VIEW, MAX_LEVEL, T, SOLID, TILE_COLORS, ZONES, ZONE_IDX, DUNGEONS, CLASSES, SKILLS, FEATS, RARITY, SLOTS, ITEMS, TIERS,
    STAT_KEYS, STAT_NAMES, ALLOC, MONSTERS, BOSS_PHASES, ZONE_SPAWNS, ZONE_RES, NPCS, SHOPS, RECIPES, QUESTS, APPEARANCE,
    hash, vnoise, buildWorld, buildDungeon, buildArena, solidAt, hitBox, tryMove, zoneAt, computeStats, expToNext, monsterStats,
    makeItem, itemStats, itemName, upgradeCost, rollRarity
  };
});
