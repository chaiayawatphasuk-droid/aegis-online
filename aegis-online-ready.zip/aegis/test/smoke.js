// End-to-end smoke test: spawns the server, registers 2 users, creates characters, connects via WebSocket,
// moves, attacks, checks multiplayer visibility, quest accept, shop buy, party and save/reload.
'use strict';
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const PORT = 3999, BASE = `http://localhost:${PORT}`;
const DBP = path.join(require('os').tmpdir(), `aegis-test-${Date.now()}.db`);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let fails = 0;
const ok = (c, m) => { console.log((c ? '✔ ' : '✘ ') + m); if (!c) fails++; };

async function post(url, body, tok) {
  const r = await fetch(BASE + url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(tok ? { Authorization: 'Bearer ' + tok } : {}) }, body: JSON.stringify(body) });
  return r.json();
}
async function get(url, tok) { return (await fetch(BASE + url, { headers: { Authorization: 'Bearer ' + tok } })).json(); }
function client(tok, cid) {
  const ws = new WebSocket(`ws://localhost:${PORT}/ws`), st = { msgs: [], ents: new Map(), me: null, inv: null, q: null, chat: [], party: null };
  ws.onopen = () => ws.send(JSON.stringify({ t: 'auth', token: tok, cid }));
  ws.onmessage = e => {
    const m = JSON.parse(e.data); st.msgs.push(m);
    if (m.t === 's') { st.pos = m.me; (m.a || []).forEach(a => st.ents.set(a.id, a)); (m.r || []).forEach(id => st.ents.delete(id)); st.snap = m; }
    if (m.t === 'init') st.init = m; if (m.t === 'me') st.me = m; if (m.t === 'inv') st.inv = m; if (m.t === 'q') st.q = m;
    if (m.t === 'chat') st.chat.push(m); if (m.t === 'party') st.party = m; if (m.t === 'pinv') st.pinv = m;
  };
  st.send = o => ws.send(JSON.stringify(o)); st.ws = ws; return st;
}

(async () => {
  const srv = spawn(process.execPath, ['--no-warnings', path.join(__dirname, '..', 'server', 'index.js')], { env: { ...process.env, PORT, DB_PATH: DBP, JWT_SECRET: 'test-secret-1234567890' }, stdio: ['ignore', 'pipe', 'pipe'] });
  srv.stderr.on('data', d => process.stderr.write('[srv] ' + d));
  await sleep(1200);
  try {
    const r1 = await post('/api/register', { username: 'alice', password: 'secret123' });
    const r2 = await post('/api/register', { username: 'bob', password: 'secret123' });
    ok(r1.token && r2.token, 'register two users');
    ok((await post('/api/register', { username: 'alice', password: 'x12345' })).error, 'duplicate username rejected');
    ok((await post('/api/login', { username: 'alice', password: 'wrong!!' })).error, 'wrong password rejected');
    const l1 = await post('/api/login', { username: 'alice', password: 'secret123' }); ok(l1.token, 'login');
    const c1 = await post('/api/characters', { name: 'Aegis', cls: 'guardian', app: { g: 'f', hair: 2, hc: 3 } }, l1.token);
    const c2 = await post('/api/characters', { name: 'Blade', cls: 'warrior', app: {} }, r2.token);
    ok(c1.id && c2.id, 'create characters');
    const list = await get('/api/characters', l1.token); ok(list.chars.length === 1 && list.chars[0].cls === 'guardian', 'list characters');

    const A = client(l1.token, c1.id), B = client(r2.token, c2.id);
    await sleep(1200);
    ok(A.init && B.init, 'both clients joined');
    ok(A.me && A.me.st.def > 0 && A.inv.eq.offhand, 'guardian stats + starter shield');
    const bSeen = [...A.ents.values()].some(e => e.k === 'p' && e.n === 'Blade');
    ok(bSeen, 'player A sees player B (multiplayer AOI)');
    ok([...A.ents.values()].some(e => e.k === 'n'), 'NPCs visible');
    const y0 = A.pos[1];
    A.send({ t: 'i', x: 0, y: 1, r: 1 }); await sleep(600); A.send({ t: 'i', x: 0, y: 0 }); await sleep(200);
    ok(A.pos[1] > y0 + 30, `server-authoritative movement (dy=${A.pos[1] - y0})`);
    const bEnt = B.snap.e.find(e => e[0] === A.init.id); ok(bEnt && Math.abs(bEnt[2] - A.pos[1]) < 40, 'B receives A position updates');
    // quest + npc
    const walkTo = async (st, x, y) => { for (let i = 0; i < 80; i++) { const dx = x - st.pos[0], dy = y - st.pos[1], d = Math.hypot(dx, dy); if (d < 70) break; st.send({ t: 'i', x: dx / d, y: dy / d, r: 1 }); await sleep(100); } st.send({ t: 'i', x: 0, y: 0 }); await sleep(150); };
    const qn = [...A.ents.values()].find(e => e.k === 'n' && e.role === 'quest');
    await walkTo(A, qn.x, qn.y + 40);
    A.send({ t: 'qa', n: qn.id, q: 'q1' }); await sleep(300);
    ok(A.q && A.q.a.q1, 'accept quest from Quest Master');
    const mer = [...A.ents.values()].find(e => e.k === 'n' && e.role === 'merchant');
    await walkTo(A, mer.x, mer.y + 40);
    const g0 = A.me.gold; A.send({ t: 'buy', n: mer.id, id: 'hp_s', q: 2 }); await sleep(300);
    ok(A.me.gold === g0 - 40, 'buy from merchant (server validated gold)');
    A.send({ t: 'buy', n: mer.id, id: 'celestial_guardian_wpn', q: 1 }); await sleep(200);
    ok(A.me.gold === g0 - 40, 'cannot buy items not in shop');
    // chat + party
    A.send({ t: 'c', ch: 'g', m: 'hello world' }); await sleep(200);
    ok(B.chat.some(c => c.m === 'hello world'), 'global chat');
    A.send({ t: 'pi', name: 'Blade' }); await sleep(200); B.send({ t: 'pa' }); await sleep(1300);
    ok(A.party && A.party.m && A.party.m.length === 2, 'party invite/accept');
    // combat: walk A towards nearest slime and attack
    const slime = [...A.ents.values()].find(e => e.k === 'm');
    ok(!!slime, 'monsters visible');
    A.send({ t: 's', k: 'g_bulwark' }); await sleep(200);
    ok(A.me.buffs.some(b => b[0] === 'def_up'), 'skill Bulwark Stance applies DEF buff');
    A.send({ t: 'b', on: 1 }); await sleep(150); ok((A.pos[8] & 1) === 1, 'block flag'); A.send({ t: 'b', on: 0 });
    A.send({ t: 'al', k: 'end' }); await sleep(200); // no points at lvl1 -> ignored
    // save & reload
    A.ws.close(); await sleep(500);
    const A2 = client(l1.token, c1.id); await sleep(1000);
    ok(Math.abs(A2.pos[1] - A.pos[1]) < 40 && A2.q.a.q1, 'position + quests persisted after relog');
    ok(A2.inv.inv.some(i => i && i.i === 'hp_s' && i.q >= 12), 'inventory persisted');
    // tamper attempt: invalid messages must not crash server
    A2.send({ t: 'eq', s: 999 }); A2.send({ t: 'buy', n: 'x' }); A2.ws.send('garbage'); A2.send({ t: 'i', x: 99999, y: 0 });
    await sleep(400); A2.send({ t: 'i', x: 0, y: 0 });
    const h = await (await fetch(BASE + '/health')).json(); ok(h.ok && h.players === 2, 'server healthy after bad input');
    A2.ws.close(); B.ws.close();
  } catch (e) { console.error(e); fails++; }
  srv.kill('SIGTERM'); await sleep(300);
  try { fs.unlinkSync(DBP); } catch { }
  console.log(fails ? `\n${fails} FAILED` : '\nALL TESTS PASSED');
  process.exit(fails ? 1 : 0);
})();
