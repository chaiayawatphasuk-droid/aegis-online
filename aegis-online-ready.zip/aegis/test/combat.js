// Bot test: leave town, hunt monsters, verify kill -> EXP/gold/quest progress, then enter a dungeon instance.
'use strict';
const { spawn } = require('child_process');
const path = require('path');
const PORT = 3998, BASE = `http://localhost:${PORT}`;
const sleep = ms => new Promise(r => setTimeout(r, ms));
const post = async (u, b, t) => (await fetch(BASE + u, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(t ? { Authorization: 'Bearer ' + t } : {}) }, body: JSON.stringify(b) })).json();
(async () => {
  const DBP = path.join(require('os').tmpdir(), 'aegis-combat-' + Date.now() + '.db');
  const srv = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { env: { ...process.env, PORT, DB_PATH: DBP, JWT_SECRET: 'x'.repeat(20) }, stdio: ['ignore', 'inherit', 'inherit'] });
  await sleep(1200); let ok = true;
  try {
    const r = await post('/api/register', { username: 'bot', password: 'secret123' });
    const c = await post('/api/characters', { name: 'Botty', cls: process.argv[2] || 'warrior', app: {} }, r.token);
    const ws = new WebSocket(`ws://localhost:${PORT}/ws`), st = { ents: new Map(), fx: 0, msgs: [] };
    ws.onopen = () => ws.send(JSON.stringify({ t: 'auth', token: r.token, cid: c.id }));
    ws.onmessage = e => { const m = JSON.parse(e.data); if (m.t === 's') { st.pos = m.me; (m.a || []).forEach(a => st.ents.set(a.id, a)); (m.r || []).forEach(id => st.ents.delete(id)); m.e.forEach(a => { const x = st.ents.get(a[0]); if (x) Object.assign(x, { x: a[1], y: a[2], hp: a[4] }); }); } if (m.t === 'me') st.me = m; if (m.t === 'q') st.q = m; if (m.t === 'f') st.fx += m.l.length; if (m.t === 'm') st.msgs.push(m.m); if (m.t === 'map') st.map = m; };
    const send = o => ws.send(JSON.stringify(o));
    await sleep(800);
    const qn = [...st.ents.values()].find(e => e.k === 'n' && e.role === 'quest');
    const walk = async (x, y, stop = 50) => { for (let i = 0; i < 300; i++) { const dx = x - st.pos[0], dy = y - st.pos[1], d = Math.hypot(dx, dy); if (d < stop) break; send({ t: 'i', x: dx / d, y: dy / d, r: 1 }); await sleep(100); } send({ t: 'i', x: 0, y: 0 }); };
    await walk(qn.x, qn.y + 40, 60); send({ t: 'qa', n: qn.id, q: 'q1' }); await sleep(200);
    console.log('quest accepted:', !!(st.q && st.q.a.q1));
    await walk(128.5 * 32, 150 * 32, 40);
    const exp0 = st.me.exp, gold0 = st.me.gold; let kills = 0;
    for (let n = 0; n < 6; n++) {
      const mons = [...st.ents.values()].filter(e => e.k === 'm' && e.m === 'slime' && e.x !== undefined).sort((a, b) => Math.hypot(a.x - st.pos[0], a.y - st.pos[1]) - Math.hypot(b.x - st.pos[0], b.y - st.pos[1]));
      if (!mons.length) { await walk(st.pos[0] + 200, st.pos[1] + 100); continue; }
      const m = mons[0];
      for (let i = 0; i < 150 && st.ents.has(m.id); i++) {
        const d = Math.hypot(m.x - st.pos[0], m.y - st.pos[1]);
        if (d > 55) { send({ t: 'i', x: (m.x - st.pos[0]) / d, y: (m.y - st.pos[1]) / d, r: 1 }); } else { send({ t: 'i', x: 0, y: 0 }); send({ t: 'a', a: Math.atan2(m.y - st.pos[1], m.x - st.pos[0]), id: m.id }); if (i % 7 === 0) send({ t: 's', k: GD.CLASSES[c.cls || process.argv[2] || 'warrior'].skills[0], id: m.id, x: m.x, y: m.y }); }
        await sleep(100);
      }
      if (!st.ents.has(m.id)) kills++;
    }
    console.log('kills', kills, 'exp', exp0, '->', st.me.exp, 'lv', st.me.lv, 'gold', gold0, '->', st.me.gold, 'q1', JSON.stringify(st.q.a.q1 || 'done'), 'hp', st.pos[2], '/', st.pos[3], 'fx', st.fx);
    ok = kills > 0 && (st.me.exp > exp0 || st.me.lv > 1);
    console.log(st.msgs.slice(-6).join('\n'));
    ws.close();
  } catch (e) { console.error(e); ok = false; }
  srv.kill('SIGTERM'); await sleep(300); try { require('fs').unlinkSync(DBP); } catch { }
  console.log(ok ? 'COMBAT OK' : 'COMBAT FAILED'); process.exit(ok ? 0 : 1);
})();
const GD = require('../shared/data');
