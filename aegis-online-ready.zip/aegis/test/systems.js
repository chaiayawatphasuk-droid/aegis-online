// In-process system test: dungeon instance, boss phases, arena match, trade, guild, crafting.
'use strict';
process.env.JWT_SECRET = 'y'.repeat(20);
const path = require('path'), os = require('os'), fs = require('fs');
const GD = require('../shared/data');
const DB = require('../server/database/db');
const { Game } = require('../server/systems/game');
const DBP = path.join(os.tmpdir(), 'aegis-sys-' + Date.now() + '.db');
const db = new DB(DBP), game = new Game(db);
let fails = 0; const ok = (c, m) => { console.log((c ? '✔ ' : '✘ ') + m); if (!c) fails++; };
const fakeSock = () => ({ open: true, out: [], send(s) { this.out.push(JSON.parse(s)); }, close() { this.open = false; } });
function mk(name, cls, lvl) {
  const uid = db.addUser(name, 'x');
  const id = db.createChar(uid, name, cls, 5000, { app: {}, alloc: {}, pts: 0, pos: { x: 128.5 * 32, y: 130.5 * 32 } }, [GD.makeItem('iron_ore', 50), GD.makeItem('herb', 10)], {});
  db.q.saveChar.run(lvl, 0, 5000, 1000, 0, 0, JSON.stringify({ app: {}, pos: { x: 128.5 * 32, y: 130.5 * 32 } }), Date.now(), id);
  const s = fakeSock(); const p = game.join(s, uid, id); return p;
}
(async () => {
  try {
    const a = mk('Tank', 'guardian', 30), b = mk('Mage', 'mage', 30);
    // party + dungeon
    game.handle(a, JSON.stringify({ t: 'pi', name: 'Mage' })); game.handle(b, JSON.stringify({ t: 'pa' }));
    ok(a.party && a.party === b.party, 'party formed');
    game.enterDungeon(a, 'goblin'); game.enterDungeon(b, 'goblin');
    ok(a.map.kind === 'dungeon' && a.map === b.map, 'party shares one dungeon instance');
    const boss = [...a.map.ents.values()].find(e => e.kind === 'm' && e.mid === 'goblin_king');
    ok(!!boss, 'dungeon has final boss');
    game.handle(a, JSON.stringify({ t: 'qa', n: 0, q: 'q8' }));
    a.quests.active.q8 = { p: [0] };
    boss.hp = boss.mhp * 0.5; boss.state = 'chase'; boss.patT = 0; a.x = boss.x - 40; a.y = boss.y; b.x = boss.x - 80; b.y = boss.y;
    game.bossThink(boss, Date.now(), a.map);
    ok(boss.phase === 1, 'boss enters phase 2 at 50% hp');
    game.dealDamage(a, boss, 1, {}); boss.hp = 1; game.dealDamage(b, boss, 5, { magic: true });
    ok(boss.dead && a.map.meta.cleared, 'boss killed -> dungeon cleared');
    ok(a.quests.active.q8.p[0] === 1, 'boss quest progress shared');
    const chest = [...a.map.ents.values()].find(e => e.st === 'chest');
    a.x = chest.x; a.y = chest.y; const inv0 = a.inv.filter(Boolean).length; game.interact(a, chest); game.autoLoot(a, Date.now() + 99999);
    ok(a.inv.filter(Boolean).length > inv0, 'reward chest loot');
    game.leaveInstance(a); game.leaveInstance(b);
    ok(a.map.kind === 'world', 'left dungeon');
    // taunt + block/reflect
    const m = [...game.world.ents.values()].find(e => e.kind === 'm' && e.mid === 'slime');
    a.x = m.x + 30; a.y = m.y; a.cds = {}; a.lvl = 30; game.recalc(a); a.mp = 999;
    game.useSkill(a, { k: 'g_taunt' });
    ok(m.buffs.taunt && m.buffs.taunt.v === a.id, 'Challenge Roar taunts monster');
    a.blocking = true; const hp0 = a.hp; m.hp = m.mhp = 1e6; game.dealDamage(m, a, 1, {});
    ok(a.hp >= hp0 - 5 && m.hp < 1e6, 'guardian block reduces damage and reflects');
    a.blocking = false;
    game.useSkill(a, { k: 'g_aegis' }); ok(a.sh > 0, 'Aegis Link shield');
    // arena 1v1
    a.party = null; b.party = null;
    game.queueArena(a, 1); game.queueArena(b, 1);
    ok(a.map.kind === 'arena' && a.team !== b.team, 'arena match created');
    a.map.meta.start = 0; ok(game.canHarm(a, b), 'enemies can fight in arena');
    b.hp = 1; game.dealDamage(a, b, 50, {}); ok(b.dead && a.map.meta.done && a.wins === 1 && a.rating === 1020, 'arena result + rating');
    a.map.meta.closeT = 0; game.updateArena(a.map, Date.now());
    ok(a.map.kind === 'world' && b.map.kind === 'world' && !b.dead, 'returned from arena');
    // world PvP protection
    ok(!game.canHarm(a, b), 'no PvP outside arena / unflagged');
    // trade
    b.x = a.x + 50; b.y = a.y;
    const sword = GD.makeItem('iron_guardian_wpn', 1, Math.random, -1); a.inv[30] = sword;
    game.handle(a, JSON.stringify({ t: 'tr', name: 'Mage' })); game.handle(b, JSON.stringify({ t: 'ta' }));
    game.handle(a, JSON.stringify({ t: 'to', s: 30 })); game.handle(b, JSON.stringify({ t: 'tg', g: 300 }));
    const ga = a.gold, gb = b.gold;
    game.handle(a, JSON.stringify({ t: 'tc' })); game.handle(b, JSON.stringify({ t: 'tc' }));
    ok(a.gold === ga + 300 && b.gold === gb - 300 && b.inv.includes(sword) && !a.inv.includes(sword), 'trade executed atomically');
    // guild
    const gm = [...game.world.ents.values()].find(e => e.kind === 'n' && e.role === 'guild'); a.x = gm.x; a.y = gm.y + 30;
    game.handle(a, JSON.stringify({ t: 'gc', n: gm.id, name: 'Iron Wall' })); ok(a.gid > 0, 'guild created');
    game.handle(a, JSON.stringify({ t: 'gi', name: 'Mage' })); game.handle(b, JSON.stringify({ t: 'ga' })); ok(b.gid === a.gid, 'guild invite');
    game.handle(b, JSON.stringify({ t: 'gd', s: b.inv.indexOf(sword) })); ok(game.guild(a.gid).storage.length === 1, 'guild storage deposit');
    // crafting + upgrade
    const sm = [...game.world.ents.values()].find(e => e.kind === 'n' && e.role === 'blacksmith' && e.nid === 'smith'); a.x = sm.x; a.y = sm.y + 30;
    const ri = GD.RECIPES.findIndex(r => r.out === 'iron_shield'); game.handle(a, JSON.stringify({ t: 'craft', n: sm.id, r: ri }));
    ok(a.inv.some(i => i && i.i === 'iron_shield'), 'crafted Iron Shield');
    const s = a.inv.findIndex(i => i && i.i === 'iron_shield'); game.handle(a, JSON.stringify({ t: 'eq', s })); ok(a.eq.offhand.i === 'iron_shield', 'equip shield');
    for (let i = 0; i < 3; i++) game.handle(a, JSON.stringify({ t: 'up', n: sm.id, sl: 'offhand' }));
    ok((a.eq.offhand.u || 0) >= 1, 'upgrade equipment');
    // feats
    a.cnt.blocks = 100; game.checkFeats(a); ok(a.feats.includes('stoneheart'), 'Stoneheart feat unlocks');
    // save/load
    game.save(a); const L = db.loadChar(a.cid); ok(L.eq.offhand && L.data.feats.includes('stoneheart') && L.row.wins === 1, 'persistence of eq/feats/pvp');
    console.log(db.db.prepare('SELECT kind, COUNT(*) n FROM transactions GROUP BY kind').all().map(r => `${r.kind}:${r.n}`).join(' '));
  } catch (e) { console.error(e); fails++; }
  clearInterval(game.timer); try { fs.unlinkSync(DBP); } catch { }
  console.log(fails ? `${fails} FAILED` : 'ALL SYSTEM TESTS PASSED'); process.exit(fails ? 1 : 0);
})();
